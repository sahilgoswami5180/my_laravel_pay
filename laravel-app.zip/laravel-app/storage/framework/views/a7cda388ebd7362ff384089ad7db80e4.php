<?php $__env->startSection('content'); ?>
    <div class="container mx-auto top-0">
        <!-- Breadcrumb Navigation -->
        <nav class="flex text-md text-gray-600 mb-4 items-center justify-between">
            <div class="flex items-center">
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="hover:text-blue-500 flex items-center <?php echo e(Request::is('dashboard') ? 'text-blue-500' : ''); ?>">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <a href="<?php echo e(route('categories.index')); ?>"
                    class="hover:text-blue-500 flex items-center <?php echo e(Request::is('categories') || Request::is('categories/*') ? 'text-blue-500' : ''); ?>">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Categories</span>
                </a>
            </div>
            <div class="flex items-center">
                <a href="<?php echo e(route('deleted-categories.index')); ?>"
                    class="bg-yellow-500 text-white px-2 py-2 rounded-full shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 text-sm">
                    View Deleted Categories
                </a>
            </div>
        </nav>

        <!-- Filter Bar -->
        <form action="<?php echo e(route('categories.index')); ?>" method="GET"
            class="flex justify-between items-center mb-4 bg-gray-50 p-4 rounded-lg shadow-md ">
            <div class="flex space-x-2 w-full max-w-3xl">
                <!-- Search by Category Name -->
                <input type="text" name="search" placeholder="Search by category name..."
                    value="<?php echo e(request()->search); ?>"
                    class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                    style="width: 500px;">

                <!-- Apply Filters Button -->
                <button type="submit"
                    class="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 text-sm">
                    <i class="fas fa-filter"></i>
                </button>
                <!-- Reset Filters Button -->
                <a href="<?php echo e(route('categories.index')); ?>"
                    class="bg-gray-300 text-black px-6 py-3 rounded-full shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center justify-center text-sm">
                    <i class="fas fa-undo"></i>
                </a>
            </div>

            <div class="flex space-x-2 items-center justify-between">
                <!-- Add New Category Button -->
                <a href="<?php echo e(route('categories.create')); ?>"
                    class="bg-indigo-900 text-white py-2 rounded-full shadow-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition duration-300 flex items-center justify-center text-sm"
                    style="width: 220px;">
                    <i class="fas fa-plus-circle mr-2"></i> Add New Category
                </a>
            </div>
        </form>

        <!-- Categories Table -->
        <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
            <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 text-gray-600">
                    <tr>
                        <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Category Name</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Image</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Description</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Having products</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Having subcategories</th>
                        <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                            <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($category->id); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-800 uppercase font-semibold"><?php echo e($category->name); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-800">
                                <?php if($category->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>"
                                        class="w-12 h-12 object-cover rounded-full">
                                <?php else: ?>
                                    <span>No Image</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-800">
                                <?php echo e($category->description ?? 'No description available'); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-800">
                                <a href="<?php echo e(route('categories.products', $category)); ?>"
                                    class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition duration-300">
                                    <i class="fas fa-box"></i>
                                </a>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-800">
                                <a href="<?php echo e(route('categories.viewSubcategories', $category)); ?>"
                                    class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition duration-300">
                                    <i class="fa-solid fa-bars"></i>
                                </a>
                            </td>
                            <td class="px-6 py-4 text-sm text-center">
                                <div class="flex justify-center space-x-4">
                                    <a href="<?php echo e(route('categories.view', $category)); ?>"
                                        class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 text-sm">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('categories.edit', $category)); ?>"
                                        class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 text-sm">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button"
                                        class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm"
                                        onclick="confirmDelete(<?php echo e($category->id); ?>)">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-6 py-4 text-center text-gray-500 text-sm">No categories found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4 text-sm">
            <?php echo e($categories->links()); ?> <!-- Pagination Links -->
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Are you sure you want to delete this category?</h3>
            <form id="deleteForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="flex justify-end space-x-4">
                    <button type="button" onclick="closeModal()"
                        class="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 transition duration-300 text-sm">
                        Cancel
                    </button>
                    <button type="submit"
                        class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm">
                        Delete
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function confirmDelete(categoryId) {
            const deleteModal = document.getElementById('deleteModal');
            const deleteForm = document.getElementById('deleteForm');
            deleteForm.action = `/categories/${categoryId}`;
            deleteModal.classList.remove('hidden');
        }

        function closeModal() {
            const deleteModal = document.getElementById('deleteModal');
            deleteModal.classList.add('hidden');
        }
    </script>

    <?php if(session('success')): ?>
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 text-sm">
            <!-- Success Icon -->
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <!-- Success Message -->
            <span><?php echo e(session('success')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <!-- Error Toast -->
    <?php if(session('error')): ?>
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 text-sm">
            <!-- Error Icon -->
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <!-- Error Message -->
            <span><?php echo e(session('error')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Desktop/laravel-auth-app/resources/views/categories/index.blade.php ENDPATH**/ ?>