<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="bg-gray-50 flex items-center justify-center min-h-screen">

    <!-- Main container with two sides: left for image, right for form -->
    <div class="flex w-full min-h-screen">

        <!-- Left side: Image Section -->
        <div class="hidden lg:block w-1/2 h-full bg-cover bg-center flex items-center justify-center">
            <!-- Image will cover the left side -->
            <img src="https://cdni.iconscout.com/illustration/premium/thumb/user-login-4268415-3551762.png" alt="" style="height:605px;width:700px;" class="h-full w-full object-cover">
        </div>

        <!-- Right side: Form Section -->
        <div class="w-full lg:w-1/2 bg-gradient-to-r from-blue-100 via-blue-200 to-blue-300 shadow-lg rounded-lg p-8 space-y-6 overflow-y-aut">
            <h2 class="text-3xl font-bold text-center text-blue-500 mb-6">Login</h2>

            <form id="login-form" action="<?php echo e(route('login')); ?>" method="POST" class="space-y-4">
                <?php echo csrf_field(); ?>

                <div class="relative">
                    <label for="email" class="block text-gray-700 font-medium mb-1">Email <span class="text-red-500">*</span></label>
                    <input type="email" name="email" id="email"
                        class="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2  transition"
                        placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <span class="absolute right-3 top-1/2  cursor-pointer text-gray-500">
                        <i class="fas fa-envelope"></i>
                    </span>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="relative">
                    <label for="password" class="block text-gray-700 font-medium mb-1">Password <span class="text-red-500">*</span></label>
                    <input type="password" name="password" id="password"
                        class="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2  transition"
                        placeholder="Password">
                    <span id="toggle-password"
                        class="absolute right-3 top-1/2 cursor-pointer text-gray-500" style="top: 50px;"
                        onclick="togglePassword()">
                        <i id="password-icon" class="fas fa-eye"></i>
                    </span>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex items-center justify-between">
                    <div>
                        <label for="remember" class="flex items-center">
                            <input type="checkbox" name="remember" id="remember"
                                class="h-4 w-4 text-blue-500 border-gray-300 rounded focus:ring-2 focus:ring-blue-500">
                            <span class="ml-2 text-gray-700">Remember me</span>
                        </label>
                    </div>
                    <div>
                        <a href="<?php echo e(route('forgot.password')); ?>" class="text-blue-500 hover:underline">Forgot Password?</a>
                    </div>
                </div>

                <button type="submit"
                    class="w-full bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 transition">Login</button>
            </form>

            <div class="mt-4 text-center">
                <span class="text-gray-600">Don't have an account?</span>
                <a href="<?php echo e(route('register.form')); ?>" class="text-blue-500 hover:underline ml-1">Create new</a>
            </div>

        </div>

    </div>

    <!-- Success Toast -->
    <?php if(session('success')): ?>
    <div id="successToast"
        class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
        <i class="fas fa-check-circle text-white text-2xl"></i>
        <span><?php echo e(session('success')); ?></span>
    </div>

    <script>
        setTimeout(() => {
            document.querySelector('#successToast').style.display = 'none';
        }, 4000);
    </script>
    <?php endif; ?>

    <!-- Error Toast -->
    <?php if(session('error')): ?>
    <div id="errorToast"
        class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
        <i class="fas fa-times-circle text-white text-2xl"></i>
        <span><?php echo e(session('error')); ?></span>
    </div>

    <script>
        setTimeout(() => {
            document.querySelector('#errorToast').style.display = 'none';
        }, 4000);
    </script>
    <?php endif; ?>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const passwordIcon = document.getElementById('password-icon');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.classList.remove('fa-eye');
                passwordIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordIcon.classList.remove('fa-eye-slash');
                passwordIcon.classList.add('fa-eye');
            }
        }
    </script>
    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const passwordIcon = document.getElementById('password-icon');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.classList.remove('fa-eye');
                passwordIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordIcon.classList.remove('fa-eye-slash');
                passwordIcon.classList.add('fa-eye');
            }
        }


        // Remember credentials functionality
        document.getElementById('login-form').addEventListener('submit', function(e) {
            if (document.getElementById('remember').checked) {
                // Save email, password, and last login time to cookies
                const email = document.getElementById('email').value;
                const password = document.getElementById('password').value;
                const lastLoginTime = new Date().toISOString(); // Current time in ISO format

                // Create a user object to store in the cookie
                const userData = {
                    email: email,
                    password: password,
                    last_login_at: lastLoginTime
                };

                // Encode the user data as a JSON string and store it in a cookie
                document.cookie = `user_data=${encodeURIComponent(JSON.stringify(userData))};max-age=86400;path=/`; // 1 day expiration
            }
        });

        // Load credentials from cookies if "Remember me" was checked earlier
        window.onload = function() {
            const cookies = document.cookie.split(';');
            let userDataCookie = '';

            cookies.forEach(cookie => {
                const [key, value] = cookie.trim().split('=');
                if (key === 'user_data') userDataCookie = decodeURIComponent(value);
            });

            // If the user data cookie is found, parse it and populate the form
            if (userDataCookie) {
                const userData = JSON.parse(userDataCookie);

                // Populate form fields with the data from the cookie
                document.getElementById('email').value = userData.email;
                document.getElementById('password').value = userData.password;
                document.getElementById('remember').checked = true; // Check the "Remember me" checkbox

                // Display the last login time
                const lastLoginDate = new Date(userData.last_login_at);
                const lastLoginFormatted = lastLoginDate.toLocaleString(); // You can format it further as needed
                document.getElementById('last-login-time').textContent = `Last login: ${lastLoginFormatted}`;
            } else {
                document.getElementById('remember').checked = false; // Uncheck the "Remember me" checkbox
            }
        };
    </script>
</body>

</html><?php /**PATH /home/xceltec-28/Desktop/laravel-auth-app/resources/views/auth/login.blade.php ENDPATH**/ ?>