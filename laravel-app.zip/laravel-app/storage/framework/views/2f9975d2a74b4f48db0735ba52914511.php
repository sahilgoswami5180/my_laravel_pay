<div class="bg-white shadow-md rounded-lg p-6 mx-auto w-full max-w-screen-lg mt-8">
    <!-- Toast Notification -->
    <div id="toast" class="hidden fixed top-4 right-4 bg-green-500 text-white p-4 rounded shadow-lg flex items-center space-x-3">
        <i class="fas fa-check-circle"></i>
        <span id="toast-message"></span>
        <button onclick="hideToast()" class="ml-4 text-white hover:text-gray-200">&times;</button>
    </div>

    <h2 class="text-2xl font-bold text-center mb-6">Categories</h2>

    <!-- Create New Category Button -->
    <div class="text-right mb-4">
        <a href="<?php echo e(route('categories.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300">
            <i class="fas fa-plus-circle mr-2"></i> Create New Category
        </a>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-md">
        <table class="min-w-full table-auto">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Category Name</th>
                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-700">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="px-4 py-2 text-sm text-gray-800"><?php echo e($category->name); ?></td>
                    <td class="px-4 py-2 text-sm flex space-x-3">
                        <a href="<?php echo e(route('categories.edit', $category)); ?>" class="text-blue-500 hover:underline">
                            <i class="fas fa-edit"></i> Edit
                        </a>

                        <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 hover:underline">
                                <i class="fas fa-trash-alt"></i> Delete
                            </button>
                        </form>

                        <a href="<?php echo e(route('categories.show', $category)); ?>" class="text-green-500 hover:underline">
                            <i class="fas fa-eye"></i> View
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/categories-table.blade.php ENDPATH**/ ?>