<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto">
        <!-- Loader Section -->
        <div id="loader" class="fixed inset-0 flex justify-center items-center bg-white bg-opacity-0 z-50"
            style="z-index:9999; background-color:white;">
            <img src="<?php echo e(asset('img/Spinner@2x-0.9s-200px-200px.gif')); ?>" alt="Loading..." class="w-16 h-16">
        </div>

        <!-- Cards Section -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            <!-- Total Categories Card -->
            <div class="bg-white shadow-md rounded-lg relative overflow-hidden">
                <div class="bg-blue-500 text-white p-4 rounded-t-lg flex items-center">
                    <h3 class="text-lg font-bold flex items-center">
                        <i class="fas fa-list mr-2 text-xl"></i> Total Categories
                    </h3>
                </div>
                <div class="pb-0">
                    <div
                        class="p-6 pb-1 flex items-center justify-between hover: transition duration-300 ease-in-out rounded-lg cursor-pointer">
                        <div class="text-lg font-bold">
                            <p class="text-gray-600 font-medium">Active Categories</p>
                            <p class="text-4xl font-semibold text-gray-800"><?php echo e($activeCategories->count() ?? 0); ?></p>
                        </div>
                        <i
                            class="fas fa-list text-blue-300 text-6xl transform hover:scale-110 transition-transform duration-300"></i>
                    </div>
                    <hr class="my-2 border-gray-300 w-full p-0">
                    <div class="py-1 mb-1 px-4 text-center flex items-center justify-end space-x-2">
                        <a href="<?php echo e(route('categories.index')); ?>"
                            class="text-blue-600 font-medium hover:underline flex items-center"
                            style="text-decoration: none;">
                            More Info <i class="fas fa-arrow-circle-right text-blue-500 text-lg ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Active Subcategories Card -->
            <div class="bg-white shadow-md rounded-lg relative overflow-hidden">
                <div class="bg-blue-500 text-white p-4 rounded-t-lg flex items-center">
                    <h3 class="text-lg font-bold flex items-center">
                        <i class="fas fa-list mr-2 text-xl"></i> Active Subcategories
                    </h3>
                </div>
                <div class="pb-0">
                    <div
                        class="p-6 pb-1 flex items-center justify-between hover: transition duration-300 ease-in-out rounded-lg cursor-pointer">
                        <div class="text-lg font-bold">
                            <p class="text-gray-600 font-medium">Active Subcategories</p>
                            <p class="text-4xl font-semibold text-gray-800"><?php echo e($activeSubcategories->count() ?? 0); ?></p>
                        </div>
                        <i
                            class="fas fa-list text-blue-300 text-6xl transform hover:scale-110 transition-transform duration-300"></i>
                    </div>
                    <hr class="my-2 border-gray-300 w-full p-0">
                    <div class="py-1 mb-1 px-4 text-center flex items-center justify-end space-x-2">
                        <a href="<?php echo e(route('subcategories.index')); ?>"
                            class="text-blue-600 font-medium hover:underline flex items-center"
                            style="text-decoration: none;">
                            More Info <i class="fas fa-arrow-circle-right text-blue-500 text-lg ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Total Products Card -->
            <div class="bg-white shadow-md rounded-lg relative overflow-hidden">
                <div class="bg-blue-500 text-white p-4 rounded-t-lg flex items-center">
                    <h3 class="text-lg font-bold flex items-center">
                        <i class="fas fa-box mr-2 text-xl"></i> Total Products
                    </h3>
                </div>
                <div class="pb-0">
                    <div
                        class="p-6 pb-1 flex items-center justify-between hover: transition duration-300 ease-in-out rounded-lg cursor-pointer">
                        <div class="text-lg font-bold">
                            <p class="text-gray-600 font-medium">Active Products</p>
                            <p class="text-4xl font-semibold text-gray-800"><?php echo e($activeProducts->count() ?? 0); ?></p>
                        </div>
                        <i
                            class="fas fa-box text-blue-300 text-6xl transform hover:scale-110 transition-transform duration-300"></i>
                    </div>
                    <hr class="my-2 border-gray-300 w-full p-0">
                    <div class="py-1 mb-1 px-4 text-center flex items-center justify-end space-x-2">
                        <a href="<?php echo e(route('products.index')); ?>"
                            class="text-blue-600 font-medium hover:underline flex items-center"
                            style="text-decoration: none;">
                            More Info <i class="fas fa-arrow-circle-right text-blue-500 text-lg ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Total Orders Card -->
            <div class="bg-white shadow-md rounded-lg relative overflow-hidden">
                <div class="bg-blue-500 text-white p-4 rounded-t-lg flex items-center">
                    <h3 class="text-lg font-bold flex items-center">
                        <i class="fas fa-user mr-2 text-xl"></i> Total Orders
                    </h3>
                </div>
                <div class="pb-0">
                    <div
                        class="p-6 pb-1 flex items-center justify-between hover: transition duration-300 ease-in-out rounded-lg cursor-pointer">
                        <div class="text-lg font-bold">
                            <p class="text-gray-600 font-medium">All Orders</p>
                            <p class="text-4xl font-semibold text-gray-800"><?php echo e($activeorders->count() ?? 0); ?></p>
                        </div>
                        <i
                            class="fa-solid fa-cube text-blue-300 text-6xl transform hover:scale-110 transition-transform duration-300"></i>
                    </div>
                    <hr class="my-2 border-gray-300 w-full p-0">
                    <div class="py-1 mb-1 px-4 text-center flex items-center justify-end space-x-2">
                        <a href="<?php echo e(route('order.index')); ?>"
                            class="text-blue-600 font-medium hover:underline flex items-center"
                            style="text-decoration: none;">
                            More Info <i class="fas fa-arrow-circle-right text-blue-500 text-lg ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Notification Button and Modal -->
    <div class="relative fixed bottom-10 right-5 z-50">
        <!-- Notification Button (fixed at bottom-right) -->
        <a href="#" class="relative fixed bottom-10 z-50" onclick="toggleNotificationPanel(event)"
            style="right:15px; position: fixed;">
            <i
                class="fas fa-bell bg-black text-white p-3 rounded-md shadow-md hover:bg-gray-700 transition-all duration-200 ease-in-out"></i>
            <?php if($unreadCount > 0): ?>
                <span
                    class="absolute right-0 inline-flex items-center justify-center w-4 h-4 text-xs font-semibold text-white bg-red-600 rounded-full transform translate-x-1 translate-y-1"
                    style="top:-10px;">
                    <?php echo e($unreadCount); ?>

                </span>
            <?php endif; ?>
        </a>

        <!-- Modal for Notification Panel -->
        <div id="notificationModal"
            class="hidden fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center z-50 transition-all transform scale-100">
            <div
                class="bg-white w-96 rounded-lg shadow-xl max-h-[80vh] overflow-y-auto transform scale-95 origin-top transition-transform duration-200 ease-in-out p-0 relative">

                <!-- Header of Notification Panel -->
                <div class="sticky top-0 w-full bg-white z-10 border-0 py-4">
                    <div class="flex items-center justify-between p-4">
                        <h4 class="font-semibold text-xl text-gray-800 flex items-center space-x-2">
                            <i class="fas fa-bell text-blue-500"></i>
                            <span>New Notifications</span>
                        </h4>
                        <!-- Close Button -->
                        <button class="text-gray-600 hover:text-gray-800 focus:outline-none"
                            onclick="toggleNotificationPanel(event)">
                            <i class="fas fa-times text-2xl"></i>
                        </button>
                    </div>
                </div>

                <!-- Notification List -->
                <div class="space-y-4">
                    <!-- Unread Notifications Section -->
                    <div>
                        <h2 class="text-xl font-semibold text-gray-800 mb-3">Unread Notifications</h2>
                        <ul class="space-y-4" id="unreadNotifications">
                            <?php $__currentLoopData = $contactUsSubmissions->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Only take 10 notifications -->
                                <?php if(!$submission->read): ?>
                                    <li
                                        class="p-4 border-b border-gray-200 bg-white hover:bg-gray-50 transition-colors duration-200 ease-in-out rounded-md shadow-md">
                                        <div class="flex items-start space-x-3">
                                            <i class="fas fa-info-circle text-blue-500 text-xl"></i>
                                            <div class="flex-1">
                                                <div class="flex justify-between items-center">
                                                    <div>
                                                        <strong
                                                            class="text-gray-800 text-lg"><?php echo e($submission->name); ?></strong>
                                                        <span
                                                            class="text-sm text-gray-500">(<?php echo e($submission->email); ?>)</span>
                                                    </div>
                                                    <form
                                                        action="<?php echo e(route('contact-msg.mark-as-read', $submission->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit"
                                                            class="text-sm text-blue-500 hover:text-blue-700 font-medium">
                                                            <i class="fas fa-check-circle mr-1"></i> Mark as Read
                                                        </button>
                                                    </form>
                                                </div>
                                                <div class="mt-2 text-sm text-gray-600">
                                                    <p><?php echo e(Str::limit($submission->message, 80)); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <!-- See More Button -->
                        <div class="text-center mt-4">
                            <a href="<?php echo e(route('inbox')); ?>" class="text-blue-500 hover:text-blue-700 font-medium">See
                                More</a>
                        </div>
                    </div>

                    <!-- Clear All and Mark All as Read Button (Footer) -->
                    <div class="flex justify-between mt-4 p-4 border-t border-gray-200 bg-gray-50">
                        <button class="text-sm text-blue-500 hover:text-blue-700 font-medium" id="markAllAsReadBtn">Mark
                            All as Read</button>
                        <button class="text-sm text-red-500 hover:text-red-700 font-medium" id="clearAllBtn">Clear
                            All</button>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php if(session('success')): ?>
        <div id="toastSuccess"
            class="fixed top-2 left-1/2 transform -translate-x-1/2 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 opacity-0 translate-y-[-20px] transition-all duration-500 ease-out text-center">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div id="toastError"
            class="fixed top-2 left-1/2 transform -translate-x-1/2 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 opacity-0 translate-y-[-20px] transition-all duration-500 ease-out">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>

    <script>
        function showToast(toastId) {
            let toast = document.querySelector(toastId);
            if (toast) {
                setTimeout(() => {
                    toast.classList.remove('opacity-0', 'translate-y-[-20px]');
                    toast.classList.add('opacity-100', 'translate-y-0');
                }, 10);

                setTimeout(() => {
                    toast.classList.remove('opacity-100', 'translate-y-0');
                    toast.classList.add('opacity-0', 'translate-y-[-20px]');
                }, 4000);
            }
        }

        <?php if(session('success')): ?>
            showToast('#toastSuccess');
        <?php endif; ?>

        <?php if(session('error')): ?>
            showToast('#toastError');
        <?php endif; ?>
    </script>

    <!-- JavaScript for Toggle Effect -->
    <script>
        function toggleNotificationPanel(event) {
            event.preventDefault();
            const panel = document.getElementById('notificationModal');

            // Toggle modal visibility and apply transition
            if (panel.classList.contains('hidden')) {
                panel.classList.remove('hidden');
                panel.classList.add('scale-100', 'transform', 'transition-transform', 'duration-200', 'ease-in-out');
            } else {
                panel.classList.add('hidden');
                panel.classList.remove('scale-100', 'transform', 'transition-transform', 'duration-200', 'ease-in-out');
            }
        }
    </script>
    <!-- Mark All as Read JS -->
    <script>
        document.getElementById('markAllAsReadBtn').addEventListener('click', function() {
            if (confirm('Are you sure you want to mark all notifications as read?')) {
                // Send a request to mark all notifications as read
                fetch('<?php echo e(route('contact-msg.mark-all-as-read')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    },
                }).then(response => {
                    if (response.ok) {
                        location.reload(); // Reload the page to reflect the changes
                    }
                });
            }
        });

        // Clear All Notifications
        document.getElementById('clearAllBtn').addEventListener('click', function() {
            if (confirm('Are you sure you want to clear all notifications?')) {
                // Send a request to clear all notifications
                fetch('<?php echo e(route('contact-msg.clear-all')); ?>', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    },
                }).then(response => {
                    if (response.ok) {
                        location.reload(); // Reload the page to reflect the changes
                    }
                });
            }
        });
    </script>

    <?php $__env->startPush('scripts'); ?>
        <script>
            window.onload = function() {
                setTimeout(() => {
                    document.getElementById('loader').style.display = 'none';
                }, 400);
            }
        </script>
    <?php $__env->stopPush(); ?>
    <!-- Custom Scrollbar Styling -->
    <style>
        /* Scrollbar styling */
        #notificationModal .overflow-y-auto {
            scrollbar-width: thin;
            scrollbar-color: #4B5563 #F3F4F6;
        }

        /* Webkit scrollbars for Chrome, Safari, and Edge */
        #notificationModal .overflow-y-auto::-webkit-scrollbar {
            width: 8px;
        }

        #notificationModal .overflow-y-auto::-webkit-scrollbar-thumb {
            background-color: #4B5563;
            border-radius: 10px;
        }

        #notificationModal .overflow-y-auto::-webkit-scrollbar-track {
            background: #F3F4F6;
            border-radius: 10px;
        }

        /* Button Styles */
        .btn-mark-read {
            @apply bg-blue-500 text-white font-semibold px-4 py-2 rounded-lg hover:bg-blue-600 focus:outline-none transition-all duration-200 ease-in-out;
        }

        .btn-mark-read i {
            @apply text-white;
        }

        /* Hover effects for List Items */
        li:hover {
            @apply bg-gray-50 cursor-pointer;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Desktop/laravel-auth-app/resources/views/dashboard.blade.php ENDPATH**/ ?>