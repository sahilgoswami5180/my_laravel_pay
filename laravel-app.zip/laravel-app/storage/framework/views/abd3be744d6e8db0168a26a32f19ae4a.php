<?php $__env->startSection('title', 'Product Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-8">
    <div class="bg-white shadow-lg rounded-lg p-8 mb-8">
        <!-- Title and Back Button -->
        <div class="flex items-center justify-between mb-4">
            <div>
                <h6 class="text-xl font-semibold">
                    <a href="<?php echo e(route('products.index')); ?>" class="mr-2 text-blue-800 hover:text-blue-600" id="goBackLink">
                        <i class="fa-solid fa-arrow-left-long"></i>
                    </a>
                    <?php echo e($product->name); ?>

                </h6>
            </div>
        </div>

        <!-- Product Information Section -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Product Image -->
            <div class="bg-white shadow-lg rounded-lg p-6 flex justify-center items-center">
                <?php if($product->image): ?>
                    <div class="max-w-sm w-full">
                        <a href="<?php echo e(asset('storage/' . $product->image)); ?>" data-fancybox="images" data-caption="<?php echo e($product->name); ?>">
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="zoomable rounded-lg shadow-lg max-w-full h-auto object-cover max-h-[400px] mx-auto">
                        </a>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500">No image available</p>
                <?php endif; ?>
            </div>

            <!-- Product Details -->
            <div class="bg-white shadow-lg rounded-lg p-6">
                <table class="min-w-full table-auto">
                    <tbody>
                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Product Name</th>
                            <td class="py-2 px-4"><?php echo e($product->name); ?></td>
                        </tr>

                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Category</th>
                            <td class="py-2 px-4"><?php echo e($product->category->name); ?></td>
                        </tr>
                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Price</th>
                            <td class="py-2 px-4 text-xl font-semibold text-gray-900">₹<?php echo e(number_format($product->price, 2)); ?></td>
                        </tr>

                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Description</th>
                            <td class="py-2 px-4"><?php echo e($product->description); ?></td>
                        </tr>
                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Created At</th>
                            <td class="py-2 px-4"><?php echo e($product->created_at->format('Y-m-d H:i:s')); ?></td>
                        </tr>
                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Updated At</th>
                            <td class="py-2 px-4"><?php echo e($product->updated_at->format('Y-m-d H:i:s')); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="flex justify-center space-x-4 mt-8">
            <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary px-6 py-3 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200 ease-in-out">
                <i class="fa-solid fa-pencil"></i> Edit
            </a>
            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="inline-block">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger px-6 py-3 bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 focus:ring-4 focus:ring-red-300 transition duration-200 ease-in-out"
                    onclick="return confirm('Are you sure you want to delete this item?')">
                    <i class="fas fa-trash-alt"></i> Delete
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Fancybox setup for image zoom
            $('[data-fancybox="images"]').fancybox({
                buttons: [
                    'zoom',
                    'slideShow',
                    'thumbs',
                    'close'
                ],
                loop: true,
                protect: true
            });

            // Back button functionality
            const goBackLink = document.getElementById('goBackLink');
            if (goBackLink) {
                goBackLink.addEventListener('click', function(event) {
                    event.preventDefault();
                    history.back();
                });
            }
        });
    </script>

    <style>
        /* CSS for zoom effect */
        .zoomable {
            transition: transform 0.3s ease-in;
        }

        .zoomable:hover {
            cursor: zoom-in;
            transform: scale(1.1);
        }

        .zoomable:active {
            transform: scale(1.2);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/products/show.blade.php ENDPATH**/ ?>