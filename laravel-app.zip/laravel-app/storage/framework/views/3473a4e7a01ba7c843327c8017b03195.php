<div class="w-64 bg-gradient-to-b from-blue-600 to-blue-800 text-white p-4 shadow-lg">
    <div class="flex flex-col items-center mb-4">
        <span class="font-semibold text-xl">Dashboard</span>
        <div class="text-center">
            <span class="text-gray-300 text-sm" id="last-login-time" style="font-size: 11px;"></span>
        </div>
    </div>
    <hr class="w-full border-gray-700 my-1 mb-6">
    <ul class="space-y-6">
        <!-- Dashboard Link -->
        <li>
            <a href="<?php echo e('/dashboard'); ?>" class="flex items-center text-lg font-semibold hover:text-blue-200 transition duration-300 ease-in-out transform hover:scale-105">
                <i class="fas fa-tachometer-alt w-6 h-6 mr-3"></i> Dashboard
            </a>
        </li>

        <!-- Categories Dropdown -->
        <li>
            <button class="flex items-center w-full text-lg font-semibold hover:text-blue-200 focus:outline-none transition duration-300 ease-in-out transform hover:scale-105" id="categoriesDropdownToggle">
                <i class="fas fa-list w-6 h-6 mr-3"></i> Categories
                <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200" id="categoriesDropdownArrow"></i>
            </button>
            <ul class="space-y-2 mt-2 pl-6 hidden" id="categoriesDropdown">
                <li><a href="<?php echo e('categories'); ?>" class="text-gray-200 hover:text-white transition duration-200">View Categories</a></li>
                <li><a href="<?php echo e('categories/create'); ?>" class="text-gray-200 hover:text-white transition duration-200">Add New Category</a></li>
            </ul>
        </li>

        <!-- Settings -->
        <li>
            <a href="#" class="flex items-center text-lg font-semibold hover:text-blue-200 transition duration-300 ease-in-out transform hover:scale-105">
                <i class="fas fa-cogs w-6 h-6 mr-3"></i> Settings
            </a>
        </li>
    </ul>
</div>
<?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views//sidebar.blade.php ENDPATH**/ ?>