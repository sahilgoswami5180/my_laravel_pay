<?php $__env->startSection('content'); ?>
    <div class="bg-gray-100 flex items-center justify-center">
        <div class="bg-white shadow-md rounded-lg p-6 w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-4">Change Password</h2>

            <form action="<?php echo e(route('change-password.update')); ?>" method="POST" class="space-y-4">
                <?php echo csrf_field(); ?>

                <!-- Current Password -->
                <div class="relative">
                    <label for="current_password" class="block text-gray-700 font-medium mb-1">
                        Current Password <span class="text-red-600">*</span>
                    </label>
                    <input type="password" name="current_password" id="current_password"
                        class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500
                            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Enter your current password">
                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- New Password -->
                <div class="relative">
                    <label for="new_password" class="block text-gray-700 font-medium mb-1">
                        New Password <span class="text-red-600">*</span>
                    </label>
                    <input type="password" name="new_password" id="new_password" value="<?php echo e(old('new_password')); ?>"
                        class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500
                            <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Enter your new password">
                    <span id="toggle-new-password"
                        class="absolute right-3 transform -translate-y-1/2 cursor-pointer text-gray-500" style="top: 50px;"
                        onclick="togglePassword('new_password', 'new_password_icon')">
                        <i id="new_password_icon" class="fas fa-eye"></i>
                    </span>
                    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Confirm New Password -->
                <div class="relative">
                    <label for="new_password_confirmation" class="block text-gray-700 font-medium mb-1">
                        Confirm New Password
                    </label>
                    <input type="password" name="new_password_confirmation" id="new_password_confirmation"
                        value="<?php echo e(old('new_password_confirmation')); ?>"
                        class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Confirm your new password">
                    <span id="toggle-confirm-password"
                        class="absolute right-3 transform -translate-y-1/2 cursor-pointer text-gray-500" style="top: 50px;"
                        onclick="togglePassword('new_password_confirmation', 'confirm_password_icon')">
                        <i id="confirm_password_icon" class="fas fa-eye"></i>
                    </span>
                </div>

                <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition">
                    Change Password
                </button>
            </form>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Success Icon -->
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <!-- Success Message -->
            <span><?php echo e(session('success')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <!-- Error Toast -->
    <?php if(session('error')): ?>
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Error Icon -->
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <!-- Error Message -->
            <span><?php echo e(session('error')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <!-- Include Toastr CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">

    <!-- Include Toastr JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        function togglePassword(inputId, iconId) {
            const passwordField = document.getElementById(inputId);
            const passwordIcon = document.getElementById(iconId);

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.classList.remove('fa-eye');
                passwordIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordIcon.classList.remove('fa-eye-slash');
                passwordIcon.classList.add('fa-eye');
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/user/change-password.blade.php ENDPATH**/ ?>