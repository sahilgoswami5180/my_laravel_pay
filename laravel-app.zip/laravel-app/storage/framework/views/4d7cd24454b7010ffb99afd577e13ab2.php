<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.js" defer></script>

    <?php echo $__env->yieldPushContent('head'); ?> <!-- For any additional head content -->
</head>

<body class="bg-gray-50 flex flex-col m-0 p-0 min-h-screen">
    <!-- Navbar -->
    <nav class="navbar bg-white shadow-md sticky top-0 z-50 py-4 px-4 lg:px-0">
        <div class="container mx-auto flex justify-between items-center">
            <!-- Brand Logo -->
            <h1 class="text-2xl md:text-3xl font-bold text-gray-800">BrandLogo</h1>

            <!-- Mobile Hamburger, Search, and Cart -->
            <div class="lg:hidden flex items-center space-x-4" id="mobile-nav" x-data="{ openMenu: false, openSearch: false }">
                <!-- Search Icon -->
                <button id="search-toggle" class="text-gray-600 text-2xl">
                    <i class="fas fa-search"></i>
                </button>

                <!-- Cart Icon (between search and hamburger) -->
                <a href="<?php echo e(route('user.cart')); ?>" class="text-gray-600 text-2xl relative">
                    <i class="fas fa-shopping-bag"></i>
                    <!-- Cart Item Count Badge -->
                    <?php if(Auth::check()): ?>
                        <?php
                            $cartCount = App\Models\CartItem::where('user_id', Auth::id())->sum('quantity');
                        ?>
                        <span
                            class="absolute top-0 right-0 -mr-3 -mt-2 inline-flex items-center justify-center w-4 h-4 text-xs font-semibold text-white bg-red-600 rounded-full">
                            <?php echo e($cartCount > 0 ? $cartCount : 0); ?>

                        </span>
                    <?php endif; ?>
                </a>

                <!-- Hamburger Icon -->
                <button id="hamburger-toggle" class="text-gray-600 text-2xl">
                    <i class="fas fa-bars"></i>
                </button>
            </div>

            <!-- Full Search Bar for Desktop and Expandable Search for Mobile -->
            <form id="search-form" action="<?php echo e(route('user.search')); ?>" method="GET"
                class="hidden lg:flex flex-grow mx-4 justify-center" autocomplete="off">
                <div class="relative w-full max-w-lg">
                    <input type="text" id="search-input" name="search"
                        class="px-4 py-2 pl-10 pr-4 border-2 border-gray-300 rounded-l-md w-full"
                        placeholder="Search products..." value="<?php echo e(request('search')); ?>">
                    <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                </div>
                <button type="submit" id="search-btn"
                    class="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 transition">
                    <i class="fas fa-search"></i>
                </button>
            </form>

            <!-- Navbar Links -->
            <div class="hidden lg:flex items-center space-x-6">
                <a href="<?php echo e(route('user.index')); ?>" class="text-gray-700 hover:text-blue-500">Home</a>
                <a href="<?php echo e(route('user.contact-us')); ?>" class="text-gray-700 hover:text-blue-500">Contact Us</a>

                <!-- Profile Dropdown -->
                <?php if(auth()->guard()->check()): ?>
                    <div x-data="{ open: false }" class="relative">
                        <button @click="open = !open" class="flex items-center space-x-2 text-gray-700 hover:text-blue-500">
                            <img id="profileImagePreview"
                                src="<?php echo e(asset('storage/' . (Auth::user()->profile_image ?? 'profile_images/Profile.png'))); ?>"
                                alt="Profile Picture"
                                class="w-8 h-8 rounded-full object-cover border-2 border-white shadow-lg">
                            <p class="hidden md:block"><?php echo e(Auth::user()->name); ?></p>
                            <i class="fas fa-chevron-down w-5 h-5 transform transition-transform duration-200"></i>
                        </button>
                        <ul x-show="open" @click.away="open = false" x-transition
                            class="absolute right-0 w-48 bg-white shadow-lg rounded-lg" style="margin-top: 25px;">
                            <li>
                                <a href="<?php echo e(route('userprofile')); ?>"
                                    class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                    <i class="fas fa-user ml-2"></i><span class="pl-2">My Profile</span>
                                </a>
                            </li>
                            <hr>
                            <li class="flex justify-center items-center">
                                <button onclick="openLogoutModal()"
                                    class="bg-red-600 px-8 py-1 m-2 rounded hover:bg-red-700 text-white text-lg font-semibold flex items-center">
                                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                                </button>
                                <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden"><?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-gray-700 hover:text-blue-500">Login</a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Search Bar for Mobile (Initially Hidden) -->
        <div id="search-bar" class="hidden bg-white shadow-md py-2 px-4 lg:hidden">
            <form id="search-form-mobile" action="<?php echo e(route('user.search')); ?>" method="GET" autocomplete="off"
                class="flex items-center space-x-4 w-full">
                <input type="text" id="search-input-mobile" name="search"
                    class="px-4 py-2 border-2 border-gray-300 rounded-l-md w-full" placeholder="Search products..."
                    value="<?php echo e(request('search')); ?>">
                <button type="submit" id="search-btn"
                    class="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 transition">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>

        <!-- Mobile Menu (full-screen from right) -->
        <div id="mobile-menu"
            class="lg:hidden fixed inset-0 bg-white z-50 transform translate-x-full transition-all duration-500">
            <div class="flex justify-end p-4">
                <button id="hamburger-close" class="text-2xl text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="flex flex-col items-center justify-center h-full space-y-8">
                <a href="<?php echo e(route('user.index')); ?>" class="text-xl text-gray-700 hover:text-blue-500">Home</a>
                <a href="<?php echo e(route('user.contact-us')); ?>" class="text-xl text-gray-700 hover:text-blue-500">Contact
                    Us</a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('userprofile')); ?>" class="text-xl text-gray-700 hover:text-blue-500">My Profile</a>
                    <li class="flex justify-center items-center">
                        <button type="button"
                            class="bg-red-600 px-8 py-1 m-2 rounded hover:bg-red-700 text-white text-lg font-semibold flex items-center"
                            onclick="document.getElementById('logoutForm').submit();">
                            <i class="fas fa-sign-out-alt mr-2"></i> Logout
                        </button>

                        <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                            <?php echo csrf_field(); ?>
                        </form>

                    </li>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-xl text-gray-700 hover:text-blue-500">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-content flex flex-col w-full">
        <main class="py-6 px-4 overflow-auto">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <!-- Footer -->
    <footer class="bg-gradient-to-r from-gray-600 to-gray-700 text-white py-4 mt-auto">
        <div class="container mx-auto text-center">
            <p>&copy; <?php echo e(date('Y')); ?> Your Company. All rights reserved.</p>
            <div class="mt-4">
                <a href="#" class="text-gray-400 mx-2">
                    <i class="fab fa-facebook-square text-2xl"></i>
                </a>
                <a href="#" class="text-gray-400 mx-2">
                    <i class="fab fa-twitter-square text-2xl"></i>
                </a>
                <a href="#" class="text-gray-400 mx-2">
                    <i class="fab fa-instagram-square text-2xl"></i>
                </a>
            </div>
        </div>
    </footer>
    <!-- Logout Confirmation Modal -->
    <div id="logout-modal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-4 rounded-lg shadow-lg w-full max-w-xl">
            <div class="flex items-center mb-4">
                <i class="fas fa-exclamation-circle text-red-600 text-3xl mr-4"></i>
                <h2 class="text-xl font-semibold text-gray-800">Are you sure you want to log out?</h2>
            </div>
            <p class="text-gray-700 mb-4 text-center">If you log out, you will need to sign in again to continue using
                the application.</p>
            <div class="flex justify-end gap-4 mt-6">
                <button onclick="closeLogoutModal()"
                    class="flex items-center justify-center px-6 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition duration-300">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </button>
                <button onclick="document.getElementById('logoutForm').submit();"
                    class="flex items-center justify-center px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-300">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Menu Script -->
    <script>
        const hamburgerToggle = document.getElementById('hamburger-toggle');
        const hamburgerClose = document.getElementById('hamburger-close');
        const mobileMenu = document.getElementById('mobile-menu');
        const searchToggle = document.getElementById('search-toggle');
        const searchBar = document.getElementById('search-bar');

        hamburgerToggle.addEventListener('click', () => {
            mobileMenu.classList.remove('translate-x-full');
            mobileMenu.classList.add('translate-x-0');
        });

        hamburgerClose.addEventListener('click', () => {
            mobileMenu.classList.add('translate-x-full');
            mobileMenu.classList.remove('translate-x-0');
        });

        searchToggle.addEventListener('click', () => {
            searchBar.classList.toggle('hidden');
        });

        function openLogoutModal() {
            document.getElementById('logout-modal').classList.remove('hidden');
        }

        function closeLogoutModal() {
            document.getElementById('logout-modal').classList.add('hidden');
        }
    </script>
</body>

</html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/layouts/user.blade.php ENDPATH**/ ?>