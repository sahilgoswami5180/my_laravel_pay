<?php $__env->startSection('content'); ?>
    <div class="flex items-start justify-center" style="height: 60vh;">
        <div class="bg-white shadow-lg rounded-lg p-10 w-full" style="height: 500px;">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Profile</h2>

            <?php if(session('success')): ?>
                <div id="successToast"
                    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-check-circle text-white text-2xl"></i>
                    <span><?php echo e(session('success')); ?></span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#successToast').style.display = 'none';
                    }, 4000);
                </script>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div id="errorToast"
                    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-times-circle text-white text-2xl"></i>
                    <span><?php echo e(session('error')); ?></span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#errorToast').style.display = 'none';
                    }, 4000);
                </script>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Profile Image and Form -->
                <div>
                    <div class="flex justify-center mb-8">
                        <img id="profileImagePreview"
                            src="<?php echo e(asset('storage/' . ($user->profile_image ?? 'profile_images/Profile.png'))); ?>"
                            alt="Profile Picture"
                            class="w-32 h-32 rounded-full object-cover border-4 border-indigo-500 shadow-lg">
                    </div>

                    <form action="<?php echo e(route('profile.update.image')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> <!-- Use PUT for updating data -->

                        <div class="mb-6 text-center">
                            <label for="profile_image" class="block text-gray-700 font-medium mb-2">Update Profile
                                Image</label>

                            <!-- Flex container for input and button -->
                            <div class="flex items-center space-x-2">
                                <!-- File Input -->
                                <input type="file" name="profile_image" id="profile_image"
                                    class="w-full bg-indigo-500 sm:w-auto p-2 border rounded-lg"
                                    onchange="previewImage(event)">

                                <!-- Submit Button -->
                                <button type="submit"
                                    class="bg-indigo-500 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 transition duration-300 ease-in-out">
                                    <i class="fa-solid fa-floppy-disk"></i> </button>
                            </div>

                            <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red-500 text-sm mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </form>

                </div>

                <!-- User Details -->
                <div>
                    <div class="space-y-6">
                        <div class="flex justify-between">
                            <label for="name" class="text-gray-700 font-medium">Name</label>
                            <div class="text-gray-800"><?php echo e($user->name); ?></div>
                        </div>

                        <div class="flex justify-between">
                            <label for="email" class="text-gray-700 font-medium">Email</label>
                            <div class="text-gray-800" id="emailSection">
                                <!-- Initially display partial email and hide full email -->
                                <span
                                    id="maskedEmail"><?php echo e(substr($user->email, 0, 3)); ?>XXX<?php echo e(substr($user->email, 6)); ?></span>
                                <span id="fullEmail" style="display:none;"><?php echo e($user->email); ?></span>
                                <i class="fas fa-eye" id="toggleEmail" style="cursor: pointer;"></i>
                            </div>
                        </div>

                        <div class="flex justify-between">
                            <label for="email" class="text-gray-700 font-medium">Mobile Number</label>
                            <div class="text-gray-800" id="mobileNumberSection">
                                <!-- Initially display partial number and hide full number -->
                                <span
                                    id="maskedNumber"><?php echo e(substr($user->mobile_number, 0, 7)); ?>XXX<?php echo e(substr($user->mobile_number, 10, 15)); ?></span>
                                <span id="fullNumber" style="display:none;"><?php echo e($user->mobile_number); ?></span>
                                <i class="fas fa-eye" id="toggleMobileNumber" style="cursor: pointer;"></i>
                            </div>
                        </div>

                        <div class="flex justify-between">
                            <label for="created_at" class="text-gray-700 font-medium">Joined</label>
                            <div class="text-gray-800"><?php echo e($user->created_at->format('F j, Y')); ?></div>
                        </div>
                    </div>

                    <!-- Buttons Section -->
                    <div class="mt-8 flex justify-between gap-4">
                        <a href="<?php echo e(route('dashboard')); ?>"
                            class="w-full md:w-auto bg-gray-300 text-gray-700 px-6 py-3 rounded-lg text-center hover:bg-gray-400 transition duration-300 ease-in-out">
                            Back to Dashboard
                        </a>
                        <a href="<?php echo e(route('change-password.form')); ?>"
                            class="w-full md:w-auto bg-indigo-500 text-white px-6 py-3 rounded-lg text-center hover:bg-indigo-600 transition duration-300 ease-in-out">
                            Change Password
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Function to preview the selected image
        function previewImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function(e) {
                const preview = document.getElementById('profileImagePreview');
                preview.src = e.target.result; // Set the source to the selected file's data URL
            }

            if (file) {
                reader.readAsDataURL(file); // Read the file as a Data URL
            } else {
                // If no file is selected, set the default image again
                document.getElementById('profileImagePreview').src =
                    '<?php echo e(asset('storage/' . ($user->profile_image ?? 'profile_images/Profile.png'))); ?>';
            }
        }

        // JavaScript for toggling mobile number visibility
        document.getElementById("toggleMobileNumber").addEventListener("click", function() {
            var maskedNumber = document.getElementById("maskedNumber");
            var fullNumber = document.getElementById("fullNumber");

            // Toggle visibility of the full mobile number
            if (fullNumber.style.display === "none") {
                fullNumber.style.display = "inline"; // Show full number
                maskedNumber.style.display = "none"; // Hide masked number
            } else {
                fullNumber.style.display = "none"; // Hide full number
                maskedNumber.style.display = "inline"; // Show masked number
            }
        });

        // JavaScript for toggling email visibility
        document.getElementById("toggleEmail").addEventListener("click", function() {
            var maskedEmail = document.getElementById("maskedEmail");
            var fullEmail = document.getElementById("fullEmail");

            // Toggle visibility of the full email
            if (fullEmail.style.display === "none") {
                fullEmail.style.display = "inline"; // Show full email
                maskedEmail.style.display = "none"; // Hide masked email
            } else {
                fullEmail.style.display = "none"; // Hide full email
                maskedEmail.style.display = "inline"; // Show masked email
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/auth/profile.blade.php ENDPATH**/ ?>