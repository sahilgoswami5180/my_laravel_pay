<?php $__env->startSection('title', 'Create Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-0">

    <!-- Breadcrumb Navigation -->
    <nav class="flex text-sm text-gray-600 mb-6 items-center">
        <a href="<?php echo e(route('dashboard')); ?>"
            class="flex items-center <?php echo e(Request::is('dashboard') ? 'text-blue-500' : ''); ?>">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <a href="<?php echo e(route('products.index')); ?>"
            class="flex items-center <?php echo e(Request::is('products') || Request::is('products/*') ? 'text-blue-500' : ''); ?>">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Products</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <span class="text-xs text-gray-500">Create</span>
    </nav>

    <!-- Full-Screen Width Card Container for the Form -->
    <div class="w-full bg-white p-8 rounded-lg shadow-xl">

        <!-- Flex container to align Button and Page Title -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-semibold text-gray-800"><i class="fas fa-plus-circle mr-2"></i> Add New Product
            </h2>
        </div>

        <!-- Form to Create Product -->
        <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>

            <!-- Flex container for category and subcategory -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- Product Category -->
                <div>
                    <label for="category_id" class="block text-sm font-medium text-gray-700">Category <span class="text-red-500">*</span></label>
                    <select name="category_id" id="category_id" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Product Subcategory (Based on Category) -->
                <div>
                    <label for="subcategory_id" class="block text-sm font-medium text-gray-700">Subcategory <span class="text-red-500">*</span></label>
                    <select name="subcategory_id" id="subcategory_id" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Select Subcategory</option>
                    </select>
                    <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Flex container for product name and price -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <!-- Product Name -->
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700">Product Name <span class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-tag absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Product Price -->
                <div>
                    <label for="price" class="block text-sm font-medium text-gray-700">Product Price <span class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="number" name="price" id="price" value="<?php echo e(old('price')); ?>" step="0.01" min="0" class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-dollar-sign absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Product Prices with Serving Sizes Section -->
            <div class="mb-6">
                <label for="prices" class="block text-sm font-medium text-gray-700">Product Prices with Serving Sizes</label>
                <div id="prices-container">
                    <div class="flex items-center mb-4">
                        <input type="number" name="prices[0][price]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md" placeholder="Price" step="0.01" min="0">
                        <input type="text" name="prices[0][serving_size]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md ml-4" placeholder="Serving Size">
                        <button type="button" class="remove-price-btn text-red-500 ml-2">Remove</button>
                    </div>
                </div>
                <button type="button" id="add-price-btn" class="bg-blue-500 text-white px-4 py-2 rounded">Add Another Price</button>
            </div>

            <!-- Product Description -->
            <div class="mb-6">
                <label for="description" class="block text-sm font-medium text-gray-700">Product Description <span class="text-red-500">*</span></label>
                <div class="relative">
                    <textarea name="description" id="description" rows="4" maxlength="255" oninput="updateCharCount()" class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e(old('description')); ?></textarea>
                    <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
                <div class="flex justify-end text-sm text-gray-500 mt-1">
                    <span id="charCount">0</span> / 255
                </div>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Product Image -->
            <div class="mb-6">
                <label for="images" class="block text-sm font-medium text-gray-700">Product Images</label>
                <input type="file" name="images[]" id="images" accept="image/*" multiple class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Product Status -->
            <div class="mb-6">
                <label for="status" class="block text-sm font-medium text-gray-700">Product Status <span class="text-red-500">*</span></label>
                <select name="status" id="status" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="" disabled <?php echo e(old('status') ? '' : 'selected'); ?>>Please choose a status</option>
                    <option value="active" <?php echo e(old('status', 'active') == 'active' ? '' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e(old('status', 'inactive') == 'inactive' ? '' : 'selected'); ?>>Inactive</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end space-x-4">
                <a href="<?php echo e(route('products.index')); ?>" class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </a>
                <button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                    <i class="fas fa-check-circle mr-2"></i> Create Product
                </button>
            </div>
        </form>

    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        let priceIndex = 1;

        // Add price input field
        document.getElementById('add-price-btn').addEventListener('click', function() {
            const container = document.getElementById('prices-container');
            const newPriceField = document.createElement('div');
            newPriceField.classList.add('flex', 'items-center', 'mb-4');
            newPriceField.innerHTML = `
                <input type="number" name="prices[${priceIndex}][price]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md" placeholder="Price" step="0.01" min="0">
                <input type="text" name="prices[${priceIndex}][serving_size]" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md ml-4" placeholder="Serving Size">
                <button type="button" class="remove-price-btn text-red-500 ml-2">Remove</button>
            `;
            container.appendChild(newPriceField);
            priceIndex++;
        });

        // Remove price input field
        document.getElementById('prices-container').addEventListener('click', function(event) {
            if (event.target.classList.contains('remove-price-btn')) {
                event.target.closest('.flex').remove();
            }
        });

        // Form submission validation
        document.querySelector('form').addEventListener('submit', function(event) {
            const servingSizes = [];
            const priceInputs = document.querySelectorAll('input[name^="prices["][name$="serving_size"]');
            priceInputs.forEach(input => {
                if (servingSizes.includes(input.value)) {
                    event.preventDefault();
                    alert("This serving size already exists.");
                }
                servingSizes.push(input.value);
            });
        });
    });
</script>

<script>
    // When the category changes, make an AJAX call to get the subcategories
    document.getElementById('category_id').addEventListener('change', function() {
        const categoryId = this.value;
        const subcategoryDropdown = document.getElementById('subcategory_id');

        // Clear previous subcategory options
        subcategoryDropdown.innerHTML = '<option value="">Select Subcategory</option>';

        if (categoryId) {
            // Make an AJAX request to fetch subcategories based on the selected category
            fetch(`/get-subcategories/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    // Check if subcategories are available
                    if (data.length > 0) {
                        data.forEach(subcategory => {
                            const option = document.createElement('option');
                            option.value = subcategory.id;
                            option.textContent = subcategory.name;
                            subcategoryDropdown.appendChild(option);
                        });
                    } else {
                        // If no subcategories are available
                        const option = document.createElement('option');
                        option.value = '';
                        option.textContent = 'No subcategories available';
                        subcategoryDropdown.appendChild(option);
                    }
                })
                .catch(error => {
                    console.error('Error fetching subcategories:', error);
                });
        }
    });

    // Character Counter
    function updateCharCount() {
        const description = document.getElementById('description');
        const charCount = document.getElementById('charCount');
        charCount.textContent = description.value.length;
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Documents/laravel-auth-app/resources/views/products/create.blade.php ENDPATH**/ ?>