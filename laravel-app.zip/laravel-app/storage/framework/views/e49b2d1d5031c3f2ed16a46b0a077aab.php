<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Profile</h2>

            <?php if(session('success')): ?>
                <div id="successToast"
                    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-check-circle text-white text-2xl"></i>
                    <span><?php echo e(session('success')); ?></span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#successToast').style.display = 'none';
                    }, 4000);
                </script>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div id="errorToast"
                    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-times-circle text-white text-2xl"></i>
                    <span><?php echo e(session('error')); ?></span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#errorToast').style.display = 'none';
                    }, 4000);
                </script>
            <?php endif; ?>

            <!-- Profile Image Update Form -->
            <form action="<?php echo e(route('profile.update.userimage')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Merged Image Preview and File Input -->
                <div class="relative flex justify-center mb-8">
                    <!-- Profile Image Preview -->
                    <img id="profileImagePreview"
                        src="<?php echo e(asset('storage/' . ($user->profile_image ?? 'profile_images/Profile.png'))); ?>"
                        alt="Profile Picture"
                        class="w-32 h-32 rounded-full object-cover border-4 border-indigo-500 shadow-lg cursor-pointer">

                    <!-- Hidden File Input for Image Upload -->
                    <input type="file" name="profile_image" id="profile_image"
                        class="absolute inset-0 w-full h-full opacity-0 cursor-pointer rounded-full"
                        onchange="previewImage(event)" accept="image/*">

                    <!-- Pencil Icon Positioned at the Bottom-Right -->
                    <label for="profile_image" class="absolute bottom-0 bg-white right-40 rounded-full p-1 cursor-pointer">
                        <i class="fas fa-pencil-alt text-indigo-500 hover:text-indigo-700 text-xl"></i>
                    </label>
                </div>

                <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-sm text-center mt-2"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Submit Button -->
                <div class="text-center">
                    <button type="submit"
                        class="w-full md:w-auto bg-indigo-500 text-white px-6 py-3 rounded-lg text-center hover:bg-indigo-600 transition duration-300 ease-in-out">
                        Update Profile Image
                    </button>
                </div>
            </form>

            <!-- User Details -->
            <div class="space-y-6 mt-6">
                <div class="flex justify-between">
                    <label for="name" class="text-gray-700 font-medium">Name</label>
                    <div class="text-gray-800"><?php echo e($user->name); ?></div>
                </div>

                <div class="flex justify-between">
                    <label for="email" class="text-gray-700 font-medium">Email</label>
                    <div class="text-gray-800"><?php echo e($user->email); ?></div>
                </div>

                <div class="flex justify-between">
                    <label for="created_at" class="text-gray-700 font-medium">Joined</label>
                    <div class="text-gray-800"><?php echo e($user->created_at->format('F j, Y')); ?></div>
                </div>
            </div>

            <!-- Navigation Links for New Sections -->
            <div class="mt-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Manage Your Account</h3>
                <ul class="space-y-4">
                    <li><a href="<?php echo e(route('user.orders')); ?>" class="text-indigo-500 hover:underline">My Orders</a></li>
                    <li><a href="<?php echo e(route('user.wishlist')); ?>" class="text-indigo-500 hover:underline">My Wishlist</a>
                    </li>
                    <li><a href="<?php echo e(route('user.support')); ?>" class="text-indigo-500 hover:underline">Support / Need
                            Help?</a></li>
                    <li><a href="<?php echo e(route('user.faq')); ?>" class="text-indigo-500 hover:underline">FAQ</a></li>
                </ul>
            </div>

            <!-- Action Buttons -->
            <div class="mt-8">
                <!-- Side by side buttons -->
                <div class="flex justify-between gap-4">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="w-full md:w-auto bg-gray-300 text-gray-700 px-6 py-3 rounded-lg text-center hover:bg-gray-400 transition duration-300 ease-in-out">
                        Back to Dashboard
                    </a>
                    <a href="<?php echo e(route('userchange-password.form')); ?>"
                        class="w-full md:w-auto bg-indigo-500 text-white px-6 py-3 rounded-lg text-center hover:bg-indigo-600 transition duration-300 ease-in-out">
                        Change Password
                    </a>
                </div>

                <!-- Delete Account Button (below the two buttons) -->
                <div class="mt-4">
                    <button id="deleteAccountButton"
                        class="w-full md:w-auto bg-red-500 text-white px-6 py-3 rounded-lg text-center hover:bg-red-600 transition duration-300 ease-in-out">
                        Delete Account
                    </button>
                </div>
            </div>

        </div>
    </div>

    <!-- Confirmation Modal -->
    <div id="confirmationModal" class="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg w-96">
            <h3 class="text-2xl font-semibold text-gray-800 mb-4">Are you sure you want to delete your account?</h3>
            <p class="text-gray-600 mb-4">This action cannot be undone. In 24 hours, your account and all associated data
                will be permanently deleted.</p>

            <!-- Action Buttons -->
            <div class="flex justify-between gap-4">
                <button id="cancelButton"
                    class="w-full md:w-auto bg-gray-300 text-gray-700 px-6 py-3 rounded-lg text-center hover:bg-gray-400 transition duration-300 ease-in-out">
                    Cancel
                </button>
                <form action="<?php echo e(route('delete.account')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" id="confirmDeleteButton"
                        class="w-full md:w-auto bg-red-500 text-white px-6 py-3 rounded-lg text-center hover:bg-red-600 transition duration-300 ease-in-out">
                        Confirm
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Function to preview the selected image
        function previewImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function(e) {
                const preview = document.getElementById('profileImagePreview');
                preview.src = e.target.result; // Set the source to the selected file's data URL
            }

            if (file) {
                reader.readAsDataURL(file); // Read the file as a Data URL
            } else {
                // If no file is selected, set the default image again
                document.getElementById('profileImagePreview').src =
                    '<?php echo e(asset('storage/' . ($user->profile_image ?? 'profile_images/default.jpg'))); ?>';
            }
        }

        // Show the confirmation modal when the user clicks "Delete Account"
        document.getElementById('deleteAccountButton').addEventListener('click', function() {
            document.getElementById('confirmationModal').classList.remove('hidden');
        });

        // Hide the confirmation modal when the user clicks "Cancel"
        document.getElementById('cancelButton').addEventListener('click', function() {
            document.getElementById('confirmationModal').classList.add('hidden');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Documents/laravel-auth-app/resources/views/user/userprofile.blade.php ENDPATH**/ ?>