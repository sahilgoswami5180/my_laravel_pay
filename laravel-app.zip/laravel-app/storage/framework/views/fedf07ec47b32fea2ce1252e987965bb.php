<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Product Combos</h1>
    <table class="min-w-full bg-white rounded-lg shadow-lg">
        <thead>
            <tr class="text-left bg-gray-200">
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Name</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Description</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Total Price</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Discount Price</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Selected Products</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Image</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $combos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t border-gray-200 hover:bg-gray-50">
                <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($combo->name); ?></td>
                <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($combo->description); ?></td>
                <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($combo->total_price); ?></td>
                <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($combo->disc_price); ?></td>

                <!-- Displaying Selected Products -->
                <td class="px-6 py-4 text-sm text-gray-600">
                    <?php $__currentLoopData = $combo->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="block text-gray-800"><?php echo e($product->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <!-- Displaying the Product Image -->
                <td class="px-6 py-4 text-sm text-gray-600">
                    <?php if($combo->image_path && Storage::exists('public/' . $combo->image_path)): ?>
                    <img src="<?php echo e(asset('storage/' . $combo->image_path)); ?>" alt="<?php echo e($combo->name); ?>" class="w-16 h-16 object-cover rounded-lg">
                    <?php else: ?>
                    <img src="<?php echo e(asset('images/default-image.jpg')); ?>" alt="Default Image" class="w-16 h-16 object-cover rounded-lg">
                    <?php endif; ?>
                </td>
                <td class="px-6 py-4 text-sm space-x-2">
                    <!-- Edit Button -->
                    <a href="<?php echo e(route('product_combos.edit', $combo->id)); ?>" class="inline-flex items-center px-4 py-2 text-white bg-yellow-500 hover:bg-yellow-600 rounded-lg transition duration-300">
                        <i class="fas fa-edit mr-2"></i>Edit
                    </a>

                    <!-- Delete Button -->
                    <form action="<?php echo e(route('product_combos.destroy', $combo->id)); ?>" method="POST" class="inline-block" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="inline-flex items-center px-4 py-2 text-white bg-red-500 hover:bg-red-600 rounded-lg transition duration-300">
                            <i class="fas fa-trash mr-2"></i>Delete
                        </button>
                    </form>

                    <!-- Soft Delete Button -->
                    <form action="<?php echo e(route('product_combos.softdelete', $combo->id)); ?>" method="POST" class="inline-block" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="inline-flex items-center px-4 py-2 text-white bg-gray-500 hover:bg-gray-600 rounded-lg transition duration-300">
                            <i class="fas fa-archive mr-2"></i>Soft Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Desktop/sahil_desk/laravel-app/resources/views/product_combos/index.blade.php ENDPATH**/ ?>