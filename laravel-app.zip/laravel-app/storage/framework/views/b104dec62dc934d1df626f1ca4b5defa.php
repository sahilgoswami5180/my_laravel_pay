<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div id="toastSuccess"
            class="fixed top-2 left-1/2 transform -translate-x-1/2 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 opacity-0 translate-y-[-20px] transition-all duration-500 ease-out text-center">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div id="toastError"
            class="fixed top-2 left-1/2 transform -translate-x-1/2 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 opacity-0 translate-y-[-20px] transition-all duration-500 ease-out">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>

    <script>
        function showToast(toastId) {
            let toast = document.querySelector(toastId);
            if (toast) {
                // Show toast with transition
                setTimeout(() => {
                    toast.classList.remove('opacity-0', 'translate-y-[-20px]');
                    toast.classList.add('opacity-100', 'translate-y-0');
                }, 10); // Slight delay to trigger the transition

                // Hide the toast after 4 seconds
                setTimeout(() => {
                    toast.classList.remove('opacity-100', 'translate-y-0');
                    toast.classList.add('opacity-0', 'translate-y-[-20px]');
                }, 4000); // Hide toast after 4 seconds
            }
        }

        // Show the success toast if present
        <?php if(session('success')): ?>
            showToast('#toastSuccess');
        <?php endif; ?>

        // Show the error toast if present
        <?php if(session('error')): ?>
            showToast('#toastError');
        <?php endif; ?>
    </script>
    <!-- Category Section -->
    <section class="py-4 bg-gray-100">
        <div class="container mx-auto text-center">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Categories</h2>

            <!-- Category Links -->
            <div class="flex justify-center gap-4">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('user.categorywiseproduct', $category->id)); ?>"
                        class="category-btn bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600">
                        <?php echo e($category->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- Featured Products Section -->
    <section class="py-12 bg-gray-100">
        <div class="container mx-auto text-center">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Featured Products</h2>

            <!-- Grid of Featured Products -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        // Check if the product is in the cart
                        $cartItem = session('cart')[$product->id] ?? null;
                    ?>

                    <div
                        class="bg-white p-4 rounded-md shadow-lg transform hover:scale-105 transition-transform duration-300">
                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                            class="w-full h-48 object-cover rounded-md mb-4">
                        <h3 class="text-xl font-semibold text-gray-800"><?php echo e($product->name); ?></h3>
                        <p class="text-gray-600 mt-2"><?php echo e(Str::limit($product->description, 100)); ?></p>
                        <p class="text-lg font-bold text-blue-500 mt-4">$<?php echo e(number_format($product->price, 2)); ?></p>

                        <?php if($cartItem): ?>
                            <!-- Product is in the cart, show update and remove buttons -->
                            <div class="mt-4">
                                <!-- Remove Button -->
                                <form action="<?php echo e(route('cart.remove', $product)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                        class="text-red-500 flex items-center space-x-2 hover:text-red-700">
                                        <i class="fas fa-trash-alt"></i>
                                        <span>Remove</span>
                                    </button>
                                </form>

                                <!-- Update Quantity with + and - buttons -->
                                <form action="<?php echo e(route('cart.updateQuantity', $product)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="space-y-2">
                                        <!-- Quantity Input -->
                                        <input type="number" name="quantity" value="<?php echo e($cartItem['quantity']); ?>"
                                            min="1"
                                            class="w-20 text-center border border-gray-300 rounded-md mx-auto block"
                                            readonly>

                                        <!-- Buttons to Change Quantity -->
                                        <div class="flex space-x-2 mt-2">
                                            <!-- Decrease Button -->
                                            <button type="submit" name="quantity" value="<?php echo e($cartItem['quantity'] - 1); ?>"
                                                class="bg-gray-200 text-gray-600 px-3 py-1 rounded-md hover:bg-gray-300 w-20 flex items-center justify-center"
                                                <?php echo e($cartItem['quantity'] <= 1 ? 'disabled' : ''); ?>>
                                                <i class="fas fa-minus"></i>
                                            </button>

                                            <!-- Increase Button -->
                                            <button type="submit" name="quantity" value="<?php echo e($cartItem['quantity'] + 1); ?>"
                                                class="bg-gray-200 text-gray-600 px-3 py-1 rounded-md hover:bg-gray-300 w-20 flex items-center justify-center">
                                                <i class="fas fa-plus"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        <?php else: ?>
                            <!-- Add to Cart Button -->
                            <div class="mt-4">
                                <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600">Add
                                        to Cart</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/user/index.blade.php ENDPATH**/ ?>