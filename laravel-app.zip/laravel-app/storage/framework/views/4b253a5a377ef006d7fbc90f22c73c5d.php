<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="bg-white shadow-md rounded-lg p-6 w-full max-w-md">
        <h2 class="text-2xl font-bold text-center mb-4">Email Verified</h2>

        <?php if(session('status')): ?>
            <div class="bg-green-100 text-green-700 p-4 mb-4 rounded">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 text-red-700 p-4 mb-4 rounded">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="space-y-4">
            <p class="text-gray-700 text-center">
                Thank you for verifying your email. Your account is now active.
            </p>
            <a href="<?php echo e(route('dashboard')); ?>"
               class="w-full bg-blue-500 text-white py-2 rounded text-center block hover:bg-blue-600 transition">
                Go to Dashboard
            </a>
        </div>
    </div>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/auth/verify.blade.php ENDPATH**/ ?>