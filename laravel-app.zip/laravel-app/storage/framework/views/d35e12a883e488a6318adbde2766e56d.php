<nav class="bg-white shadow-md sticky top-0 z-10 p-4 flex justify-between items-center">
    <h1 class="text-3xl font-bold text-gray-800">Categories</h1>

    <!-- Profile Icon Dropdown -->
    <div class="relative flex items-center space-x-2">
        <button class="flex items-center space-x-2 text-gray-700 hover:text-blue-500" id="profileNavbarDropdownToggle">
            <img src="https://www.w3schools.com/w3images/avatar2.png" alt="Profile" class="w-8 h-8 rounded-full">
            <p class="px-1"><?php echo e(Auth::user()->name); ?></p>
            <i class="fas fa-chevron-down w-5 h-5 transform transition-transform duration-200" id="navbarDropdownArrow"></i>
        </button>

        <!-- Dropdown menu -->
        <ul class="absolute right-0 w-48 mt-40 bg-white shadow-lg hidden" id="profileNavbarDropdown">
            <li><a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">My Account</a></li>
            <li><a href="#" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Change Password</a></li>
            <hr>
            <li class="flex justify-center items-center">
                <button onclick="openLogoutModal()" class="bg-red-600 px-8 py-1 m-2 rounded hover:bg-red-700 text-white text-lg font-semibold">Logout</button>
                <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden"><?php echo csrf_field(); ?></form>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/navbar.blade.php ENDPATH**/ ?>