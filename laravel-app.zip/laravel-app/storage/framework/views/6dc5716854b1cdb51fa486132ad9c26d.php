<?php echo e($slot); ?>

<?php /**PATH /home/xceltec-28/Desktop/sahil_desk/laravel-app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>