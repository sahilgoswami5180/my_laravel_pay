<?php $__env->startSection('title', 'Edit Combo'); ?>

<?php $__env->startSection('content'); ?>
<style>
    /* Custom Scrollbar Styling */
    .max-h-60::-webkit-scrollbar {
        width: 8px;
    }
    .max-h-60::-webkit-scrollbar-track {
        background-color: #f1f1f1;
    }
    .max-h-60::-webkit-scrollbar-thumb {
        background-color: #888;
        border-radius: 10px;
    }
    .max-h-60::-webkit-scrollbar-thumb:hover {
        background-color: #555;
    }
    
    /* Custom form input and select styles */
    .form-input, .form-select {
        background-color: #f9fafb;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        padding: 10px 15px;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .form-input:focus, .form-select:focus {
        border-color: #4CAF50;
        box-shadow: 0 0 5px rgba(76, 175, 80, 0.5);
    }

    /* Button Hover Effects */
    .btn-hover {
        transition: background-color 0.3s ease, transform 0.2s ease-in-out;
    }

    .btn-hover:hover {
        background-color: #4CAF50;
        transform: scale(1.05);
    }

    /* Custom Checkbox Styles */
    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .checkbox-label input {
        margin-right: 10px;
    }
    
    /* Card Style Form Container */
    .form-container {
        background-color: #ffffff;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    /* Breadcrumb Styles */
    .breadcrumb a {
        color: #4a90e2;
        transition: color 0.3s ease;
    }

    .breadcrumb a:hover {
        color: #2c6ed5;
    }
    
</style>

<div class="container mx-auto mt-10 px-4">

    <!-- Breadcrumb Navigation -->
    <nav class="flex text-sm text-gray-600 mb-6 items-center breadcrumb">
        <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center <?php echo e(Request::is('dashboard') ? 'text-blue-500' : ''); ?>">
            <span class="text-xs px-3 py-1 bg-gray-200 rounded-full">Home</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <a href="<?php echo e(route('product_combos.index')); ?>" class="flex items-center <?php echo e(Request::is('product_combos') || Request::is('product_combos/*') ? 'text-blue-500' : ''); ?>">
            <span class="text-xs px-3 py-1 bg-gray-200 rounded-full">Product Combos</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <span class="text-xs text-gray-500">Edit Combo</span>
    </nav>

    <!-- Form Container -->
    <div class="form-container">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-semibold text-gray-800">Edit Combo</h2>
        </div>

        <!-- Edit Combo Form -->
        <form action="<?php echo e(route('product_combos.update', $combo->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Combo Name -->
            <div class="mb-6">
                <label for="name" class="block text-sm font-medium text-gray-700">Combo Name</label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name', $combo->name)); ?>" class="form-input w-full" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Combo Description -->
            <div class="mb-6">
                <label for="description" class="block text-sm font-medium text-gray-700">Combo Description</label>
                <textarea name="description" id="description" rows="4" class="form-input w-full" required><?php echo e(old('description', $combo->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Total Price -->
            <div class="mb-6">
                <label for="total_price" class="block text-sm font-medium text-gray-700">Total Price</label>
                <input type="number" name="total_price" id="total_price" value="<?php echo e(old('total_price', $combo->total_price)); ?>" step="0.01" class="form-input w-full" required>
                <?php $__errorArgs = ['total_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Discount Price -->
            <div class="mb-6">
                <label for="disc_price" class="block text-sm font-medium text-gray-700">Discount Price</label>
                <input type="number" name="disc_price" id="disc_price" value="<?php echo e(old('disc_price', $combo->disc_price)); ?>" step="0.01" class="form-input w-full" required>
                <?php $__errorArgs = ['disc_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>
            <!-- Category and Subcategory -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label for="category_id" class="block text-sm font-medium text-gray-700">Category</label>
                    <select name="category_id" id="category_id" class="form-select w-full" required>
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e($combo->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="subcategory_id" class="block text-sm font-medium text-gray-700">Subcategory</label>
                    <select name="subcategory_id" id="subcategory_id" class="form-select w-full" required>
                        <option value="">Select Subcategory</option>
                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subcategory->id); ?>" <?php echo e($combo->subcategory_id == $subcategory->id ? 'selected' : ''); ?>><?php echo e($subcategory->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Product Selection -->
             <div class="relative">
                <label for="products" class="block text-sm font-medium text-gray-700">Select Products</label>
                <div class="max-h-60 overflow-y-auto mt-2">
                    <ul id="product-checkboxes" class="space-y-4">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="checkbox-label">
                                <input type="checkbox" 
                                    name="products[]" 
                                    value="<?php echo e($product->id); ?>" 
                                    id="product-<?php echo e($product->id); ?>"
                                    class="h-5 w-5 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 product-checkbox"
                                    <?php echo e(in_array($product->id, old('products', $combo->products->pluck('id')->toArray())) ? 'checked' : ''); ?>>
                                <label for="product-<?php echo e($product->id); ?>" class="text-sm text-gray-700"><?php echo e($product->name); ?></label>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <p class="product-count mt-2">Total Selected: <span id="product-count">0</span></p>
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end space-x-4 mt-6">
                <a href="<?php echo e(route('product_combos.index')); ?>" class="btn-hover bg-gray-300 text-gray-800 px-6 py-2 rounded">Cancel</a>
                <button type="submit" class="btn-hover bg-blue-500 text-white px-6 py-2 rounded">Update Combo</button>
            </div>
        </form>
    </div>
</div>
<!-- JavaScript to update the selected product count dynamically -->
<script>
    document.querySelectorAll('.product-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function () {
            const selectedProducts = document.querySelectorAll('.product-checkbox:checked').length;
            document.getElementById('product-count').textContent = selectedProducts;
        });
    });

    // Initialize the product count on page load
    document.addEventListener('DOMContentLoaded', function () {
        const selectedProducts = document.querySelectorAll('.product-checkbox:checked').length;
        document.getElementById('product-count').textContent = selectedProducts;
    });
</script>
<!-- JavaScript to load subcategories dynamically when category changes -->
<script>
    document.getElementById('category_id').addEventListener('change', function() {
        const categoryId = this.value;
        const subcategoryDropdown = document.getElementById('subcategory_id');
        subcategoryDropdown.innerHTML = '<option value="">Select Subcategory</option>';

        if (categoryId) {
            fetch(`/get-subcategories/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    data.forEach(subcategory => {
                        const option = document.createElement('option');
                        option.value = subcategory.id;
                        option.textContent = subcategory.name;
                        subcategoryDropdown.appendChild(option);
                    });
                })
                .catch(error => console.error('Error fetching subcategories:', error));
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Documents/laravel-auth-app/resources/views/product_combos/edit.blade.php ENDPATH**/ ?>