<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Account</title>
    <!-- Include Tailwind CSS from CDN -->
    <script src="https://cdn.tailwindcss.com"></script> <!-- If you don't have Tailwind installed -->
</head>
<body class="bg-gray-100">

    <div class="max-w-2xl mx-auto mt-10 bg-white p-6 rounded-lg shadow-lg">
        <h1 class="text-3xl font-semibold mb-4">Your Account</h1>
        <!-- You can display user data here -->
        <p class="text-lg">Welcome, <?php echo e(Auth::user()->name); ?></p>  <!-- Replace "John Doe" with dynamic user data if needed -->

        <div class="mt-6">
            <a href="#" class="text-blue-500 hover:underline">Edit Profile</a>
        </div>

        <!-- Logout Button -->
        <button onclick="openLogoutModal()"
                class="bg-red-600 px-8 py-2 mt-4 rounded hover:bg-red-700 text-white text-lg font-semibold">
            Logout
        </button>

        <!-- Logout Form (hidden initially) -->
        <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
            <?php echo csrf_field(); ?>
        </form>
    </div>

    <!-- Logout Confirmation Modal (hidden initially) -->
    <div id="logoutModal" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg text-center max-w-sm w-full">
            <h2 class="text-2xl font-semibold mb-4">Are you sure you want to logout?</h2>
            <div class="flex justify-between space-x-4">
                <button onclick="confirmLogout()" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg">Yes, logout</button>
                <button onclick="closeLogoutModal()" class="bg-gray-300 hover:bg-gray-400 text-black px-4 py-2 rounded-lg">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        // Function to open the logout modal
        function openLogoutModal() {
            document.getElementById('logoutModal').classList.remove('hidden');
        }

        // Function to close the logout modal
        function closeLogoutModal() {
            document.getElementById('logoutModal').classList.add('hidden');
        }

        // Function to confirm logout (submit the form)
        function confirmLogout() {
            document.getElementById('logoutForm').submit();
        }
    </script>

</body>
</html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/user/account.blade.php ENDPATH**/ ?>