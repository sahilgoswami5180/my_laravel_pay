<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>


    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Add Font Awesome CDN -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <?php echo $__env->yieldPushContent('head'); ?> <!-- For any additional head content -->
    <style>
        /* Ensure sidebar takes full height and doesn't scroll */
        .sidebar {
            position: fixed;
            height: 100vh;
            overflow: hidden;
            z-index: 9999;
        }

        #sidebar::-webkit-scrollbar {
            width: 8px;
        }

        #sidebar::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.3);
            border-radius: 10px;
        }

        #sidebar::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        /* Make the main content scrollable */
        .main-content {
            overflow-y: auto;
            flex-grow: 1;
        }

        /* Prevent horizontal scroll on body */
        body {
            overflow-x: hidden;
            display: flex;
            min-height: 100vh;
        }

        /* Custom scrollbar styles */
        body::-webkit-scrollbar {
            width: 10px;
        }

        body::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        body::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }

        body::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* For better mobile support */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                left: -100%;
                top: 0;
                width: 250px;
                z-index: 1000;
                transition: 0.3s;
            }

            .sidebar.open {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .navbar {
                padding: 0.5rem;
            }
        }

        .last-login-time {
    color: white;
}
    </style>
</head>

<body class="bg-gray-100">
    <!-- Sidebar -->
    <div id="sidebar" class="sidebar bg-teal-500 from-teal-600 to-teal-800 text-white w-64 p-6 shadow-lg max-h-screen overflow-y-auto">
        <div class="flex flex-col items-center mb-2">
            <span class="font-semibold text-2xl">Dashboard</span>
            <div class="text-center mt-1">
                <span class="text-gray-300 text-sm" id="last-login-time" style="font-size: 12px;"></span>
            </div>
        </div>
        <hr class="w-full border-gray-700 mb-6">
        <ul class="space-y-6">
            <li>
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="flex items-center text-lg font-semibold hover:text-white-200 transition duration-300 ease-in-out transform hover:scale-105 p-2 rounded-lg hover:bg-teal-700">
                    <i class="fas fa-tachometer-alt w-4 h-4 mr-3"></i> Dashboard
                </a>
            </li>

            <li>
                <button
                    class="flex items-center w-full text-lg font-semibold hover:text-white-200 focus:outline-none transition duration-300 ease-in-out transform hover:scale-105 p-2 rounded-lg hover:bg-teal-700"
                    id="categoriesDropdownToggle">
                    <i class="fas fa-list w-4 h-4 mr-3"></i> Categories
                    <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200 dropdown-arrow"
                        id="categoriesDropdownArrow"></i>
                </button>
                <ul class="space-y-2 mt-2 pl-6 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                    id="categoriesDropdown" aria-labelledby="categoriesDropdownToggle">
                    <li>
                        <a href="<?php echo e(route('categories.index')); ?>"
                            class="text-gray-900 hover:text-black transition duration-200 transform hover:scale-105">
                            <i class="fas fa-eye mr-2"></i> View Categories
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('categories.create')); ?>"
                            class="text-gray-900 hover:text-black transition duration-200 transform hover:scale-105">
                            <i class="fas fa-plus-circle mr-2"></i> Add New Category
                        </a>
                    </li>
                </ul>
            </li>
            <!-- Subcategories Dropdown -->
            <li>
                <button
                    class="flex items-center w-full text-lg font-semibold hover:text-white-200 focus:outline-none transition duration-300 ease-in-out transform hover:scale-105 p-2 rounded-lg hover:bg-teal-700"
                    id="subcategoriesDropdownToggle">
                    <i class="fas fa-box w-4 h-4 mr-3"></i> Subcategories
                    <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200 dropdown-arrow"
                        id="subcategoriesDropdownArrow"></i>
                </button>
                <ul class="mt-1 pl-1 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                    id="subcategoriesDropdown" aria-labelledby="subcategoriesDropdownToggle">
                    <li>
                        <a href="<?php echo e(route('subcategories.index')); ?>"
                            class="text-gray-900 hover:text-black transition duration-200 transform hover:scale-105">
                            <i class="fas fa-eye mr-1"></i> View Subcategories
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('subcategories.create')); ?>"
                            class="text-gray-900 hover:text-black transition duration-200 transform hover:scale-105">
                            <i class="fas fa-plus-circle mr-1"></i> Add New Subcategory
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Products Dropdown -->
            <li>
                <button
                    class="flex items-center w-full text-lg font-semibold hover:text-white-200 focus:outline-none transition duration-300 ease-in-out transform hover:scale-105 p-2 rounded-lg hover:bg-teal-700"
                    id="productsDropdownToggle">
                    <i class="fas fa-box w-4 h-4 mr-3"></i> Products
                    <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200 dropdown-arrow"
                        id="productsDropdownArrow"></i>
                </button>
                <ul class="space-y-2 mt-2 pl-6 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                    id="productsDropdown" aria-labelledby="productsDropdownToggle">
                    <li>
                        <a href="<?php echo e(route('products.index')); ?>"
                            class="text-gray-900 hover:text-black transition duration-200 transform hover:scale-105">
                            <i class="fas fa-eye mr-2"></i> View Products
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('products.create')); ?>"
                            class="text-gray-900 hover:text-black transition duration-200 transform hover:scale-105">
                            <i class="fas fa-plus-circle mr-2"></i> Add New Product
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="<?php echo e(route('order.index')); ?>"
                    class="flex items-center text-lg font-semibold hover:text-white-200 transition duration-300 ease-in-out transform hover:scale-105 p-2 rounded-lg hover:bg-teal-700">
                    <i class="fas fa-tachometer-alt w-4 h-4 mr-3"></i> Orders
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('order.index')); ?>"
                    class="flex items-center text-lg font-semibold hover:text-white-200 transition duration-300 ease-in-out transform hover:scale-105 p-2 rounded-lg hover:bg-teal-700">
                    <i class="fas fa-tachometer-alt w-4 h-4 mr-3"></i> Add's
                </a>
            </li>
            <!-- Combo's Dropdown -->
            <li>
                <button
                    class="flex items-center w-full text-lg font-semibold hover:text-white-200 focus:outline-none transition duration-300 ease-in-out transform hover:scale-105 p-2 rounded-lg hover:bg-teal-700"
                    id="CombosDropdownToggle">
                    <i class="fas fa-box w-4 h-4 mr-3"></i> Combo's
                    <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200 dropdown-arrow"
                        id="CombosDropdownDropdownArrow"></i>
                </button>
                <ul class="mt-1 pl-1 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                    id="CombosDropdown" aria-labelledby="CombosDropdownDropdownToggle">
                    <li>
                        <a href="<?php echo e(route('product_combos.index')); ?>"
                            class="text-gray-900 hover:text-black transition duration-200 transform hover:scale-105">
                            <i class="fas fa-plus-circle mr-1"></i> View Combos
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('product_combos.create')); ?>"
                            class="text-gray-900 hover:text-black transition duration-200 transform hover:scale-105">
                            <i class="fas fa-plus-circle mr-1"></i> Create Combos
                        </a>
                    </li>
                </ul>
            </li>
            <li>

            </li>

        </ul>
    </div>


    <!-- Main Content -->
    <div class="flex flex-col w-full">
        <nav
            class="navbar bg-white border-b-2 border-blue-700 shadow-md sticky top-0 z-10 p-4 flex justify-between items-center" style="margin-left:250px;">
            <h1 class="text-3xl font-bold text-gray-800"></h1>

            <?php if(auth()->guard()->check()): ?>
            <div class="relative flex items-center space-x-2">


                <button class="flex items-center space-x-2 text-gray-700 hover:text-blue-500"
                    id="profileNavbarDropdownToggle" aria-expanded="false">
                    <img id="profileImagePreview"
                        src="<?php echo e(asset('storage/' . (Auth::user()->profile_image ?? 'profile_images/Profile.png'))); ?>"
                        alt="Profile Picture"
                        class="w-8 h-8 rounded-full object-cover border-2 border-white-500 shadow-lg">
                    <p class="px-1"><?php echo e(Auth::user()->name); ?></p>
                    <i class="fas fa-chevron-down w-5 h-5 transform transition-transform duration-200"
                        id="navbarDropdownArrow"></i>
                </button>
                <!-- Dropdown menu -->
                <ul class="absolute right-0 w-48 rounded-lg bg-white shadow-2xl hidden" id="profileNavbarDropdown"
                    aria-labelledby="profileNavbarDropdownToggle" style=" margin-right:-15px; margin-top: 205px;">
                    <li>
                        <a href="<?php echo e(route('profile')); ?>" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                            <i class="fas fa-user ml-2"></i><span class="pl-2">My Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('change-password.form')); ?>"
                            class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                            <i class="fas fa-lock ml-2"></i><span class="pl-2">Change Password</span>
                        </a>
                    </li>
                    <hr>
                    <li class="flex justify-center items-center">
                        <button onclick="openLogoutModal()"
                            class="bg-red-600 px-8 py-1 m-2 rounded hover:bg-red-700 text-white text-lg font-semibold flex items-center">
                            <i class="fas fa-sign-out-alt mr-2"></i> Logout
                        </button>
                        <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden"><?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>

            </div>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?>
            <div>
                <a href="<?php echo e(route('login')); ?>" class="text-gray-700 hover:text-blue-500">Login</a>
            </div>
            <?php endif; ?>
        </nav>

        <div class="main-content flex flex-col w-full">
            <!-- Page Content -->
            <main class="py-6 px-4 overflow-auto" style="min-height: 100vh; margin-left:250px;">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            <!-- Footer -->
            <footer class="bg-gradient-to-r bg-teal-500 to-teal-600 text-white py-2 mt-auto"
                style="margin-left:250px;">
                <div class="max-w-screen-xl mx-auto flex justify-between items-center px-4 sm:px-6">
                    <div class="text-sm">
                        <p>&copy; 2024 Your Company. All rights reserved.</p>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="#" class="text-gray-300 hover:text-white transition-colors">
                            <i class="fab fa-facebook-square text-2xl"></i>
                        </a>
                        <a href="#" class="text-gray-300 hover:text-white transition-colors">
                            <i class="fab fa-twitter-square text-2xl"></i>
                        </a>
                        <a href="#" class="text-gray-300 hover:text-white transition-colors">
                            <i class="fab fa-linkedin text-2xl"></i>
                        </a>
                        <a href="#" class="text-gray-300 hover:text-white transition-colors">
                            <i class="fab fa-instagram-square text-2xl"></i>
                        </a>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Logout Confirmation Modal -->
    <div id="logoutModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-4 rounded-lg shadow-lg w-full max-w-xl">
            <div class="flex items-center mb-4">
                <i class="fas fa-exclamation-circle text-red-600 text-3xl mr-4"></i>
                <h2 class="text-xl font-semibold text-gray-800">Are you sure you want to log out?</h2>
            </div>
            <p class="text-gray-700 mb-4 text-center">If you log out, you will need to sign in again to continue using
                the application.</p>
            <div class="flex justify-end gap-4 mt-6">
                <button onclick="closeLogoutModal()"
                    class="flex items-center justify-center px-6 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition duration-300">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </button>
                <button onclick="document.getElementById('logoutForm').submit();"
                    class="flex items-center justify-center px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-300">
                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                </button>
            </div>
        </div>
    </div>
    <script>
        // Function to preview the selected image
        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('profileImagePreview');

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            } else {
                preview.src = '<?php echo e(asset("storage/" . (Auth::user()->profile_image ?? "profile_images/default.jpg"))); ?>';
            }
        }

        // Dropdown toggle functions
        function toggleDropdown(id, arrowId) {
            const dropdown = document.getElementById(id);
            const arrow = document.getElementById(arrowId);

            dropdown.classList.toggle('hidden');
            arrow.classList.toggle('rotate-180');
        }
        subcategoriesDropdownToggle
        document.getElementById('categoriesDropdownToggle').addEventListener('click', () => toggleDropdown('categoriesDropdown', 'categoriesDropdownArrow'));
        document.getElementById('subcategoriesDropdownToggle').addEventListener('click', () => toggleDropdown('subcategoriesDropdown', 'subcategoriesDropdownArrow'));
        document.getElementById('CombosDropdownToggle').addEventListener('click', () => toggleDropdown('CombosDropdown', 'CombosDropdownArrow'));

        document.getElementById('productsDropdownToggle').addEventListener('click', () => toggleDropdown('productsDropdown', 'productsDropdownArrow'));
        document.getElementById('profileNavbarDropdownToggle').addEventListener('click', () => toggleDropdown('profileNavbarDropdown', 'navbarDropdownArrow'));

        // Open logout confirmation modal
        function openLogoutModal() {
            document.getElementById('logoutModal').classList.remove('hidden');
        }

        // Close logout confirmation modal
        function closeLogoutModal() {
            document.getElementById('logoutModal').classList.add('hidden');
        }

        // Fetch and display last login time
        window.onload = function() {
            const cookies = document.cookie.split('; ');
            let lastLoginTimeCookie = '';
            cookies.forEach(cookie => {
                const [key, value] = cookie.split('=');
                if (key === 'user_data') {
                    try {
                        const userData = JSON.parse(decodeURIComponent(value));
                        if (userData.last_login_at) {
                            lastLoginTimeCookie = userData.last_login_at;
                        }
                    } catch (e) {
                        console.error('Error parsing user data cookie', e);
                    }
                }
            });

            if (lastLoginTimeCookie) {
                const lastLoginDate = new Date(lastLoginTimeCookie);
                const lastLoginFormatted = lastLoginDate.toLocaleString();
                document.getElementById('last-login-time').textContent = `Last login: ${lastLoginFormatted}`;
                document.getElementById('last-login-time').style.color = 'white';
            } else {
                document.getElementById('last-login-time').textContent = 'Last login: N/A';
            }
        };
    </script>

    <script>
        // Function to preview the selected image
        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('profileImagePreview');

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            } else {
                preview.src = '<?php echo e(asset('
                storage / ' . (Auth::user()->profile_image ?? '
                profile_images /
                    default.jpg '))); ?>';
            }
        }

        // Dropdown toggle functions
        function toggleDropdown(id, arrowId) {
            const dropdown = document.getElementById(id);
            const arrow = document.getElementById(arrowId);

            dropdown.classList.toggle('hidden');
            arrow.classList.toggle('rotate-180');
        }

        document.getElementById('categoriesDropdownToggle').addEventListener('click', () => toggleDropdown(
            'categoriesDropdown', 'categoriesDropdownArrow'));
        // Event listeners for the toggle buttons
        document.getElementById('subcategoriesDropdownToggle').addEventListener('click', () => toggleDropdown(
            'subcategoriesDropdown', 'subcategoriesDropdownArrow'));
        document.getElementById('productsDropdownToggle').addEventListener('click', () => toggleDropdown(
            'productsDropdown', 'productsDropdownArrow'));
        document.getElementById('CombosDropdownToggle').addEventListener('click', () => toggleDropdown(
            'CombosDropdown', 'CombosDropdownArrow'));
        document.getElementById('profileNavbarDropdownToggle').addEventListener('click', () => toggleDropdown(
            'profileNavbarDropdown', 'navbarDropdownArrow'));

        // Open logout confirmation modal
        function openLogoutModal() {
            document.getElementById('logoutModal').classList.remove('hidden');
        }

        // Close logout confirmation modal
        function closeLogoutModal() {
            document.getElementById('logoutModal').classList.add('hidden');
        }

        window.onload = function() {
            const cookies = document.cookie.split('; ');
            console.log(cookies); // Log the cookies to check if `user_data` exists
            let lastLoginTimeCookie = '';
            cookies.forEach(cookie => {
                const [key, value] = cookie.split('=');
                if (key === 'user_data') {
                    try {
                        const userData = JSON.parse(decodeURIComponent(value));
                        console.log(userData); // Check if `userData` has the expected structure
                        if (userData.last_login_at) {
                            lastLoginTimeCookie = userData.last_login_at;
                        }
                    } catch (e) {
                        console.error('Error parsing user data cookie', e);
                    }
                }
            });

            if (lastLoginTimeCookie) {
                const lastLoginDate = new Date(lastLoginTimeCookie);
                const lastLoginFormatted = lastLoginDate.toLocaleString();
                document.getElementById('last-login-time').textContent = `Last login: ${lastLoginFormatted}`;
            } else {
                document.getElementById('last-login-time').textContent = 'Last login: N/A';
            }
        };
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?> <!-- For any page-specific scripts -->
</body>

</html><?php /**PATH /home/xceltec-28/Desktop/sahil_desk/laravel-app/resources/views/layouts/app.blade.php ENDPATH**/ ?>