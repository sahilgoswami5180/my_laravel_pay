<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products List</title>
    <!-- Link to Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f7fb;
            color: #333;
        }

        h2 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 30px;
            color: #2c3e50;
            font-weight: bold;
        }

        h3 {
            font-size: 24px;
            margin-top: 30px;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            font-weight: 600;
        }

        .table-header-icon {
            margin-right: 10px;
            vertical-align: middle;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
        }

        th,
        td {
            padding: 15px;
            text-align: center;
            font-size: 16px;
            color: #555;
            border-bottom: 1px solid #f1f1f1;
        }

        th {
            background-color: #3498db;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
            cursor: pointer;
        }

        img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            transition: transform 0.2s ease-in-out;
        }

        img:hover {
            transform: scale(1.1);
        }

        .status-active {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            padding: 5px 12px;
            border-radius: 20px;
        }

        .status-inactive {
            background-color: #e74c3c;
            color: white;
            font-weight: bold;
            padding: 5px 12px;
            border-radius: 20px;
        }

        .price {
            font-weight: bold;
            color: #2ecc71;
            font-size: 14px;
        }

        .price:hover {
            color: #27ae60;
        }

        .table-container {
            max-width: 1200px;
            margin: 0 auto;
            overflow-x: auto;
        }

        @media (max-width: 768px) {
            h2 {
                font-size: 28px;
            }

            th,
            td {
                font-size: 14px;
                padding: 8px;
            }

            img {
                width: 50px;
                height: 50px;
            }

            table {
                margin-top: 10px;
            }
        }

        @media (max-width: 576px) {

            th,
            td {
                font-size: 12px;
                padding: 6px;
            }

            img {
                width: 40px;
                height: 40px;
            }

            .price {
                font-size: 12px;
            }

            h2 {
                font-size: 24px;
            }
        }
    </style>
</head>

<body>

    <div class="table-container">
        <h2>Product Inventory</h2>

        <h3><i class="fas fa-box-open table-header-icon"></i>Active Products</h3>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th style="width:140px;">Product Name</th>
                    <th>Category</th>
                    <th style="width:80px;">Price</th>
                    <th>Image</th>
                    <th style="width:100px;">Status</th>
                    <th style="width:150px;">Added On</th>
                    <th style="width:150px;">Updated On</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $nonDeletedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->category->name ?? 'No category'); ?></td>
                        <td class="price">$<?php echo e(number_format($product->price, 2)); ?></td>

                        <td>
                            <?php if($product->image && file_exists(storage_path('app/public/' . $product->image))): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images/placeholder.png')); ?>" alt="Placeholder Image">
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="<?php echo e($product->status == 'active' ? 'status-active' : 'status-inactive'); ?>">
                                <i
                                    class="fas <?php echo e($product->status == 'active' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
                                <?php echo e(ucfirst($product->status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($product->created_at->format('M j, Y, g:i a')); ?></td>
                        <td><?php echo e($product->updated_at->format('M j, Y, g:i a')); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <h3><i class="fas fa-trash-alt table-header-icon"></i>Deleted Products</h3>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th style="width:140px;">Product Name</th>
                    <th>Category</th>
                    <th style="width:80px;">Price</th>
                    <th>Image</th>
                    <th style="width:100px;">Status</th>
                    <th style="width:150px;">Added On</th>
                    <th style="width:150px;">Updated On</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $deletedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->category->name ?? 'No category'); ?></td>
                        <td class="price">$<?php echo e(number_format($product->price, 2)); ?></td>

                        <td>
                            <?php if($product->image && file_exists(storage_path('app/public/' . $product->image))): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('images/placeholder.png')); ?>" alt="Placeholder Image">
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="<?php echo e($product->status == 'active' ? 'status-active' : 'status-inactive'); ?>">
                                <i
                                    class="fas <?php echo e($product->status == 'active' ? 'fa-check-circle' : 'fa-times-circle'); ?>"></i>
                                <?php echo e(ucfirst($product->status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($product->created_at->format('M j, Y, g:i a')); ?></td>
                        <td><?php echo e($product->updated_at->format('M j, Y, g:i a')); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

</body>

</html>
<?php /**PATH /home/xceltec-28/Documents/laravel-auth-app/resources/views/products/pdf.blade.php ENDPATH**/ ?>