<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel/slick/slick.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel/slick/slick-theme.css" />

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel/slick/slick.min.js"></script>
<style>
    .carousel {
        position: relative;
        width: 100%;
        max-width: 300px;
        / You can adjust the width based on your needs / margin: 0 auto;
        overflow: hidden;
    }

    .carousel-images {
        display: flex;
        transition: transform 0.5s ease-in-out;
    }

    .carousel-item {
        min-width: 100%;
        display: flex;
        justify-content: center;
    }

    .carousel-item img {
        object-fit: cover;
        width: 100%;
        height: auto;
    }
</style>
<div class="container mx-auto top-0 text-sm">
    <!-- Breadcrumb Navigation -->
    <nav class="flex text-md text-gray-600 mb-2 items-center justify-between">
        <div class="flex items-center">
            <a href="<?php echo e(route('dashboard')); ?>"
                class="hover:text-blue-500 flex items-center <?php echo e(Request::is('dashboard') ? 'text-blue-500' : ''); ?>">
                <span class="text-sm px-2 py-1 bg-gray-200 rounded-full">Home</span>
            </a>
            <span class="mx-2 text-sm">/</span>
            <a href="<?php echo e(route('products.index')); ?>"
                class="hover:text-blue-500 flex items-center <?php echo e(Request::is('products') || Request::is('products/*') ? 'text-blue-500' : ''); ?>">
                <span class="text-sm px-2 py-1 bg-gray-200 rounded-full">Products</span>
            </a>
        </div>

        <!-- Deleted Products Button -->
        <div class="flex items-center">
            <a href="<?php echo e(route('deleted-products.index')); ?>"
                class="bg-yellow-500 text-white px-2 py-2 rounded-full shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 text-sm">
                View Deleted Products
            </a>
        </div>
    </nav>

    <!-- Filter Bar -->
    <form action="<?php echo e(route('products.index')); ?>" method="GET"
        class="flex items-center space-x-1 mb-2 bg-gray-50 p-4 rounded-lg shadow-md">
        <div class="flex space-x-2 w-full">

            <!-- Search Input -->
            <input type="text" name="search" placeholder="Search by product name..."
                class="px-3 py-2 text-sm rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-blue-400"
                style="width:230px;">

            <!-- Category Select -->
            <select name="category_id"
                class="px-2 py-1 text-sm rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-700 bg-white shadow-md hover:border-blue-300 transition duration-300 ease-in-out"
                style="width: 100px;">
                <option value="" style="color: black;" disabled selected>Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" class="text-gray-700"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <!-- Subcategory Select -->
            <select name="subcategory_id"
                class="px-2 py-1 text-sm rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-700 bg-white shadow-md hover:border-blue-300 transition duration-300 ease-in-out"
                style="width: 120px;">
                <option value="" style="color: black;" disabled selected>Subcategory</option>
                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subcategory->id); ?>" class="text-gray-700"><?php echo e($subcategory->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <!-- Status Select -->
            <select name="status"
                class="px-3 py-1 text-sm rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 text-black bg-white shadow-md hover:border-green-300 transition duration-300 ease-in-out"
                style="width: 90px;">
                <option value="" class="text-black" disabled selected>Status</option>
                <option value="active" class="text-green-600">Active</option>
                <option value="inactive" class="text-red-600">Inactive</option>
            </select>

            <!-- Apply Filters Button -->
            <button type="submit"
                class="bg-blue-500 text-white px-3 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 flex items-center text-sm">
                <i class="fas fa-filter"></i>
            </button>

            <!-- Reset Button -->
            <a href="<?php echo e(route('products.index')); ?>"
                class="bg-gray-300 text-black px-4 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center  text-sm">
                <i class="fas fa-undo"></i>
            </a>

            <!-- Download PDF Button -->
            <a href="<?php echo e(route('products.export.pdf')); ?>"
                class="bg-red-500 text-white px-3 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 transition duration-300 flex items-center  text-sm">
                <i class="fas fa-file-pdf"></i>
            </a>

            <!-- Download CSV Button -->
            <a href="<?php echo e(route('products.export.csv')); ?>"
                class="bg-yellow-500 text-white px-3 rounded-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 flex items-center text-sm">
                <i class="fas fa-file-csv"></i>
            </a>

            <!-- Add New Product Button -->
            <a href="<?php echo e(route('products.create')); ?>"
                class="bg-indigo-900 text-white px-3 rounded-full hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-green-400 transition duration-300 flex items-center text-sm">
                <i class="fas fa-plus-circle mr-1"></i>
                <span class="hidden sm:inline">Add New Product</span>
            </a>
        </div>
    </form>


    <!-- Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl mt-6">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-4 py-3 text-center text-md font-bold">#</th>
                    <th class="px-4 py-3 text-center text-md font-bold">Product Name</th>
                    <th class="px-4 py-3 text-center text-md font-bold">Category</th>
                    <th class="px-4 py-3 text-center text-md font-bold">Subcategory</th>
                    <th class="px-4 py-3 text-center text-md font-bold">Price</th>
                    <th class="px-4 py-3 text-center text-md font-bold">Status</th>
                    <th class="px-4 py-3 text-center text-md font-bold">Image</th>
                    <th class="px-4 py-3 text-center text-md font-bold">Actions</th>
                    <th class="px-4 py-3 text-center text-md font-bold" style="width:115px;">Qr-Code</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition-colors text-center duration-200">
                    <td class="px-4 py-4 text-md text-gray-800"><?php echo e($product->id); ?></td>
                    <td class="px-4 py-4 text-sm text-gray-800 uppercase font-semibold"><?php echo e($product->name); ?></td>
                    <td class="px-4 py-4 text-md text-gray-800"><?php echo e($product->category->name ?? 'No category'); ?>

                    </td>
                    <td class="px-4 py-4 text-md text-gray-800">
                        <?php echo e($product->subcategory->name ?? 'No subcategory'); ?>

                    </td>

                    <td class="px-4 py-4 text-md text-gray-800">$<?php echo e(number_format($product->price, 2)); ?></td>
                    <td class="px-4 py-4 text-md text-center">
                        <button
                            onclick="openStatusConfirmationModal(<?php echo e($product->id); ?>, '<?php echo e($product->status); ?>')"
                            class="px-4 py-2 rounded-md transition duration-300 toast-btn <?php echo e($product->status == 'active' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'); ?>">
                            <?php echo e($product->status == 'active' ? 'Active' : 'Inactive'); ?>

                        </button>
                    </td>
                    <td class="px-4 py-4 text-md text-center">
    <!-- Image Carousel Section -->
    <div class="image-carousel-container">
        <?php
        $images = explode(',', $product->image); // Convert the comma-separated string into an array
        ?>

        <?php if(is_array($images) && count($images) > 0): ?>
        <!-- Carousel Wrapper -->
        <div id="carousel-<?php echo e($product->id); ?>" class="carousel relative">
            <!-- Carousel Images -->
            <div class="carousel-images">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                    <img src="<?php echo e(asset('storage/products' . $products)); ?>" 
                         alt="<?php echo e($product->name); ?>"
                         class="w-25 h-2 object-cover rounded-md mx-auto cursor-pointer">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php else: ?>
        <img src="<?php echo e(asset('images/placeholder.png')); ?>" 
             alt="<?php echo e($product->name); ?>"
             class="w-35 h-20 object-cover rounded-md mx-auto cursor-pointer">
        <?php endif; ?>
    </div>
</td>


                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            // Loop through each carousel and add auto-play functionality
                            document.querySelectorAll('.carousel').forEach(function(carousel) {
                                const items = carousel.querySelectorAll('.carousel-item');
                                const totalItems = items.length;
                                let currentIndex = 0;

                                // Function to show the next image
                                function showNext() {
                                    currentIndex = (currentIndex + 1) % totalItems;
                                    updateCarousel();
                                }

                                // Function to update the carousel (move to the next image)
                                function updateCarousel() {
                                    const offset = -currentIndex * 100; // Slide by 100% width of each image
                                    carousel.querySelector('.carousel-images').style.transform = `translateX(${offset}%)`;
                                }

                                // Set interval to auto-play every 3 seconds
                                setInterval(showNext, 3000); // Change image every 3 seconds
                            });
                        });
                    </script>
                    <td class="px-2 py-4 text-md text-center">
                        <div class="flex justify-center space-x-2">
                            <a href="<?php echo e(route('products.show', $product)); ?>"
                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 flex items-center space-x-2">
                                <i class="fas fa-eye"></i>
                            </a>

                            <a href="<?php echo e(route('products.edit', $product)); ?>"
                                class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center space-x-2">
                                <i class="fas fa-edit"></i>
                            </a>

                            <button type="button"
                                class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 flex items-center space-x-2"
                                onclick="openDeleteModal(<?php echo e($product->id); ?>)">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                    <td class="px-2 py-4 text-md text-center">
                        <button id="qrButton-<?php echo e($product->id); ?>"
                            onclick="toggleQRCodePreview(<?php echo e($product->id); ?>, '<?php echo e($product->name); ?>', '<?php echo e($product->description); ?>', '<?php echo e(number_format($product->price, 2)); ?>', '<?php echo e(ucfirst($product->status)); ?>', '<?php echo e($product->category->name ?? 'No category'); ?>')"
                            class="bg-indigo-500 text-white px-4 py-2 m-auto rounded hover:bg-indigo-600 transition duration-300 flex items-center space-x-2">
                            <i id="qrIcon-<?php echo e($product->id); ?>" class="fas fa-qrcode"></i>
                        </button>

                        <div id="qrCodeContainer-<?php echo e($product->id); ?>" class="mt-4 hidden">
                            <img id="qrCode-<?php echo e($product->id); ?>" src="" alt="QR Code" class="mx-auto">
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        <?php echo e($products->links()); ?>

    </div>

    <?php if($products->isEmpty()): ?>
    <div class="mt-8 text-center text-gray-500">
        <p>No products found. Create a new product to get started!</p>
    </div>
    <?php endif; ?>
</div>


<!-- Status Confirmation Modal -->
<div id="statusModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-xl">
        <div class="flex items-center mb-4">
            <i class="fas fa-exclamation-circle text-yellow-600 text-3xl mr-4"></i>
            <h3 class="text-xl font-semibold text-gray-800">Are you sure you want to change the status?</h3>
        </div>
        <p class="text-gray-700 mb-4 text-center">
            Changing the status will affect the current item’s state in the system. The changes are not reversible.
        </p>
        <div class="flex justify-end gap-4 mt-6">
            <button onclick="closeStatusModal()"
                class="flex items-center justify-center px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition duration-300">
                <i class="fas fa-times-circle mr-2"></i> Cancel
            </button>
            <form id="statusForm" method="POST" class="inline-block">
                <?php echo csrf_field(); ?>
                <button type="submit"
                    class="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-300">
                    <i class="fas fa-check-circle mr-2"></i> Confirm
                </button>
            </form>
        </div>
    </div>
</div>


<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-xl">
        <!-- Modal Header -->
        <div class="flex items-center mb-4">
            <i class="fas fa-archive text-yellow-600 text-3xl mr-4"></i>
            <h3 class="text-xl font-semibold text-gray-800">Are you sure you want to archive this product?</h3>
        </div>
        <!-- Modal Content -->
        <p class="text-gray-700 mb-4 text-center">
            Archiving this product will hide it from the active list but it will not be permanently deleted. You can
            restore it later if needed.
        </p>
        <!-- Modal Footer -->
        <div class="flex justify-end gap-4 mt-6">
            <!-- Cancel Button -->
            <button onclick="closeDeleteModal()"
                class="flex items-center justify-center px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition duration-300">
                <i class="fas fa-times-circle mr-2"></i> Cancel
            </button>
            <!-- Soft Delete Button -->
            <form id="deleteForm" method="POST" class="inline-block">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?> <!-- Keep DELETE method for soft delete -->
                <button type="submit"
                    class="flex items-center justify-center px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition duration-300">
                    <i class="fas fa-archive mr-2"></i> Archive
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.0/build/qrcode.min.js"></script>
<script>
    function openStatusConfirmationModal(productId, currentStatus) {
        statusForm.action = `/products/${productId}/change-status`;
        let actionText = currentStatus === 'active' ? 'Inactivate' : 'Activate';
        statusForm.innerHTML = `
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Confirm to ${actionText}</button>
                `;
        statusModal.classList.remove('hidden');
    }

    function closeStatusModal() {
        statusModal.classList.add('hidden');
    }
    // Function to open delete modal
    function openDeleteModal(productId) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = `/products/${productId}/delete`;
        document.getElementById('deleteModal').classList.remove('hidden');
    }

    // Function to close delete modal
    function closeDeleteModal() {
        document.getElementById('deleteModal').classList.add('hidden');
    }

    // Function to toggle QR code preview
    function toggleQRCodePreview(productId, name, description, price, status, category) {
        const qrCodeContainer = document.getElementById(`qrCodeContainer-${productId}`);
        const qrCodeImage = document.getElementById(`qrCode-${productId}`);
        const qrIcon = document.getElementById(`qrIcon-${productId}`);

        if (qrCodeContainer.classList.contains('hidden')) {
            qrCodeContainer.classList.remove('hidden');
            qrIcon.classList.remove('fa-qrcode');
            qrIcon.classList.add('fa-times-circle');

            const qrData =
                `Name: ${name}\nDescription: ${description}\nPrice: $${price}\nStatus: ${status}\nCategory: ${category}`;

            QRCode.toDataURL(qrData, {
                width: 128,
                height: 128
            }, function(err, url) {
                if (err) {
                    console.error("QR Code generation error:", err);
                    return;
                }
                qrCodeImage.src = url;
            });
        } else {
            qrCodeContainer.classList.add('hidden');
            qrIcon.classList.remove('fa-times-circle');
            qrIcon.classList.add('fa-qrcode');
        }
    }
</script>

<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-16 right-0 z-50 bg-green-500 text-white px-4 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Success Icon -->
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <!-- Success Message -->
    <span><?php echo e(session('success')); ?></span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<!-- Error Toast -->
<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-16 right-10 z-50 bg-red-500 text-white px-4 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Error Icon -->
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <!-- Error Message -->
    <span><?php echo e(session('error')); ?></span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Desktop/sahil_desk/laravel-app/resources/views/products/index.blade.php ENDPATH**/ ?>