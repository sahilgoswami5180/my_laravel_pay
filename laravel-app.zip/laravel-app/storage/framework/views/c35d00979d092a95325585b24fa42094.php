<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Success Icon -->
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <!-- Success Message -->
    <span><?php echo e(session('success')); ?></span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<!-- Error Toast -->
<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Error Icon -->
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <!-- Error Message -->
    <span><?php echo e(session('error')); ?></span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

    <div class="container mx-auto mt-8 px-4">

        <!-- Cart Items -->
        <?php if($cartItems->count() > 0): ?>
            <div class="bg-white shadow-xl rounded-lg p-6 mb-8">
                <h2 class="text-2xl font-semibold mb-4">Items in Cart <i class="fas fa-cart-arrow-down"></i></h2>
                <table class="min-w-full table-auto border-collapse">
                    <thead class="bg-gray-100 text-gray-600">
                        <tr>
                            <th class="border px-4 py-2 text-left">Product</th>
                            <th class="border px-4 py-2 text-left">Price</th>
                            <th class="border px-4 py-2 text-left">Quantity</th>
                            <th class="border px-4 py-2 text-left">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 transition-colors duration-200">
                                <td class="border px-4 py-2 flex items-center">
                                    <img src="<?php echo e(asset('storage/' . $item->product->image)); ?>"
                                        alt="<?php echo e($item->product->name); ?>" class="w-16 h-16 object-cover mr-4 rounded-md">
                                    <span><?php echo e($item->product->name); ?></span>
                                </td>
                                <td class="border px-4 py-2">$<?php echo e(number_format($item->product->price, 2)); ?></td>
                                <td class="border px-4 py-2"><?php echo e($item->quantity); ?></td>
                                <td class="border px-4 py-2">
                                    $<?php echo e(number_format($item->product->price * $item->quantity, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Recommended Products Section -->
            <div class="bg-white shadow-xl rounded-lg p-6 mt-8">
                <h2 class="text-2xl font-semibold mb-4">Recommended for You <i class="fas fa-gift"></i></h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <?php $__currentLoopData = $recommendedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('user.product_details', $product->id)); ?>"
                            class="bg-white p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                class="w-full h-48 object-cover rounded-md mb-4">
                            <h3 class="text-lg font-semibold mt-2 text-gray-800"><?php echo e($product->name); ?></h3>
                            <p class="text-gray-600 text-sm mt-2"><?php echo e(Str::limit($product->description, 100)); ?></p>
                            <p class="text-sm text-gray-500 mt-2">Category: <?php echo e($product->category->name); ?></p>
                            <p class="text-lg font-bold mt-4 text-gray-800">$<?php echo e(number_format($product->price, 2)); ?></p>
                            <div class="mt-4">
                                <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600 transition duration-300">
                                        <i class="fas fa-cart-plus"></i> Add to Cart
                                    </button>
                                </form>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Checkout Summary & Payment Options -->
            <div class="bg-white shadow-xl rounded-lg p-6 mb-8">
                <h2 class="text-xl font-semibold mb-4">Checkout Summary <i class="fas fa-calculator"></i></h2>
                <div class="flex justify-between mb-4">
                    <span class="text-lg font-medium">Total:</span>
                    <span class="text-lg font-medium">$<?php echo e(number_format($total, 2)); ?></span>
                </div>

                <!-- Payment Options -->
                <div class="flex space-x-6">
                    <!-- Cash on Delivery Option -->
                    <div class="w-1/2">
                        <form action="<?php echo e(route('checkout.cod')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                            class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300">
                                <i class="fas fa-cash-register"></i> Cash on Delivery
                            </button>
                        </form>
                    </div>

                    <!-- Stripe Checkout Form -->
                    <div class="w-1/2">
                        <form action="<?php echo e(route('checkout.process')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300">
                                <i class="fa-brands fa-stripe"></i> Pay with Stripe
                            </button>
                        </form>
                    </div>
                </div>

            </div>
        <?php else: ?>
            <div class="text-center">
                <p class="text-gray-500">No items added yet. Browse and add products to your cart to proceed with checkout.
                    <i class="fas fa-cart-arrow-down"></i></p>
            </div>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/user/checkout.blade.php ENDPATH**/ ?>