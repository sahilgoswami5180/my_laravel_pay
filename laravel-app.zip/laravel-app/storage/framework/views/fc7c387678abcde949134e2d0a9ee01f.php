<form method="post" action="https://secure.paytm.in/theia/processTransaction" name="paytm_form">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $paytmParams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button type="submit" class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300 mt-4">
        Pay with Paytm
    </button>
</form>
<script type="text/javascript">
    document.paytm_form.submit();
</script>
<?php /**PATH /home/xceltec-28/Desktop/sahil_desk/laravel-app/resources/views/user/paytm.blade.php ENDPATH**/ ?>