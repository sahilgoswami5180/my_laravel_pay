<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-6 px-4">

    <!-- Breadcrumb Navigation -->
    <nav class="flex text-sm text-gray-600 mb-6 items-center">
        <a href="<?php echo e(route('dashboard')); ?>"
            class="flex items-center <?php echo e(Request::is('dashboard') ? 'text-blue-500' : ''); ?>">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <a href="<?php echo e(route('products.index')); ?>"
            class="flex items-center <?php echo e(Request::is('products') || Request::is('products/*') ? 'text-blue-500' : ''); ?>">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Products</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <span class="text-xs text-gray-500">Edit</span>
    </nav>

    <!-- Full-Screen Width Card Container for the Form -->
    <div class="w-full bg-white p-8 rounded-lg shadow-xl">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-semibold text-gray-800 flex items-center">
                <i class="fas fa-edit mr-2"></i> Edit Product
            </h2>
        </div>

        <!-- Form to Edit Product -->
        <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data"
            class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Grid Layout for Side-by-Side Inputs -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Product Category -->
                <div>
                    <label for="category_id" class="block text-sm font-medium text-gray-700">
                        Category <span class="text-red-500">*</span>
                    </label>
                    <select name="category_id" id="category_id"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"
                            <?php echo e(old('category_id', $product->category_id) == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Product Name -->
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700">
                        Product Name <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $product->name)); ?>"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-tag absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Product Description (With Character Count) -->
            <div>
                <label for="description" class="block text-sm font-medium text-gray-700">
                    Product Description <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <textarea name="description" id="description" rows="4" maxlength="255" oninput="updateCharCount()"
                        class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e(old('description', $product->description)); ?></textarea>
                    <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
                <div class="flex justify-end text-sm text-gray-500 mt-1">
                    <span id="charCount"><?php echo e(strlen(old('description', $product->description))); ?></span> / 255
                </div>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Product Price and Status (Side-by-Side) -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Product Price -->
                <div>
                    <label for="price" class="block text-sm font-medium text-gray-700">
                        Product Price <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <input type="number" name="price" id="price" value="<?php echo e(old('price', $product->price)); ?>"
                            step="0.01" min="0"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i
                            class="fas fa-dollar-sign absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Product Status -->
                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700">
                        Product Status <span class="text-red-500">*</span>
                    </label>
                    <select name="status" id="status"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="" disabled <?php echo e(old('status') ? '' : 'selected'); ?>>Please choose a status
                        </option>
                        <option value="active" <?php echo e(old('status', $product->status) == 'active' ? 'selected' : ''); ?>>
                            Active</option>
                        <option value="inactive" <?php echo e(old('status', $product->status) == 'inactive' ? 'selected' : ''); ?>>
                            Inactive</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Product Image (Optional) -->
            <div>
                <label for="image" class="block text-sm font-medium text-gray-700">
                    Product Image (Optional)
                </label>
                <input type="file" name="images[]" id="images" accept="image/*" multiple
           class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
   
                <div class="mt-4 flex gap-6">
                    <?php if($product->images): ?>
                    <?php
                    $images = explode(',', $product->images); // Convert the comma-separated string into an array
                    ?>

                    <div class="flex flex-wrap gap-4">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w-32 h-32 relative">
                            <!-- Display each image -->
                            <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="Product Image"
                                class="w-full h-full object-cover rounded">
                            <p class="mt-2 text-sm text-gray-500 text-center">Current Image</p>

                            <!-- Image Deletion Form -->
                            <!-- <form action="<?php echo e(route('products.deleteImage', [$product->id, basename($image)])); ?>" method="POST" class="absolute top-0 right-0 p-1">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="text-red-600 hover:text-red-800" onclick="return confirm('Are you sure you want to delete this image?')">
                        <i class="fa-solid fa-trash-alt"></i>
                    </button>
                </form> -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>


                    <!-- Display new image preview if selected -->
                    <div id="imagePreviewContainer" class="w-32 h-32 hidden">
                        <img id="imagePreview" src="#" alt="New Image Preview"
                            class="w-full h-full object-cover rounded">
                        <p class="mt-2 text-sm text-gray-500 text-center">New Image</p>
                    </div>
                </div>

                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Submit and Cancel Buttons -->
            <div class="flex justify-end space-x-4 mt-6">
                <a href="<?php echo e(route('products.index')); ?>"
                    class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </a>
                <button type="submit"
                    class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                    <i class="fas fa-save mr-2"></i> Save Changes
                </button>
            </div>
        </form>
    </div>

</div>

<!-- Success and Error Toasts -->
<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<script>
    // Function to update character count for the description field
    function updateCharCount() {
        const textarea = document.getElementById('description');
        const charCount = document.getElementById('charCount');
        charCount.textContent = textarea.value.length; // Update character count
    }

    // Function to preview new image before upload
    function previewImage() {
        const fileInput = document.getElementById('image'); // The file input element
        const imagePreview = document.getElementById('imagePreview'); // Image element for preview
        const imagePreviewContainer = document.getElementById('imagePreviewContainer'); // Container for preview
        const file = fileInput.files[0]; // Get the first selected file

        // If no file is selected, clear the preview and exit
        if (!file) {
            imagePreviewContainer.classList.add('hidden');
            return;
        }

        // Validate file size (max 10MB)
        if (file.size > 10 * 1024 * 1024) { // 10MB in bytes
            alert('Image size must be less than or equal to 10MB.');
            imagePreviewContainer.classList.add('hidden');
            return;
        }

        // Validate file type (only jpeg, png, jpg allowed)
        const validExtensions = ['image/jpeg', 'image/png', 'image/jpg'];
        if (!validExtensions.includes(file.type)) {
            alert('Only image files (jpeg, png, jpg) are allowed.');
            imagePreviewContainer.classList.add('hidden');
            return;
        }

        // If file is valid, create a FileReader to preview the image
        const reader = new FileReader();
        reader.onload = function(event) { // Use `event` instead of `e`
            const result = event.target.result; // Access `result` correctly
            imagePreview.src = result; // Set the preview image
            imagePreviewContainer.classList.remove('hidden'); // Show the preview container
        };
        reader.readAsDataURL(file); // Read the file as a Data URL
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Desktop/sahil_desk/laravel-app/resources/views/products/edit.blade.php ENDPATH**/ ?>