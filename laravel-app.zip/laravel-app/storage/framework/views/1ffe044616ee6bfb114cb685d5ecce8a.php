<?php $__env->startSection('title', 'Product Details'); ?>

<?php $__env->startSection('content'); ?>
<!-- Back Icon -->
<section class="py-4 bg-gray-100">
    <div class="container mx-auto">
        <a href="<?php echo e(url()->previous()); ?>" class="flex items-center text-blue-500 hover:text-blue-600 font-medium">
            <i class="fas fa-arrow-left mr-2"></i> Back
        </a>
    </div>
</section>

<!-- Product Details Section -->
<section class="py-20 bg-gray-100">
    <div class="container mx-auto">
        <div class="flex flex-col lg:flex-row gap-12">
            <!-- Product Image -->
            <div class="lg:w-1/2">
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-96 object-cover rounded-lg shadow-lg">
            </div>

            <!-- Product Info -->
            <div class="lg:w-1/2">
                <h2 class="text-3xl font-bold text-gray-800"><?php echo e($product->name); ?></h2>
                <p class="text-sm text-gray-500 mt-2">Category: <?php echo e($product->category->name); ?></p>
                <p class="text-lg text-gray-600 mt-4"><?php echo e($product->description); ?></p>

                <p class="text-2xl font-bold text-gray-800 mt-6">$<?php echo e(number_format($product->price, 2)); ?></p>

                <!-- Add to Cart Button -->
                <div class="mt-6">
                    <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600">
                            Add to Cart
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Related Products Section -->
<section class="py-12 bg-white">
    <div class="container mx-auto text-center">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Related Products</h2>

        <!-- Product Cards Grid -->
        
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/user/product_details.blade.php ENDPATH**/ ?>