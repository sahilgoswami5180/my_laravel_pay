<?php $__env->startSection('content'); ?>
    <div class="bg-gray-100 flex items-center justify-center min-h-screen">
        <!-- Contact Us Form -->
        <div class="bg-white shadow-md rounded-lg p-6 w-full max-w-lg">
            <h2 class="text-2xl font-bold text-center text-gray-700 mb-4">Contact Us</h2>

            <!-- Success Toast -->
            <?php if(session('success')): ?>
                <div id="successToast"
                    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-check-circle text-white text-2xl"></i>
                    <span><?php echo e(session('success')); ?></span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#successToast').style.display = 'none';
                    }, 4000);
                </script>
            <?php endif; ?>

            <!-- Error Toast -->
            <?php if(session('error')): ?>
                <div id="errorToast"
                    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-times-circle text-white text-2xl"></i>
                    <span><?php echo e(session('error')); ?></span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#errorToast').style.display = 'none';
                    }, 4000);
                </script>
            <?php endif; ?>

            <!-- Form Start -->
            <form action="<?php echo e(url('/contact-us')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Name Field -->
                <div class="mb-6">
                    <label for="name" class="block text-sm font-medium text-gray-700">Name <span
                            class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="text" name="name" id="name"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required>
                        <i
                            class="fas fa-user absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
                    </div>
                </div>

                <!-- Email Field -->
                <div class="mb-6">
                    <label for="email" class="block text-sm font-medium text-gray-700">Email <span
                            class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="email" name="email" id="email"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required>
                        <i
                            class="fas fa-envelope absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
                    </div>
                </div>

                <!-- Message Field -->
                <div class="mb-6">
                    <label for="message" class="block text-sm font-medium text-gray-700">Message <span
                            class="text-red-500">*</span></label>
                    <div class="relative">
                        <textarea name="message" id="message"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            rows="5" required></textarea>
                        <i
                            class="fas fa-comment-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition">
                    <i class="fas fa-paper-plane mr-2"></i> Send Message
                </button>
            </form>

            <!-- Back Link -->
            <div class="mt-4 text-center">
                <a href="<?php echo e(url('/')); ?>" class="text-blue-500 hover:underline text-sm">
                    <i class="fas fa-home mr-1"></i> Back to Home
                </a>
            </div>
        </div>
    </div>

    <script>
        // Hide toast notifications after 4 seconds
        setTimeout(() => {
            document.querySelector('#successToast')?.style.display = 'none';
            document.querySelector('#errorToast')?.style.display = 'none';
        }, 4000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/user/contact-us.blade.php ENDPATH**/ ?>