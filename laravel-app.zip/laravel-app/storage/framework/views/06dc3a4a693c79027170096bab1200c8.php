<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/xceltec-28/Documents/laravel-auth-app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>