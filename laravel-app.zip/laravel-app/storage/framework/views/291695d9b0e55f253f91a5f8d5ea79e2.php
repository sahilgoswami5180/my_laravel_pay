<?php $__env->startSection('content'); ?>
    <div class="container w-full m-auto py-8 p-3">
        <!-- Heading and Action Buttons -->
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-semibold text-gray-800">Inbox</h1>
            <div class="flex space-x-4 ml-auto">
                <!-- Mark All as Read Button with Tooltip -->
                <form action="<?php echo e(route('contact-msg.mark-all-as-read')); ?>" method="POST" class="inline relative group">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-blue-500 hover:text-blue-700">
                        <i class="fas fa-check-circle text-xl"></i>
                    </button>
                    <!-- Tooltip for Mark All as Read Button -->
                    <div
                        class="tooltip absolute left-1/2 transform -translate-x-1/2 bottom-12 bg-gray-800 text-white text-xs rounded-md py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        Mark all as Read
                    </div>
                </form>

                <!-- Dropdown for Delete Options with Tooltip -->
                <div class="relative group">
                    <button class="text-red-500 hover:text-red-700" id="deleteDropdownButton">
                        <i class="fas fa-trash-alt text-xl"></i>
                    </button>
                    <div id="deleteDropdownMenu"
                        class="absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-md z-10 hidden">
                        <ul class="space-y-2">
                            <!-- Delete Selected Messages -->
                            <li>
                                <button id="deleteSelectedBtn"
                                    class="block text-sm text-red-500 hover:text-red-700 px-4 py-2 w-full text-left">
                                    Delete Selected Messages
                                </button>
                            </li>
                            <!-- Delete All Read Messages -->
                            <li>
                                <button id="deleteAllReadBtn"
                                    class="block text-sm text-red-500 hover:text-red-700 px-4 py-2 w-full text-left">
                                    Delete All Read Messages
                                </button>
                            </li>
                        </ul>
                    </div>

                    <!-- Tooltip for Delete Button -->
                    <div
                        class="tooltip absolute left-1/2 transform -translate-x-1/2 top-12 bg-gray-800 text-white text-xs rounded-md py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        Delete Messages
                    </div>
                </div>
            </div>
        </div>



        <div class="space-y-8">
            <!-- Unread Messages Section -->
            <div>
                <!-- Heading Section with Icon and Content -->
                <div class="w-full bg-blue-400 p-4 rounded-t-md">
                    <h2 class="text-xl font-semibold text-white text-center flex items-center justify-center space-x-2">
                        <i class="fas fa-inbox text-blue-900 text-2xl"></i>
                        <span>Unread Messages</span>
                    </h2>
                    <p class="text-center text-sm text-gray-900 mt-2">You have unread messages from users. Review and take
                        action as needed.</p>
                </div>

                <!-- Unread Messages List -->
                <ul class="space-y-4">
                    <?php $__currentLoopData = $contactUsSubmissions->where('read', false); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="p-4 border-b border-gray-200 bg-white hover:bg-gray-50 transition-colors duration-200 ease-in-out rounded-md shadow-md message-item"
                            data-id="<?php echo e($submission->id); ?>" ondblclick="toggleSelection(this)">

                            <div class="relative flex items-start space-x-3">
                                <!-- Unread Icon -->
                                <i class="fas fa-info-circle text-blue-500 text-xl"></i>

                                <!-- Sticky form for the "Mark as Read" button -->
                                <form action="<?php echo e(route('contact-msg.mark-as-read', $submission->id)); ?>" method="POST"
                                    class="absolute top-2 right-2">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="text-sm bg-blue-500 hover:bg-blue-700 font-medium text-white p-2 rounded-lg">
                                        <i class="fas fa-check-circle mr-1"></i> Mark as Read
                                    </button>
                                </form>
                            </div>

                            <div class="flex-1">
                                <div class="flex justify-between items-center">
                                    <div class="flex space-x-4">
                                        <!-- Name with Icon -->
                                        <div class="flex items-center space-x-1">
                                            <i class="fas fa-user text-sm text-gray-500" style="font-size: 12px;"></i>
                                            <label class="font-semibold text-gray-500"
                                                style="font-size: 12px;">Name:</label>
                                            <span class="text-gray-800"><?php echo e($submission->name); ?></span>
                                        </div>

                                        <!-- Email with Icon -->
                                        <div class="flex items-center space-x-1 ml-auto">
                                            <i class="fas fa-envelope text-sm text-gray-500" style="font-size: 12px;"></i>
                                            <label class="text-sm font-semibold text-gray-500"
                                                style="font-size: 12px;">Email:</label>
                                            <span class="text-gray-500"><?php echo e($submission->email); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-2">
                                    <!-- Message Preview -->
                                    <label class="text-sm font-semibold text-gray-500"
                                        style="font-size: 12px;">Message:</label>
                                    <p class="text-sm text-gray-600 bg-gray-200 w-full h-10 px-2 py-1 rounded-lg mt-2">
                                        <?php echo e(Str::limit($submission->message, 80)); ?>

                                    </p>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>


            <!-- Read Messages Section -->
            <div>
                <!-- Heading Section with Icon and Content -->
                <div class="w-full bg-blue-400 p-4 rounded-t-md">
                    <h2 class="text-xl font-semibold text-white text-center flex items-center justify-center space-x-2">
                        <i class="fas fa-envelope-open text-green-500 text-2xl"></i>
                        <span>Read Messages</span>
                    </h2>
                    <p class="text-center text-sm text-gray-900 mt-2">These messages have been reviewed. You can take action
                        accordingly.</p>
                </div>
                <!-- Unread Messages List -->
                <ul class="space-y-4">
                    <?php $__currentLoopData = $contactUsSubmissions->where('read', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="p-4 border-b border-gray-200 bg-white hover:bg-gray-50 transition-colors duration-200 ease-in-out rounded-md shadow-sm message-item"
                            data-id="<?php echo e($submission->id); ?>" ondblclick="toggleSelection(this)">

                            <div class="flex items-start space-x-3">
                                <!-- Read Icon -->
                                <i class="fas fa-check-circle text-green-500 text-xl"></i>

                                <div class="flex-1">
                                    <div class="flex justify-between items-center">
                                        <div class="flex space-x-4">
                                            <!-- Name with Icon -->
                                            <div class="flex items-center space-x-1">
                                                <i class="fas fa-user text-sm text-gray-500" style="font-size: 12px;"></i>
                                                <label class="font-semibold text-gray-500"
                                                    style="font-size: 12px;">Name:</label>
                                                <span class="text-gray-800"><?php echo e($submission->name); ?></span>
                                            </div>

                                            <!-- Email with Icon -->
                                            <div class="flex items-center space-x-1 ml-auto">
                                                <i class="fas fa-envelope text-sm text-gray-500"
                                                    style="font-size: 12px;"></i>
                                                <label class="text-sm font-semibold text-gray-500"
                                                    style="font-size: 12px;">Email:</label>
                                                <span class="text-gray-500"><?php echo e($submission->email); ?></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mt-2">
                                        <!-- Message Preview -->
                                        <label class="text-sm font-semibold text-gray-500"
                                            style="font-size: 12px;">Message:</label>
                                        <p class="text-sm text-gray-600 bg-gray-100 p-2 rounded-lg mt-2">
                                            <?php echo e(Str::limit($submission->message, 80)); ?>

                                        </p>
                                    </div>

                                    <!-- Action Buttons (Optional) -->
                                    <div class="mt-4 flex justify-end space-x-4">
                                        <button class="text-sm text-blue-500 hover:text-blue-700 font-medium">
                                            <i class="fas fa-reply mr-2"></i> Reply
                                        </button>
                                        <button class="text-sm text-red-500 hover:text-red-700 font-medium">
                                            <i class="fas fa-trash mr-2"></i> Delete
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>


        </div>
    </div>

    <script>
        // Track selected messages by ID
        const selectedMessages = new Set();

        // Toggle message selection on double-click
        function toggleSelection(element) {
            const messageId = element.getAttribute('data-id');

            if (selectedMessages.has(messageId)) {
                // Deselect the message
                selectedMessages.delete(messageId);
                element.classList.remove('bg-blue-100'); // Remove background color for deselection
            } else {
                // Select the message
                selectedMessages.add(messageId);
                element.classList.add('bg-blue-100'); // Highlight the message
            }
        }

        // Toggle delete dropdown visibility
        document.getElementById('deleteDropdownButton').addEventListener('click', function() {
            const menu = document.getElementById('deleteDropdownMenu');
            menu.classList.toggle('hidden');
        });

        // Delete Selected Messages Button Click
        document.getElementById('deleteSelectedBtn').addEventListener('click', function() {
            if (selectedMessages.size > 0 && confirm('Are you sure you want to delete the selected messages?')) {
                fetch('<?php echo e(route('contact-msg.delete-selected')); ?>', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    },
                    body: JSON.stringify({
                        ids: Array.from(selectedMessages)
                    }),
                }).then(response => {
                    if (response.ok) {
                        window.location.reload(); // Reload the page after deleting
                    }
                });
            } else {
                alert('No messages selected.');
            }
        });

        // Delete All Read Messages Button Click
        document.getElementById('deleteAllReadBtn').addEventListener('click', function() {
            if (confirm('Are you sure you want to delete all read messages?')) {
                fetch('<?php echo e(route('contact-msg.clear-all')); ?>', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    },
                }).then(response => {
                    if (response.ok) {
                        window.location.reload(); // Reload the page after deleting
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/inbox.blade.php ENDPATH**/ ?>