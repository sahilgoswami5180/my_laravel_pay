<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="UTF-8">
    <!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge"><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="images/favicon.png" rel="shortcut icon">
    <title>Ludus - Electronics, Apparel, Computers, Books, DVDs & more</title>
    <!-- bootstrap core css -->
    <link href="<?php echo e(asset('./css/bootstrap.css')); ?>" rel="stylesheet" />
    <!-- font awesome style -->
    <link href="<?php echo e(asset('./css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('./css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color2.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color3.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color4.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color5.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color6.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color7.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color8.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color9.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/app.color10.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/utility.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('./css/vendor.css')); ?>" rel="stylesheet" />

    <link rel="shortcut icon" href="public/favicon.png" />

    <!--====== Google Font ======-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">

    <!--====== Vendor Css ======-->
    <link rel="stylesheet" href="<?php echo e(asset('home/css/vendor.css')); ?>">

    <!--====== Utility-Spacing ======-->
    <link rel="stylesheet" href="<?php echo e(asset('home/css/utility.css')); ?>">

    <!--====== App ======-->
    <link rel="stylesheet" href="<?php echo e(asset('home/css/app.css')); ?>">
</head>

<body class="config">
    <div class="preloader is-active">
        <div class="preloader__wrap">

            <img class="preloader__img" src="images/preloader.png" alt="">
        </div>
    </div>

    <!--====== Main App ======-->
    <div id="app">

        <!--====== App Content ======-->
        <div class="app-content">

            <!--====== Primary Slider ======-->
            <div class="s-skeleton s-skeleton--h-640 s-skeleton--bg-grey">
                <div class="owl-carousel primary-style-3" id="hero-slider">
                    <div class="hero-slide hero-slide--7" style="background-image: url('images/e1.jpg');">
                        <div class="primary-style-3-wrap">
                            <div class="container">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="slider-content slider-content--animation">
                                            <span class="content-span-1 u-c-white">Update Your Fashion</span>
                                            <span class="content-span-2 u-c-white">10% Discount on Outwear</span>
                                            <span class="content-span-3 u-c-white">Find outwear on best prices</span>
                                            <span class="content-span-4 u-c-white">Starting At
                                                <span class="u-c-brand">$100.00</span></span>
                                            <a class="shop-now-link btn--e-brand" href="shop-side-version-2.html">SHOP NOW</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hero-slide hero-slide--8" style="background-image: url('images/e2.png');">
                        <div class="primary-style-3-wrap">
                            <div class="container">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="slider-content slider-content--animation">

                                            <span class="content-span-1 u-c-white">Open Your Eyes</span>

                                            <span class="content-span-2 u-c-white">10% Off On Intimates</span>

                                            <span class="content-span-3 u-c-white">Find intimates on best prices</span>

                                            <span class="content-span-4 u-c-white">Starting At

                                                <span class="u-c-brand">$100.00</span></span>

                                            <a class="shop-now-link btn--e-brand" href="shop-side-version-2.html">SHOP NOW</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hero-slide hero-slide--9" style="background-image: url('images/e3.png');">
                        <div class="primary-style-3-wrap">
                            <div class="container">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="slider-content slider-content--animation">
                                            <span class="content-span-1 u-c-white">Find Top Brands</span>
                                            <span class="content-span-2 u-c-white">10% Off On Outwear</span>
                                            <span class="content-span-3 u-c-white">Find outwear on best prices</span>
                                            <span class="content-span-4 u-c-white">Starting At
                                                <span class="u-c-brand">$100.00</span></span>
                                            <a class="shop-now-link btn--e-brand" href="shop-side-version-2.html">SHOP NOW</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--====== End - Primary Slider ======-->
            <!--====== Section 1 ======-->
            <div class="u-s-p-y-60">
            </div>
            <div class="u-s-p-b-60">

                <!--====== Section Intro ======-->
                <div class="section__intro u-s-m-b-46">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="section__text-wrap">
                                    <h1 class="section__heading u-c-secondary u-s-m-b-12">PRODUCTS</h1>

                                    <span class="section__span u-c-silver">NEWLY ADDED PRODUCTS</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Intro ======-->
                <!-- Sidebar (Filter Form) -->
                <div class="w-1/4 bg-white p-4 rounded-md shadow-lg mr-8">
                    <h3 class="text-xl font-semibold text-gray-800 mb-4">Filter Products</h3>
                    <!-- Filter Form -->
                    <form action="<?php echo e(route('user.index')); ?>" method="GET">
                        <!-- Category Filter -->
                        <div class="mb-4">
                            <label for="category" class="block text-gray-600 mb-2">Category</label>
                            <select name="category_id" class="w-full p-2 border border-gray-300 rounded-md">
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e(request('category_id') == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <!-- Price Range Filter -->
                        <div class="mb-4">
                            <label for="price_range" class="block text-gray-600 mb-2">Max Price</label>
                            <input type="range" name="price_range" min="0" max="100000" value="<?php echo e(request('price_range', 100000)); ?>"
                                class="w-full p-2 border border-gray-300 rounded-md" id="priceRangeSlider" />
                            <p class="mt-2 text-gray-600">Max Price: $<span id="priceDisplay"><?php echo e(number_format(request('price_range', 100000))); ?></span></p>
                        </div>
                        <!-- Submit Button -->
                        <button type="submit"
                            class="w-full p-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">Filter</button>
                    </form>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const priceRangeSlider = document.getElementById('priceRangeSlider');
                        const priceDisplay = document.getElementById('priceDisplay');

                        priceRangeSlider.addEventListener('input', function() {
                            priceDisplay.textContent = priceRangeSlider.value;
                        });
                    });
                </script>

                <!--====== Section Content ======-->
                <!-- Main Content Section -->
                <div id="mainContent" class="content">
                    <?php if($products->isEmpty()): ?>
                    <div
                        class="max-w-3xl mx-auto bg-white shadow-lg rounded-lg p-6 flex flex-col items-center justify-center text-center">
                        <i class="fas fa-search text-6xl text-gray-500 mb-4"></i>
                        <h2 class="text-2xl font-semibold text-gray-700 mb-2">No Products Found</h2>
                        <p class="text-gray-500">Sorry, we couldn't find any products that match your search.</p>
                    </div>

                    <div class="mt-6 text-center">
                        <a href="<?php echo e(route('user.index')); ?>"
                            class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Go Back to Home</a>
                    </div>
                    <?php else: ?>
                    <div class="container mx-auto text-center py-4">
                        <h2 class="text-2xl font-bold text-gray-800 mb-2">Featured Products</h2>
                        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $isInCart = isset($cartItems[$product->id]);
                            $images = explode(',', $product->images); // Assuming product images are stored as comma-separated strings
                            ?>

                            <!-- Product Card -->
                            <div class="relative bg-white rounded-lg shadow-lg overflow-hidden group transform transition-all duration-300"
                                style="height: 400px; margin-left:-10px;">


                                <!-- Image Carousel Section -->
                                <div class="image-carousel-container">
                                    <?php if(is_array($images) && count($images) > 0): ?>
                                    <div id="carousel-<?php echo e($product->id); ?>" class="carousel relative w-full h-56">
                                        <!-- Carousel Images -->
                                        <div class="carousel-images flex overflow-hidden relative w-full h-full">
                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div
                                                class="carousel-item <?php echo e($index == 0 ? 'active' : 'hidden'); ?> w-full flex-shrink-0">
                                                <img src="<?php echo e(asset('storage/' . $image)); ?>"
                                                    alt="<?php echo e($product->name); ?>"
                                                    class="w-full h-full object-cover rounded-md mx-auto">
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        <!-- Carousel Navigation (Next/Previous Buttons) -->
                                        <button type="button"
                                            class="absolute left-0 top-1/2 transform -translate-y-1/2 px-4 py-2 text-white bg-gray-600 bg-opacity-50 hover:bg-opacity-75"
                                            onclick="moveCarousel('prev', <?php echo e($product->id); ?>)">
                                            <i class="fas fa-chevron-left"></i>
                                        </button>
                                        <button type="button"
                                            class="absolute right-0 top-1/2 transform -translate-y-1/2 px-4 py-2 text-white bg-gray-600 bg-opacity-50 hover:bg-opacity-75"
                                            onclick="moveCarousel('next', <?php echo e($product->id); ?>)">
                                            <i class="fas fa-chevron-right"></i>
                                        </button>
                                    </div>
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('images/placeholder.png')); ?>" alt="<?php echo e($product->name); ?>"
                                        class="w-full h-56 object-cover rounded-md mx-auto">
                                    <?php endif; ?>
                                </div>

                                <!-- Product Details -->
                                <a href="<?php echo e(route('user.product_details', $product->id)); ?>">
                                    <div class="px-4 pb-0 text-left" style="margin: 18px -10px;">
                                        <h3 class="text-xl font-semibold text-gray-800 mb-2"><?php echo e($product->name); ?></h3>
                                        <h3 class="text-xl font-semibold text-gray-800 mb-2">₹ <?php echo e($product->price); ?></h3>
                                        <p class="text-gray-600 text-sm mb-4">
                                            <?php echo e(Str::limit($product->description, 90, '...')); ?>

                                        </p>

                                        <!-- Action Buttons (Add to Cart or Quantity Control) -->
                                        <?php if($isInCart): ?>
                                        <div class="mt-0 flex items-center space-x-4">
                                            <!-- Quantity Form -->
                                            <form action="<?php echo e(route('cart.updateQuantity', $product)); ?>"
                                                method="POST" class="inline-flex items-center space-x-3">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <span
                                                    class="bg-gray-100 rounded-md text-lg font-semibold text-center inline-block p-3 w-12">
                                                    <?php echo e($cartItems[$product->id]['quantity']); ?>

                                                </span>

                                                <div class="flex space-x-2">
                                                    <!-- Minus Button -->
                                                    <button type="submit" name="quantity"
                                                        value="<?php echo e($cartItems[$product->id]['quantity'] - 1); ?>"
                                                        class="bg-gray-300 text-gray-700 hover:bg-gray-400 px-4 py-2 rounded-md transition duration-300 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                                                        <?php echo e($cartItems[$product->id]['quantity'] <= 1 ? 'disabled' : ''); ?>>
                                                        <i class="fas fa-minus"></i>
                                                    </button>

                                                    <!-- Plus Button -->
                                                    <button type="submit" name="quantity"
                                                        value="<?php echo e($cartItems[$product->id]['quantity'] + 1); ?>"
                                                        class="bg-gray-300 text-gray-700 hover:bg-gray-400 px-4 py-2 rounded-md transition duration-300 flex items-center justify-center">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                            </form>

                                            <!-- Delete Button Form -->
                                            <form action="<?php echo e(route('cart.remove', $product)); ?>" method="POST"
                                                class="inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="text-white flex items-center bg-red-600 py-1 rounded-lg text-center px-4 justify-center space-x-2 hover:text-red-700 mt-2 w-20 justify-center">
                                                    <i class="fas fa-trash-alt text-lg"></i>
                                                </button>
                                            </form>
                                        </div>
                                        <?php else: ?>
                                        <!-- Add to Cart Button -->
                                        <div
                                            class="relative bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-1 mt-6 mx-2 justify-center items-center">
                                            <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST"
                                                class="w-auto">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="w-full flex items-center justify-center bg-blue-500 text-white p-2 rounded-md font-medium hover:bg-blue-600 transition">
                                                    <i class="fas fa-cart-plus mr-2"></i> Add to Cart
                                                </button>
                                            </form>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <!--====== End - Section 3 ======-->
            <script>
                function moveCarousel(direction, productId) {
                    const carousel = document.getElementById(`carousel-${productId}`);
                    const items = carousel.querySelectorAll('.carousel-item');
                    let activeIndex = -1;

                    // Find the currently active item
                    items.forEach((item, index) => {
                        if (item.classList.contains('active')) {
                            activeIndex = index;
                        }
                    });

                    // Remove the 'active' class from the current item
                    items[activeIndex].classList.remove('active');
                    items[activeIndex].classList.add('hidden');

                    // Determine the new active index based on the direction
                    if (direction === 'next') {
                        activeIndex = (activeIndex + 1) % items.length; // Wrap around to the first item if we reach the end
                    } else if (direction === 'prev') {
                        activeIndex = (activeIndex - 1 + items.length) % items
                            .length; // Wrap around to the last item if we reach the beginning
                    }

                    // Add the 'active' class to the new item
                    items[activeIndex].classList.remove('hidden');
                    items[activeIndex].classList.add('active');
                }
            </script>
            <style>
                .carousel-item.hidden {
                    display: none;
                }

                .carousel-item.active {
                    display: block;
                }
            </style>
            <!--====== Section 4 ======-->
            <div class="u-s-p-b-60">
                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <!-- Category Slider Section (Exploring Categories) -->
                                <div class="container mx-auto text-center">
                                    <!-- Explore Categories -->
                                    <h2 class="text-3xl font-semibold text-gray-800 mb-8">Explore Our Categories</h2>
                                    <div class="relative">
                                        <div class="flex overflow-hidden space-x-6 px-4 py-2 scrollbar-hidden" id="category-slider">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(route('user.categorywiseproduct', $category->id)); ?>"
                                                class="category-btn bg-gradient-to-r from-indigo-500 via-blue-500 to-teal-500 text-white px-8 py-3 rounded-lg font-medium hover:scale-105 transform transition-all duration-300 ease-in-out shadow-lg hover:shadow-xl flex-shrink-0">
                                                <?php echo e($category->name); ?>

                                            </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <button id="prev-btn" class="absolute top-1/2 left-4 transform -translate-y-1/2 text-black p-4 transition-all ease-in-out duration-300 shadow-lg">
                                            <i class="fas fa-chevron-left text-xl"></i>
                                        </button>
                                        <button id="next-btn" class="absolute top-1/2 right-4 transform -translate-y-1/2 text-black p-4 transition-all ease-in-out duration-300 shadow-lg">
                                            <i class="fas fa-chevron-right text-xl"></i>
                                        </button>
                                    </div>
                                </div>
                                <!-- End Explore Categories Section -->



                                <div class="filter__grid-wrapper u-s-m-t-30">
                                    <div class="row">
                                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 u-s-m-b-30 filter__item footwear">
                                            <div class="product-bs">
                                                <div class="product-bs__container">
                                                    <div class="product-bs__wrap">
                                                        <a class="aspect aspect--bg-grey aspect--square u-d-block" href="product-detail.html">
                                                            <img class="aspect__img" src="images/product/men/product14.jpg" alt="">
                                                        </a>
                                                        <div class="product-bs__action-wrap">
                                                            <ul class="product-bs__action-list">
                                                                <li>
                                                                    <a data-modal="modal" data-modal-id="#quick-look"><i class="fas fa-search-plus"></i></a>
                                                                </li>
                                                                <li>
                                                                    <a data-modal="modal" data-modal-id="#add-to-cart"><i class="fas fa-plus-circle"></i></a>
                                                                </li>
                                                                <li>
                                                                    <a href="signin.html"><i class="fas fa-heart"></i></a>
                                                                </li>
                                                                <li>
                                                                    <a href="signin.html"><i class="fas fa-envelope"></i></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <span class="product-bs__category">
                                                        <a href="shop-side-version-2.html">Men Clothing</a>
                                                    </span>
                                                    <span class="product-bs__name">
                                                        <a href="product-detail.html">Men Casual Shoes Charcoal</a>
                                                    </span>
                                                    <div class="product-bs__rating gl-rating-style">
                                                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="far fa-star"></i>
                                                        <span class="product-bs__review">(23)</span>
                                                    </div>
                                                    <span class="product-bs__price">$125.00
                                                        <span class="product-bs__discount">$160.00</span>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-lg-12">
                                <div class="load-more">
                                    <button class="btn btn--e-brand" type="button">Load More</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const slider = document.getElementById('category-slider');
                        const prevBtn = document.getElementById('prev-btn');
                        const nextBtn = document.getElementById('next-btn');
                        const scrollAmount = 200; // How much to scroll on each button press

                        // Function to scroll left
                        prevBtn.addEventListener('click', function() {
                            slider.scrollBy({
                                left: -scrollAmount,
                                behavior: 'smooth'
                            });
                        });

                        // Function to scroll right
                        nextBtn.addEventListener('click', function() {
                            slider.scrollBy({
                                left: scrollAmount,
                                behavior: 'smooth'
                            });
                        });
                    });
                </script>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 4 ======-->


            <!--====== Section 5 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Intro ======-->
                <div class="section__intro u-s-m-b-46">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="section__text-wrap">
                                    <h1 class="section__heading u-c-secondary u-s-m-b-12">URBAN SOUL</h1>

                                    <span class="section__span u-c-silver">RECENTLY URBAN PRODUCTS</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Intro ======-->


                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="row">

                            <div class="col-lg-3 col-md-4 col-sm-6 u-s-m-b-30">
                                <div class="product-short u-h-100">
                                    <div class="product-short__container">
                                        <div class="product-short__img-wrap">

                                            <a class="aspect aspect--bg-grey-fb aspect--square u-d-block" href="product-detail.html">

                                                <img class="aspect__img product-short__img" src="images/product/women/product19.jpg" alt=""></a>
                                        </div>
                                        <div class="product-short__info">

                                            <span class="product-short__price">$126.77</span>

                                            <span class="product-short__name">

                                                <a href="product-detail.html">New Dress D Nice Elegant</a></span>

                                            <span class="product-short__category">

                                                <a href="shop-side-version-2.html">Women Clothing</a></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 5 ======-->


            <!--====== Section 6 ======-->
            <div class="u-s-p-b-60">

                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-sm-6 u-s-m-b-30">
                                <div class="column-product">
                                    <span class="column-product__title u-c-secondary u-s-m-b-25">SPECIAL PRODUCTS</span>
                                    <ul class="column-product__list">
                                        <li class="column-product__item">
                                            <div class="product-l">
                                                <div class="product-l__img-wrap">

                                                    <a class="aspect aspect--bg-grey aspect--square u-d-block product-l__link" href="product-detail.html">

                                                        <img class="aspect__img" src="images/product/women/product9.jpg" alt=""></a>
                                                </div>
                                                <div class="product-l__info-wrap">

                                                    <span class="product-l__category">

                                                        <a href="shop-side-version-2.html">Women Clothing</a></span>

                                                    <span class="product-l__name">

                                                        <a href="product-detail.html">New Dress A Nice Elegant</a></span>

                                                    <span class="product-l__price">$125.00</span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6 u-s-m-b-30">
                                <div class="column-product">
                                    <span class="column-product__title u-c-secondary u-s-m-b-25">WEEKLY PRODUCTS</span>
                                    <ul class="column-product__list">
                                        <li class="column-product__item">
                                            <div class="product-l">
                                                <div class="product-l__img-wrap">

                                                    <a class="aspect aspect--bg-grey aspect--square u-d-block product-l__link" href="product-detail.html">

                                                        <img class="aspect__img" src="images/product/women/product12.jpg" alt=""></a>
                                                </div>
                                                <div class="product-l__info-wrap">

                                                    <span class="product-l__category">

                                                        <a href="shop-side-version-2.html">Women Clothing</a></span>

                                                    <span class="product-l__name">

                                                        <a href="product-detail.html">New Dress D Nice Elegant</a></span>

                                                    <span class="product-l__price">$125.00

                                                        <span class="product-l__discount">$160</span></span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6 u-s-m-b-30">
                                <div class="column-product">
                                    <span class="column-product__title u-c-secondary u-s-m-b-25">FLASH PRODUCTS</span>
                                    <ul class="column-product__list">
                                        <li class="column-product__item">
                                            <div class="product-l">
                                                <div class="product-l__img-wrap">

                                                    <a class="aspect aspect--bg-grey aspect--square u-d-block product-l__link" href="product-detail.html">

                                                        <img class="aspect__img" src="images/product/women/product2.jpg" alt=""></a>
                                                </div>
                                                <div class="product-l__info-wrap">
                                                    <div class="product-l__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i></div>

                                                    <span class="product-l__category">

                                                        <a href="shop-side-version-2.html">Women Clothing</a></span>

                                                    <span class="product-l__name">

                                                        <a href="product-detail.html">Women Wedding Event Dress</a></span>

                                                    <span class="product-l__price">$125.00</span>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 6 ======-->
            <!--====== Section 7 ======-->
            <div class="u-s-p-b-60">
                <!--====== Section Content ======-->
                <div class="section__content">
                    <div class="container">

                        <!--====== Brand Slider ======-->
                        <div class="slider-fouc">
                            <div class="owl-carousel" id="brand-slider" data-item="5">
                                <div class="brand-slide">

                                    <a href="shop-side-version-2.html">

                                        <img src="images/brand/b1.png" alt=""></a>
                                </div>
                                <div class="brand-slide">

                                    <a href="shop-side-version-2.html">

                                        <img src="images/brand/b2.png" alt=""></a>
                                </div>
                                <div class="brand-slide">

                                    <a href="shop-side-version-2.html">

                                        <img src="images/brand/b3.png" alt=""></a>
                                </div>
                                <div class="brand-slide">

                                    <a href="shop-side-version-2.html">

                                        <img src="images/brand/b4.png" alt=""></a>
                                </div>
                                <div class="brand-slide">

                                    <a href="shop-side-version-2.html">

                                        <img src="images/brand/b5.png" alt=""></a>
                                </div>
                                <div class="brand-slide">

                                    <a href="shop-side-version-2.html">

                                        <img src="images/brand/b6.png" alt=""></a>
                                </div>
                            </div>
                        </div>
                        <!--====== End - Brand Slider ======-->
                    </div>
                </div>
                <!--====== End - Section Content ======-->
            </div>
            <!--====== End - Section 7 ======-->
        </div>
        <!--====== End - App Content ======-->
        <!--====== Quick Look Modal ======-->
        <div class="modal fade" id="quick-look">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content modal--shadow">

                    <button class="btn dismiss-button fas fa-times" type="button" data-dismiss="modal"></button>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-5">

                                <!--====== Product Breadcrumb ======-->
                                <div class="pd-breadcrumb u-s-m-b-30">
                                    <ul class="pd-breadcrumb__list">
                                        <li class="has-separator">

                                            <a href="index.hml">Home</a>
                                        </li>
                                        <li class="has-separator">

                                            <a href="shop-side-version-2.html">Electronics</a>
                                        </li>
                                        <li class="has-separator">

                                            <a href="shop-side-version-2.html">DSLR Cameras</a>
                                        </li>
                                        <li class="is-marked">

                                            <a href="shop-side-version-2.html">Nikon Cameras</a>
                                        </li>
                                    </ul>
                                </div>
                                <!--====== End - Product Breadcrumb ======-->


                                <!--====== Product Detail ======-->
                                <div class="pd u-s-m-b-30">
                                    <div class="pd-wrap">
                                        <div id="js-product-detail-modal">
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-1.jpg" alt="">
                                            </div>
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-2.jpg" alt="">
                                            </div>
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-3.jpg" alt="">
                                            </div>
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-4.jpg" alt="">
                                            </div>
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-5.jpg" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="u-s-m-t-15">
                                        <div id="js-product-detail-modal-thumbnail">
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-1.jpg" alt="">
                                            </div>
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-2.jpg" alt="">
                                            </div>
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-3.jpg" alt="">
                                            </div>
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-4.jpg" alt="">
                                            </div>
                                            <div>

                                                <img class="u-img-fluid" src="images/product/product-d-5.jpg" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--====== End - Product Detail ======-->
                            </div>
                            <div class="col-lg-7">

                                <!--====== Product Right Side Details ======-->
                                <div class="pd-detail">
                                    <div>

                                        <span class="pd-detail__name">Nikon Camera 4k Lens Zoom Pro</span>
                                    </div>
                                    <div>
                                        <div class="pd-detail__inline">

                                            <span class="pd-detail__price">$6.99</span>

                                            <span class="pd-detail__discount">(76% OFF)</span><del class="pd-detail__del">$28.97</del>
                                        </div>
                                    </div>
                                    <div class="u-s-m-b-15">
                                        <div class="pd-detail__rating gl-rating-style"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>

                                            <span class="pd-detail__review u-s-m-l-4">

                                                <a href="product-detail.html">23 Reviews</a></span>
                                        </div>
                                    </div>
                                    <div class="u-s-m-b-15">
                                        <div class="pd-detail__inline">

                                            <span class="pd-detail__stock">200 in stock</span>

                                            <span class="pd-detail__left">Only 2 left</span>
                                        </div>
                                    </div>
                                    <div class="u-s-m-b-15">

                                        <span class="pd-detail__preview-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
                                    </div>
                                    <div class="u-s-m-b-15">
                                        <div class="pd-detail__inline">

                                            <span class="pd-detail__click-wrap"><i class="far fa-heart u-s-m-r-6"></i>

                                                <a href="signin.html">Add to Wishlist</a>

                                                <span class="pd-detail__click-count">(222)</span></span>
                                        </div>
                                    </div>
                                    <div class="u-s-m-b-15">
                                        <div class="pd-detail__inline">

                                            <span class="pd-detail__click-wrap"><i class="far fa-envelope u-s-m-r-6"></i>

                                                <a href="signin.html">Email me When the price drops</a>

                                                <span class="pd-detail__click-count">(20)</span></span>
                                        </div>
                                    </div>
                                    <div class="u-s-m-b-15">
                                        <ul class="pd-social-list">
                                            <li>

                                                <a class="s-fb--color-hover" href="#"><i class="fab fa-facebook-f"></i></a>
                                            </li>
                                            <li>

                                                <a class="s-tw--color-hover" href="#"><i class="fab fa-twitter"></i></a>
                                            </li>
                                            <li>

                                                <a class="s-insta--color-hover" href="#"><i class="fab fa-instagram"></i></a>
                                            </li>
                                            <li>

                                                <a class="s-wa--color-hover" href="#"><i class="fab fa-whatsapp"></i></a>
                                            </li>
                                            <li>

                                                <a class="s-gplus--color-hover" href="#"><i class="fab fa-google-plus-g"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="u-s-m-b-15">
                                        <form class="pd-detail__form">
                                            <div class="pd-detail-inline-2">
                                                <div class="u-s-m-b-15">

                                                    <!--====== Input Counter ======-->
                                                    <div class="input-counter">

                                                        <span class="input-counter__minus fas fa-minus"></span>

                                                        <input class="input-counter__text input-counter--text-primary-style" type="text" value="1" data-min="1" data-max="1000">

                                                        <span class="input-counter__plus fas fa-plus"></span>
                                                    </div>
                                                    <!--====== End - Input Counter ======-->
                                                </div>
                                                <div class="u-s-m-b-15">

                                                    <button class="btn btn--e-brand-b-2" type="submit">Add to Cart</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="u-s-m-b-15">

                                        <span class="pd-detail__label u-s-m-b-8">Product Policy:</span>
                                        <ul class="pd-detail__policy-list">
                                            <li><i class="fas fa-check-circle u-s-m-r-8"></i>

                                                <span>Buyer Protection.</span>
                                            </li>
                                            <li><i class="fas fa-check-circle u-s-m-r-8"></i>

                                                <span>Full Refund if you don't receive your order.</span>
                                            </li>
                                            <li><i class="fas fa-check-circle u-s-m-r-8"></i>

                                                <span>Returns accepted if product not as described.</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!--====== End - Product Right Side Details ======-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--====== End - Quick Look Modal ======-->


        <!--====== Add to Cart Modal ======-->
        <div class="modal fade" id="add-to-cart">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content modal-radius modal-shadow">

                    <button class="btn dismiss-button fas fa-times" type="button" data-dismiss="modal"></button>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-6 col-md-12">
                                <div class="success u-s-m-b-30">
                                    <div class="success__text-wrap"><i class="fas fa-check"></i>

                                        <span>Item is added successfully!</span>
                                    </div>
                                    <div class="success__img-wrap">

                                        <img class="u-img-fluid" src="images/product/electronic/product1.jpg" alt="">
                                    </div>
                                    <div class="success__info-wrap">

                                        <span class="success__name">Beats Bomb Wireless Headphone</span>

                                        <span class="success__quantity">Quantity: 1</span>

                                        <span class="success__price">$170.00</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="s-option">

                                    <span class="s-option__text">1 item (s) in your cart</span>
                                    <div class="s-option__link-box">

                                        <a class="s-option__link btn--e-white-brand-shadow" data-dismiss="modal">CONTINUE SHOPPING</a>

                                        <a class="s-option__link btn--e-white-brand-shadow" href="cart.html">VIEW CART</a>

                                        <a class="s-option__link btn--e-brand-shadow" href="checkout.html">PROCEED TO CHECKOUT</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--====== End - Add to Cart Modal ======-->


        <!-- ====== Newsletter Subscribe Modal ======-->
        <!-- <div class="modal fade new-l" id="newsletter-modal">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content modal--shadow">

                    <button class="btn new-l__dismiss fas fa-times" type="button" data-dismiss="modal"></button>
                    <div class="modal-body">
                        <div class="row u-s-m-x-0">
                            <div class="col-lg-6 new-l__col-1 u-s-p-x-0">

                                <a class="new-l__img-wrap u-d-block" href="shop-side-version-2.html">

                                    <img class="u-img-fluid u-d-block" src="images/newsletter/newsletter.jpg" alt=""></a>
                            </div>
                            <div class="col-lg-6 new-l__col-2">
                                <div class="new-l__section u-s-m-t-30">
                                    <div class="u-s-m-b-8 new-l--center">
                                        <h3 class="new-l__h3">Newsletter</h3>
                                    </div>
                                    <div class="u-s-m-b-30 new-l--center">
                                        <p class="new-l__p1">Sign up for emails to get the scoop on new arrivals, special sales and more.</p>
                                    </div>
                                    <form class="new-l__form">
                                        <div class="u-s-m-b-15">

                                            <input class="news-l__input" type="text" placeholder="E-mail Address">
                                        </div>
                                        <div class="u-s-m-b-15">

                                            <button class="btn btn--e-brand-b-2" type="submit">Sign up!</button>
                                        </div>
                                    </form>
                                    <div class="u-s-m-b-15 new-l--center">
                                        <p class="new-l__p2">By Signing up, you agree to receive Reshop offers,<br />promotions and other commercial messages. You may unsubscribe at any time.</p>
                                    </div>
                                    <div class="u-s-m-b-15 new-l--center">

                                        <a class="new-l__link" data-dismiss="modal">No Thanks</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!--====== End - Newsletter Subscribe Modal ====== -->
        <!--====== End - Modal Section ======-->
    </div>
    <!--====== End - Main App ======-->


    <!--====== Google Analytics: change UA-XXXXX-Y to be your site's ID ======-->
    <script>
        window.ga = function() {
            ga.q.push(arguments)
        };
        ga.q = [];
        ga.l = +new Date;
        ga('create', 'UA-XXXXX-Y', 'auto');
        ga('send', 'pageview')
    </script>
    <script src="https://www.google-analytics.com/analytics.js" async defer></script>

    <!--====== Vendor Js ======-->
    <script src="js/vendor.js"></script>

    <!--====== jQuery Shopnav plugin ======-->
    <script src="js/jquery.shopnav.js"></script>

    <!--====== App ======-->
    <script src="js/app.js"></script>

    <!--====== Noscript ======-->
    <noscript>
        <div class="app-setting">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="app-setting__wrap">
                            <h1 class="app-setting__h1">JavaScript is disabled in your browser.</h1>

                            <span class="app-setting__text">Please enable JavaScript in your browser or upgrade to a JavaScript-capable browser.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </noscript>
    <!-- JavaScript Files -->
    <script src="<?php echo e(asset('./js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('./js/jquery.shopnav.js')); ?>"></script>
    <script src="<?php echo e(asset('./js/map-init.js')); ?>"></script>
    <script src="<?php echo e(asset('./js/vendor.js')); ?>"></script>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Desktop/sahil_desk/laravel-app/resources/views/user/index.blade.php ENDPATH**/ ?>