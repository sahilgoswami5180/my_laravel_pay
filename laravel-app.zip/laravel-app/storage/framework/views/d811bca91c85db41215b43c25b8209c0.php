<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-12">
    <div class="container mx-auto">
        <h1 class="text-3xl font-bold text-center mb-6">Checkout</h1>

        <?php if($cartItems->count() > 0): ?>
            <div class="mb-6">
                <h2 class="text-2xl font-semibold mb-4">Your Cart</h2>
                <table class="w-full table-auto border-collapse">
                    <thead>
                        <tr>
                            <th class="border px-4 py-2">Product</th>
                            <th class="border px-4 py-2">Price</th>
                            <th class="border px-4 py-2">Quantity</th>
                            <th class="border px-4 py-2">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border px-4 py-2"><?php echo e($item->product->name); ?></td>
                                <td class="border px-4 py-2">$<?php echo e(number_format($item->product->price, 2)); ?></td>
                                <td class="border px-4 py-2"><?php echo e($item->quantity); ?></td>
                                <td class="border px-4 py-2">$<?php echo e(number_format($item->product->price * $item->quantity, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="mb-4">
                <label for="total" class="block text-lg font-medium">Total: $<?php echo e(number_format($total, 2)); ?></label>
            </div>

            <form id="payment-form" action="<?php echo e(route('checkout.process')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div id="card-element">
                    <!-- A Stripe Element will be inserted here. -->
                </div>

                <div id="card-errors" role="alert"></div>

                <button id="submit" type="submit" class="bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 w-full mt-6">Pay with Stripe</button>
            </form>
        <?php else: ?>
            <p class="text-center">Your cart is empty.</p>
        <?php endif; ?>
    </div>
</section>

<script src="https://js.stripe.com/v3/"></script>

<script>
    var stripe = Stripe('pk_test_TYooMQauvdEDq54NiTphI7jx'); // Your Stripe test publishable key
    var elements = stripe.elements();
    var card = elements.create('card');
    card.mount('#card-element');

    var form = document.getElementById('payment-form');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const { token, error } = await stripe.createToken(card);

        if (error) {
            // Display error in #card-errors div
            document.getElementById('card-errors').textContent = error.message;
        } else {
            // Add token to form and submit
            var hiddenInput = document.createElement('input');
            hiddenInput.setAttribute('type', 'hidden');
            hiddenInput.setAttribute('name', 'stripeToken');
            hiddenInput.setAttribute('value', token.id);
            form.appendChild(hiddenInput);

            form.submit();
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/checkout/index.blade.php ENDPATH**/ ?>