<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Wishlist</h2>

            <?php if(empty($products)): ?>
                <p class="text-center text-gray-600">Your wishlist is empty.</p>
            <?php else: ?>
                <ul class="space-y-4">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex justify-between items-center">
                            <span class="text-gray-700"><?php echo e($product['name']); ?></span>
                            <span class="text-gray-500"><?php echo e($product['price']); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/user/wishlist.blade.php ENDPATH**/ ?>