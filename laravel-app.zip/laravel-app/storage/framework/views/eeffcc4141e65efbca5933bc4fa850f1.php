<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Email</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="bg-white shadow-md rounded-lg p-6 w-full max-w-md">
        <h2 class="text-2xl font-bold text-center mb-4">Verify Your Email</h2>

        <?php if(session('error')): ?>
            <div class="bg-red-100 text-red-700 p-4 mb-4 rounded">
                <?php echo e(session('error')); ?>

            </div>
        <?php elseif(session('status')): ?>
            <div class="bg-green-100 text-green-700 p-4 mb-4 rounded">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <p class="text-gray-700 text-center mb-4">
            Please check your email for a verification link. If you didn’t receive one, you can resend it below.
        </p>

        <form action="<?php echo e(route('verification.resend')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button
                type="submit"
                class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition">
                Resend Verification Email
            </button>
        </form>
    </div>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/auth/verify-email.blade.php ENDPATH**/ ?>