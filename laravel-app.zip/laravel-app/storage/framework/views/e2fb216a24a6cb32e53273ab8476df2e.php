<?php $__env->startSection('title', 'Create Product Combo'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-10">

    <!-- Breadcrumb Navigation -->
    <nav class="flex text-sm text-gray-600 mb-6 items-center">
        <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center <?php echo e(Request::is('dashboard') ? 'text-blue-500' : ''); ?>">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <a href="<?php echo e(route('product_combos.index')); ?>" class="flex items-center <?php echo e(Request::is('product_combos') || Request::is('product_combos/*') ? 'text-blue-500' : ''); ?>">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Product Combos</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <span class="text-xs text-gray-500">Create</span>
    </nav>

    <!-- Full-Screen Width Card Container for the Form -->
    <div class="w-full bg-white p-8 rounded-lg shadow-2xl">
        <!-- Flex container to align Button and Page Title -->
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-4xl font-semibold text-gray-800 flex items-center">
                <i class="fas fa-plus-circle text-blue-500 mr-3"></i>
                Create Product Combo
            </h2>
        </div>

        <!-- Form to Create Product Combo -->
        <form action="<?php echo e(route('product_combos.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-8">
            <?php echo csrf_field(); ?>

            <!-- Combo Name and Description -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <!-- Combo Name -->
                <div class="space-y-2">
                    <label for="name" class="text-lg font-medium text-gray-700">Combo Name <span class="text-red-500">*</span></label>
                    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Combo Description -->
                <div class="space-y-2">
                    <label for="description" class="text-lg font-medium text-gray-700">Description <span class="text-red-500">*</span></label>
                    <textarea name="description" id="description" rows="4" maxlength="255" oninput="updateCharCount()" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg"><?php echo e(old('description')); ?></textarea>
                    <div class="flex justify-end text-sm text-gray-500">
                        <span id="charCount">0</span> / 255
                    </div>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Category and Subcategory -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <!-- Category -->
                <div class="space-y-2">
                    <label for="category_id" class="text-lg font-medium text-gray-700">Category <span class="text-red-500">*</span></label>
                    <select name="category_id" id="category_id" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" required>
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Subcategory -->
                <div class="space-y-2">
                    <label for="subcategory_id" class="text-lg font-medium text-gray-700">Subcategory <span class="text-red-500">*</span></label>
                    <select name="subcategory_id" id="subcategory_id" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" required>
                        <option value="">Select Subcategory</option>
                    </select>
                    <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Product Selection with Checkboxes -->
            <div class="space-y-4 mb-8">
                <label class="text-lg font-semibold text-gray-800">Select Products (2-6) <span class="text-red-500">*</span></label>
                <div id="products" class="space-y-4 max-h-64 overflow-y-auto p-4 border border-gray-300 rounded-lg shadow-sm bg-white hover:shadow-lg transition-all ease-in-out duration-300">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center space-x-4 hover:bg-gray-50 rounded-md px-2 py-2 transition-colors">
                        <!-- Custom Styled Checkbox -->
                        <input type="checkbox" name="products[]" value="<?php echo e($product->id); ?>" data-price="<?php echo e($product->price); ?>" class="product-checkbox h-5 w-5 border border-gray-300 rounded-sm checked:bg-blue-500 checked:border-blue-500 focus:ring-2 focus:ring-blue-500" <?php echo e(in_array($product->id, old('products', [])) ? 'checked' : ''); ?>>

                        <!-- Product Label with Price -->
                        <label class="text-gray-700 font-medium text-sm"><?php echo e($product->name); ?> - <span class="text-blue-600">$<?php echo e(number_format($product->price, 2)); ?></span></label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Selected Products Count -->
                <div class="mt-2">
                    <p class="text-sm font-medium text-gray-600">Selected Products: <span id="selected-count" class="text-blue-600">0</span></p>
                </div>

                <!-- Error Message for Exceeding Limit -->
                <div id="error-message" class="text-sm text-red-500 mt-2" style="display: none;">
                    You can only select between 2 and 6 products.
                </div>

                <?php $__errorArgs = ['products'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const checkboxes = document.querySelectorAll('.product-checkbox');
                    const selectedCountElement = document.getElementById('selected-count');
                    const errorMessage = document.getElementById('error-message');
                    const productsForm = document.querySelector('form');

                    // Function to update the count of selected products
                    function updateSelectedCount() {
                        const selectedCheckboxes = document.querySelectorAll('.product-checkbox:checked');
                        const selectedCount = selectedCheckboxes.length;

                        // Update the displayed count
                        selectedCountElement.textContent = selectedCount;

                        // Show error message if more than 6 products are selected
                        if (selectedCount > 6) {
                            errorMessage.style.display = 'block';
                            productsForm.querySelector('button[type="submit"]').disabled = true; // Disable submit button
                        } else {
                            errorMessage.style.display = 'none';
                            productsForm.querySelector('button[type="submit"]').disabled = false; // Enable submit button
                        }
                    }

                    // Add event listeners to checkboxes
                    checkboxes.forEach(checkbox => {
                        checkbox.addEventListener('change', updateSelectedCount);
                    });

                    // Initialize the count on page load
                    updateSelectedCount();
                });
            </script>
            <!-- Total Price and Discount Price -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <!-- Total Price -->
                <div class="space-y-2">
                    <label for="total_price" class="text-lg font-medium text-gray-700">Total Price <span class="text-red-500">*</span></label>
                    <input type="number" name="total_price" id="total_price" value="<?php echo e(old('total_price')); ?>" step="0.01" min="0" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" readonly required>
                    <?php $__errorArgs = ['total_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Discount Price -->
                <div class="space-y-2">
                    <label for="disc_price" class="text-lg font-medium text-gray-700">Discount Price <span class="text-red-500">*</span></label>
                    <input type="number" name="disc_price" id="disc_price" value="<?php echo e(old('disc_price')); ?>" step="0.01" min="0" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" required>
                    <?php $__errorArgs = ['disc_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end space-x-6 mt-8">
                <a href="<?php echo e(route('product_combos.index')); ?>" class="bg-gray-300 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-400 transition duration-300 flex items-center">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </a>
                <button type="submit" class="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition duration-300 flex items-center">
                    <i class="fas fa-check-circle mr-2"></i> Create Combo
                </button>
            </div>
        </form>
    </div>

</div>

<script>
    // Update total price dynamically when products are selected or deselected
    document.querySelectorAll('.product-checkbox').forEach(function(checkbox) {
        checkbox.addEventListener('change', function() {
            let totalPrice = 0;

            // Loop through all checked checkboxes and add the prices
            document.querySelectorAll('.product-checkbox:checked').forEach(function(checkedCheckbox) {
                totalPrice += parseFloat(checkedCheckbox.getAttribute('data-price')) || 0;
            });

            // Update the total price field
            document.getElementById('total_price').value = totalPrice.toFixed(2);
        });
    });

    // Character Counter for Description
    function updateCharCount() {
        const description = document.getElementById('description');
        const charCount = document.getElementById('charCount');
        charCount.textContent = description.value.length;
    }
</script>

<script>
    // When the category changes, make an AJAX call to get the subcategories
    document.getElementById('category_id').addEventListener('change', function() {
        const categoryId = this.value;
        const subcategoryDropdown = document.getElementById('subcategory_id');

        // Clear previous subcategory options
        subcategoryDropdown.innerHTML = '<option value="">Select Subcategory</option>';

        if (categoryId) {
            // Make an AJAX request to fetch subcategories based on the selected category
            fetch(`/get-subcategories/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    // Check if subcategories are available
                    if (data.length > 0) {
                        data.forEach(subcategory => {
                            const option = document.createElement('option');
                            option.value = subcategory.id;
                            option.textContent = subcategory.name;
                            subcategoryDropdown.appendChild(option);
                        });
                    } else {
                        // If no subcategories are available
                        const option = document.createElement('option');
                        option.value = '';
                        option.textContent = 'No subcategories available';
                        subcategoryDropdown.appendChild(option);
                    }
                })
                .catch(error => {
                    console.error('Error fetching subcategories:', error);
                });
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Documents/laravel-auth-app/resources/views/product_combos/create.blade.php ENDPATH**/ ?>