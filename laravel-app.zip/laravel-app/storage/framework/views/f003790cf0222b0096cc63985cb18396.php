<?php $__env->startSection('content'); ?>
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Orders</h2>

            <?php if($orders->isEmpty()): ?>
                <p class="text-center text-gray-600">You have no orders yet.</p>
            <?php else: ?>
                <ul class="space-y-4">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex justify-between items-center">
                            <span class="text-gray-700">Order #<?php echo e($order->id); ?></span>
                            <span class="text-gray-500"><?php echo e($order->created_at->format('F j, Y')); ?></span>
                            <!-- Optional: List Order Items -->
                            <div class="text-gray-600">
                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div><?php echo e($item->quantity); ?> x <?php echo e($item->product->name); ?> - $<?php echo e($item->price); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/user/orders.blade.php ENDPATH**/ ?>