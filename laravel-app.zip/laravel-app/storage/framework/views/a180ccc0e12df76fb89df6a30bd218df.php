<?php $__env->startSection('content'); ?>
    <div class="container mx-auto mt-0">
        <!-- Breadcrumb Navigation -->
        <nav class="flex text-md text-gray-600 mb-2 items-center justify-between">
            <div class="flex items-center">
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="hover:text-blue-500 flex items-center <?php echo e(Request::is('dashboard') ? 'text-blue-500' : ''); ?>">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <a href="<?php echo e(route('categories.index')); ?>"
                    class="hover:text-blue-500 flex items-center <?php echo e(Request::is('categories') || Request::is('categories/*') ? 'text-blue-500' : ''); ?>">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Categories</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <span class="text-xs px-2 py-1 bg-gray-200 rounded-full text-blue-500">Products</span>
            </div>

            <!-- Back to Categories Button -->
            <div class="flex items-center">
                <a href="<?php echo e(route('categories.index')); ?>"
                    class="bg-blue-500 text-white px-4 py-2 rounded-full shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300">
                    Back to Categories
                </a>
            </div>
        </nav>

        <!-- Heading with Centered and Uppercase Category Name -->
        <h1 class="text-2xl font-semibold text-gray-800 mb-6 text-center uppercase">
            Products for Category: <?php echo e($category->name); ?>

        </h1>

        <!-- Card View -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php if($products->count()): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="block">
                        <div class="bg-white rounded-lg shadow-md overflow-hidden">
                            <img src="<?php echo e($product->image ? asset('storage/' . $product->image) : asset('images/placeholder.png')); ?>"
                                alt="<?php echo e($product->name); ?>"
                                class="w-full h-48 object-cover">
                            <div class="p-4">
                                <h3 class="text-lg font-semibold text-gray-800"><?php echo e($product->name); ?></h3>
                                <!-- Description with Truncation -->
                                <p class="text-sm text-gray-600 mt-2 line-clamp-2">
                                    <strong>Description:</strong> <?php echo e($product->description); ?>

                                </p>
                                <p class="text-sm text-gray-600 mt-2"><strong>Price:</strong> $<?php echo e(number_format($product->price, 2)); ?></p>
                                <p class="text-sm text-gray-600 mt-2"><strong>Category:</strong> <?php echo e($category->name); ?></p>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-span-full text-center text-gray-500 py-6">
                    <p>No products found for this category. <a href="<?php echo e(route('products.create')); ?>"
                            class="text-blue-500 underline">Create one</a> now!</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <div class="mt-6">
            <?php echo e($products->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/laravel-auth-app/resources/views/categories/products.blade.php ENDPATH**/ ?>