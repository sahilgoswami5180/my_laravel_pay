<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Include intl-tel-input CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">

    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="flex w-full min-h-screen">

        <!-- Left side: Image Section -->
        <div class="hidden lg:block w-1/2 h-full bg-cover bg-center flex items-center justify-center">
            <!-- Image will cover the left side -->
            <img src="https://img.freepik.com/premium-vector/vector-illustration-online-registration-concept-with-business-team-filling-registration_675567-3091.jpg" alt="" style="height:605px;width:700px;" class="h-full w-full object-cover">
        </div>

        <!-- Right side: Register Form Section -->
        <div class="w-full lg:w-1/2 bg-gradient-to-r from-blue-100 via-blue-200 to-blue-300 shadow-lg rounded-lg p-8 space-y-6 overflow-y-auto">
            <h2 class="text-3xl font-bold text-center text-blue-500 mb-6">Register</h2>

            <form action="<?php echo e(route('register')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Grid Layout for Fields -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

                    <!-- Name Field -->
                    <div class="relative">
                        <label for="name" class="block text-gray-700 font-medium mb-1">Name <span class="text-red-500">*</span></label>
                        <input type="text" name="name" id="name" class="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2  transition-all" placeholder="Name" value="<?php echo e(old('name')); ?>">
                        <span class="absolute right-3 top-1/2 text-gray-500">
                            <i class="fas fa-user"></i>
                        </span>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Email Field -->
                    <div class="relative">
                        <label for="email" class="block text-gray-700 font-medium mb-1">Email <span class="text-red-500">*</span></label>
                        <input type="email" name="email" id="email" class="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 transition-all"
                            placeholder="Email" value="<?php echo e(old('email')); ?>" required oninput="validateEmail()" />
                        <span class="absolute right-3 top-1/2 text-gray-500">
                            <i class="fas fa-envelope"></i>
                        </span>

                        <!-- Error message for email validation -->
                        <p id="email-error" class="text-red-600 mt-1 hidden">Please enter a valid email address.</p>
                    </div>

                    <script>
                        // Email validation function
                        function validateEmail() {
                            var emailField = document.getElementById("email");
                            var errorMessage = document.getElementById("email-error");
                            var email = emailField.value;

                            // Simple regex for email validation
                            var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                            // Check if email matches the regex
                            if (regex.test(email)) {
                                errorMessage.classList.add("hidden"); // Hide error message if valid
                                emailField.classList.remove("border-red-600"); // Remove red border if valid
                            } else {
                                errorMessage.classList.remove("hidden"); // Show error message if invalid
                                emailField.classList.add("border-red-600"); // Add red border to the email input field
                            }
                        }
                    </script>

                    <!-- Mobile Number Field -->
                    <div class="relative">
                        <label for="mobile" class="block text-gray-700 font-medium mb-2">Mobile Number <span class="text-red-600">*</span></label>
                        <input type="tel" name="mobile" id="mobile" maxlength="15"
                            class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Mobile Number" value="<?php echo e(old('mobile')); ?>"
                            inputmode="numeric" pattern="\d+" oninput="this.value = this.value.replace(/\D/g, '')">
                        <span class="absolute right-3 text-gray-500" style="top: 40px;">
                            <i class="fas fa-phone-alt"></i>
                        </span>
                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Password Field -->
                    <div class="relative">
                        <label for="password" class="block text-gray-700 font-medium mb-1">Password <span class="text-red-500">*</span></label>
                        <input type="password" name="password" id="password" class="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 transition-all"
                            placeholder="****************" required
                            pattern="^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,13}$" maxlength="13"
                            title="Password must be at least 8 characters, at most 13 characters, and contain at least one uppercase letter, one number, and one special character." oninput="validatePassword()" />
                        <span id="toggle-password" class="absolute right-3 top-1/2 cursor-pointer text-gray-500" onclick="togglePassword()">
                            <i id="password-icon" class="fas fa-eye"></i>
                        </span>

                        <!-- Error message for validation -->
                        <p id="password-error" class="text-red-600 mt-1 hidden">Password must be between 8 and 13 characters long, contain at least one uppercase letter, one number, and one special character.</p>
                    </div>

                    <script>
                        // Toggle password visibility
                        function togglePassword() {
                            var passwordField = document.getElementById("password");
                            var passwordIcon = document.getElementById("password-icon");

                            if (passwordField.type === "password") {
                                passwordField.type = "text";
                                passwordIcon.classList.remove("fa-eye");
                                passwordIcon.classList.add("fa-eye-slash");
                            } else {
                                passwordField.type = "password";
                                passwordIcon.classList.remove("fa-eye-slash");
                                passwordIcon.classList.add("fa-eye");
                            }
                        }

                        // Password validation function
                        function validatePassword() {
                            var passwordField = document.getElementById("password");
                            var errorMessage = document.getElementById("password-error");
                            var password = passwordField.value;

                            // Regular expression to match password criteria
                            var regex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,13}$/;

                            // Check if the password meets the pattern
                            if (regex.test(password)) {
                                errorMessage.classList.add("hidden"); // Hide error message if valid
                                passwordField.classList.remove("border-red-600"); // Remove red border if valid
                            } else {
                                errorMessage.classList.remove("hidden"); // Show error message if invalid
                                passwordField.classList.add("border-red-600"); // Add red border to the input field
                            }
                        }
                    </script>


                    <!-- Confirm Password Field -->
                    <div class="relative">
                        <label for="password_confirmation" class="block text-gray-700 font-medium mb-1">Confirm Password <span class="text-red-500">*</span></label>
                        <input type="password" name="password_confirmation" id="password_confirmation" class="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2  transition-all" placeholder="****************">
                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <!-- Register Button -->
                <button type="submit" class="w-full bg-gradient-to-r from-blue-400 to-blue-500 text-white py-3 rounded-xl hover:from-blue-500 hover:to-blue-600 transition duration-300">Register</button>
            </form>

            <!-- Login Redirect -->
            <div class="mt-4 text-center">
                <span class="text-gray-600">Already have an account?</span>
                <a href="<?php echo e(route('home')); ?>" class="text-blue-500 hover:underline ml-1">Login</a>
            </div>
        </div>

        <script>
            // Toggle password visibility
            function togglePassword() {
                const passwordField = document.getElementById('password');
                const passwordIcon = document.getElementById('password-icon');

                if (passwordField.type === 'password') {
                    passwordField.type = 'text';
                    passwordIcon.classList.remove('fa-eye');
                    passwordIcon.classList.add('fa-eye-slash');
                } else {
                    passwordField.type = 'password';
                    passwordIcon.classList.remove('fa-eye-slash');
                    passwordIcon.classList.add('fa-eye');
                }
            }
        </script>

    </div>

    <script>
        // Toggle password visibility
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const passwordIcon = document.getElementById('password-icon');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.classList.remove('fa-eye');
                passwordIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordIcon.classList.remove('fa-eye-slash');
                passwordIcon.classList.add('fa-eye');
            }
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"></script>
    <script>
        // Initialize intl-tel-input on mobile number field
        var input = document.querySelector("#mobile");
        var iti = window.intlTelInput(input, {
            initialCountry: "in", // Set default country to India
            geoIpLookup: function(callback) {
                fetch('https://ipinfo.io', {
                        method: 'GET'
                    })
                    .then(response => response.json())
                    .then(data => callback(data.country))
                    .catch(() => callback('us'));
            },
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
        });

        // Function to reorder countries after the plugin is initialized
        iti.promise.then(function() {
            var countryList = document.querySelectorAll('.iti__country');

            var indiaOption = Array.from(countryList).find(option => option.getAttribute('data-country-code') ===
                'in');

            if (indiaOption) {
                indiaOption.parentNode.insertBefore(indiaOption, indiaOption.parentNode.firstChild);
            }

            var firstThree = ['in']; // Example: India, US, and Canada
            countryList.forEach(function(option) {
                if (firstThree.includes(option.getAttribute('data-country-code'))) {
                    option.parentNode.insertBefore(option, option.parentNode.firstChild);
                }
            });
        });

        document.querySelector("form").addEventListener("submit", function() {
            var fullPhoneNumber = iti.getNumber();
            input.value = fullPhoneNumber;
        });

        // Toggle password visibility
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const passwordIcon = document.getElementById('password-icon');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.classList.remove('fa-eye');
                passwordIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordIcon.classList.remove('fa-eye-slash');
                passwordIcon.classList.add('fa-eye');
            }
        }

        // Enable or disable submit button based on form completion
        const form = document.getElementById('registerForm');
        const submitBtn = document.getElementById('submitBtn');

        form.addEventListener('input', function() {
            let allFilled = true;

            // Check each input element
            form.querySelectorAll('input').forEach(input => {
                if (!input.value.trim()) {
                    allFilled = false;
                }
            });

            submitBtn.disabled = !allFilled;
        });
    </script>
</body>

</html><?php /**PATH /home/xceltec-28/Desktop/sahil_desk/laravel-app/resources/views/auth/register.blade.php ENDPATH**/ ?>