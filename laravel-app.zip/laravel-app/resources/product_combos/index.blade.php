@extends('layouts.app')

@section('content')
<h1>Product Combos</h1>

<a href="{{ route('product_combos.create') }}" class="btn btn-primary">Create New Combo</a>

<table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Total Price</th>
            <th>Discount Price</th>
            <th>Category</th>
            <th>Subcategory</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($productCombos as $combo)
        <tr>
            <td>{{ $combo->name }}</td>
            <td>{{ $combo->description }}</td>
            <td>{{ $combo->total_price }}</td>
            <td>{{ $combo->disc_price }}</td>
            <td>{{ $combo->category->name }}</td>
            <td>{{ $combo->subcategory->name }}</td>
            <td>
                <a href="{{ route('product_combos.edit', $combo->id) }}" class="btn btn-warning">Edit</a>
                <form action="{{ route('product_combos.destroy', $combo->id) }}" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection