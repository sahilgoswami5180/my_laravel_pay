@extends('layouts.app')

@section('content')
<h1>Edit Product Combo</h1>

<form action="{{ route('product_combos.update', $productCombo->id) }}" method="POST">
    @csrf
    @method('PUT')

    <div class="form-group">
        <label for="name">Combo Name</label>
        <input type="text" name="name" class="form-control" id="name" value="{{ $productCombo->name }}" required>
    </div>

    <div class="form-group">
        <label for="description">Description</label>
        <textarea name="description" class="form-control" id="description" required>{{ $productCombo->description }}</textarea>
    </div>

    <div class="form-group">
        <label for="total_price">Total Price</label>
        <input type="number" name="total_price" class="form-control" id="total_price" value="{{ $productCombo->total_price }}" step="0.01" required>
    </div>

    <div class="form-group">
        <label for="disc_price">Discounted Price</label>
        <input type="number" name="disc_price" class="form-control" id="disc_price" value="{{ $productCombo->disc_price }}" step="0.01" required>
    </div>

    <div class="form-group">
        <label for="image">Image URL</label>
        <input type="text" name="image" class="form-control" id="image" value="{{ $productCombo->image }}" required>
    </div>

    <div class="form-group">
        <label for="category_id">Category</label>
        <select name="category_id" class="form-control" id="category_id" required>
            @foreach($categories as $category)
            <option value="{{ $category->id }}" {{ $category->id == $productCombo->category_id ? 'selected' : '' }}>
                {{ $category->name }}
            </option>
            @endforeach
        </select>
    </div>

    <div class="form-group">
        <label for="subcategory_id">Subcategory</label>
        <select name="subcategory_id" class="form-control" id="subcategory_id" required>
            @foreach($subcategories as $subcategory)
            <option value="{{ $subcategory->id }}" {{ $subcategory->id == $productCombo->subcategory_id ? 'selected' : '' }}>
                {{ $subcategory->name }}
            </option>
            @endforeach
        </select>
    </div>

    <div class="form-group">
        <label for="products">Select Products (2-6)</label>
        <select name="products[]" class="form-control" id="products" multiple required>
            @foreach($products as $product)
            <option value="{{ $product->id }}"
                {{ in_array($product->id, $productCombo->products->pluck('id')->toArray()) ? 'selected' : '' }}>
                {{ $product->name }}
            </option>
            @endforeach
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Update Combo</button>
</form>
@endsection