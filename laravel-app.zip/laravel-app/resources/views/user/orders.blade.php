@extends('layouts.user')

@section('content')
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Orders</h2>

            @if ($orders->isEmpty())
                <p class="text-center text-gray-600">You have no orders yet.</p>
            @else
                <ul class="space-y-4">
                    @foreach ($orders as $order)
                        <li class="flex justify-between items-center">
                            <span class="text-gray-700">Order #{{ $order->id }}</span>
                            <span class="text-gray-500">{{ $order->created_at->format('F j, Y') }}</span>
                            <!-- Optional: List Order Items -->
                            <div class="text-gray-600">
                                @foreach ($order->orderItems as $item)
                                    <div>{{ $item->quantity }} x {{ $item->product->name }} - ${{ $item->price }}</div>
                                @endforeach
                            </div>
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
@endsection
