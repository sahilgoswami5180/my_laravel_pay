@extends('layouts.app')

@section('title', 'Create Product Combo')

@section('content')
<div class="container mx-auto mt-10">

    <!-- Breadcrumb Navigation -->
    <nav class="flex text-sm text-gray-600 mb-6 items-center">
        <a href="{{ route('dashboard') }}" class="flex items-center {{ Request::is('dashboard') ? 'text-blue-500' : '' }}">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <a href="{{ route('product_combos.index') }}" class="flex items-center {{ Request::is('product_combos') || Request::is('product_combos/*') ? 'text-blue-500' : '' }}">
            <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Product Combos</span>
        </a>
        <span class="mx-2 text-xs">/</span>
        <span class="text-xs text-gray-500">Create</span>
    </nav>

    <!-- Full-Screen Width Card Container for the Form -->
    <div class="w-full bg-white p-8 rounded-lg shadow-2xl">
        <!-- Flex container to align Button and Page Title -->
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-4xl font-semibold text-gray-800 flex items-center">
                <i class="fas fa-plus-circle text-blue-500 mr-3"></i>
                Create Product Combo
            </h2>
        </div>

        <!-- Form to Create Product Combo -->
        <form action="{{ route('product_combos.store') }}" method="POST" enctype="multipart/form-data" class="space-y-8">
            @csrf

            <!-- Combo Name and Description -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <!-- Combo Name -->
                <div class="space-y-2">
                    <label for="name" class="text-lg font-medium text-gray-700">Combo Name <span class="text-red-500">*</span></label>
                    <input type="text" name="name" id="name" value="{{ old('name') }}" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" required>
                    @error('name')
                    <p class="text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Combo Description -->
                <div class="space-y-2">
                    <label for="description" class="text-lg font-medium text-gray-700">Description <span class="text-red-500">*</span></label>
                    <textarea name="description" id="description" rows="4" maxlength="255" oninput="updateCharCount()" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg">{{ old('description') }}</textarea>
                    <div class="flex justify-end text-sm text-gray-500">
                        <span id="charCount">0</span> / 255
                    </div>
                    @error('description')
                    <p class="text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
            </div>
            <!-- Category and Subcategory -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <!-- Category -->
                <div class="space-y-2">
                    <label for="category_id" class="text-lg font-medium text-gray-700">Category <span class="text-red-500">*</span></label>
                    <select name="category_id" id="category_id" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" required>
                        <option value="">Select Category</option>
                        @foreach ($categories as $category)
                        <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                        @endforeach
                    </select>
                    @error('category_id')
                    <p class="text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Subcategory -->
                <div class="space-y-2">
                    <label for="subcategory_id" class="text-lg font-medium text-gray-700">Subcategory <span class="text-red-500">*</span></label>
                    <select name="subcategory_id" id="subcategory_id" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" required>
                        <option value="">Select Subcategory</option>
                    </select>
                    @error('subcategory_id')
                    <p class="text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
            </div>
            <!-- Product Selection -->
            <div class="mb-4">
                <label for="products" class="block text-sm font-medium text-gray-700">Products</label>
                <select name="products[]" id="products"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    multiple>
                    <option value="" selected disabled>Select products...</option>
                    @foreach ($products as $product)
                    <option value="{{ $product->id }}" data-price="{{ $product->price }}">{{ $product->name }}
                    </option>
                    @endforeach
                </select>
                @error('products')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>


            <!-- Display Selected Products -->
            <div class="mb-4" id="selected-products">
                <label name="products[]" id="products" for="selected-products" class="block text-sm font-medium text-gray-700">Selected Products</label>
                <div class="overflow-y-auto h-24 border border-gray-300 rounded-md p-2 flex justify-center items-center"
                    id="selected-product-container">
                    <!-- Product will appear here -->
                </div>
            </div>

            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const productsSelect = document.getElementById('products');
                    const selectedProductContainer = document.getElementById('selected-product-container');
                    const totalPriceDisplay = document.getElementById('total_price');
                    const selectedProducts = [];

                    // Function to update selected products and total price
                    function updateSelectedProducts() {
                        selectedProductContainer.innerHTML = '';
                        let totalPrice = 0;

                        selectedProducts.forEach(product => {
                            // Create product display
                            const productDiv = document.createElement('div');
                            productDiv.classList.add('bg-gray-100', 'border-2', 'border-gray-400', 'rounded-md',
                                'p-2', 'flex', 'items-center', 'transition', 'hover:bg-gray-200');

                            const productText = document.createElement('span');
                            productText.classList.add('mr-2', 'text-gray-800', 'font-semibold');
                            productText.textContent = product.name;

                            const cancelButton = document.createElement('button');
                            cancelButton.textContent = '✖';
                            cancelButton.classList.add('text-red-500', 'ml-2', 'cursor-pointer');
                            cancelButton.onclick = function() {
                                // Remove product from selected list
                                const index = selectedProducts.findIndex(p => p.id === product.id);
                                if (index !== -1) {
                                    selectedProducts.splice(index, 1);
                                    updateSelectedProducts();
                                }
                                // Re-add the product to the dropdown
                                addProductBackToDropdown(product);
                            };

                            productDiv.appendChild(productText);
                            productDiv.appendChild(cancelButton);
                            selectedProductContainer.appendChild(productDiv);

                            // Add the product price to the total
                            totalPrice += product.price;
                        });

                        // Update the total price field
                        totalPriceDisplay.value = totalPrice.toFixed(2);
                    }

                    // Function to add product back to the dropdown
                    function addProductBackToDropdown(product) {
                        const option = document.createElement('option');
                        option.value = product.id;
                        option.textContent = product.name;
                        option.setAttribute('data-price', product.price);
                        productsSelect.appendChild(option);
                    }

                    productsSelect.addEventListener('change', function() {
                        const selectedOptions = Array.from(productsSelect.selectedOptions);
                        selectedOptions.forEach(option => {
                            const product = {
                                id: option.value,
                                name: option.text,
                                price: parseFloat(option.getAttribute('data-price'))
                            };

                            // Add selected product to the array and update the UI
                            selectedProducts.push(product);
                            updateSelectedProducts();

                            // Remove selected product from the dropdown
                            option.remove();
                        });
                    });
                });
            </script>
            <!-- Total Price and Discount Price -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <!-- Total Price -->
                <div class="space-y-2">
                    <label for="total_price" class="text-lg font-medium text-gray-700">Total Price <span class="text-red-500">*</span></label>
                    <input type="number" name="total_price" id="total_price" value="{{ old('total_price') }}" step="0.01" min="0" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" readonly required>
                    @error('total_price')
                    <p class="text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Discount Price -->
                <div class="space-y-2">
                    <label for="disc_price" class="text-lg font-medium text-gray-700">Discount Price <span class="text-red-500">*</span></label>
                    <input type="number" name="disc_price" id="disc_price" value="{{ old('disc_price') }}" step="0.01" min="0" class="w-full px-6 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg" required>
                    @error('disc_price')
                    <p class="text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end space-x-6 mt-8">
                <a href="{{ route('product_combos.index') }}" class="bg-gray-300 text-gray-800 px-6 py-3 rounded-lg hover:bg-gray-400 transition duration-300 flex items-center">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </a>
                <button type="submit" class="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition duration-300 flex items-center">
                    <i class="fas fa-check-circle mr-2"></i> Create Combo
                </button>
            </div>
        </form>
    </div>

</div>
<script>
    // Character Counter for Description
    function updateCharCount() {
        const description = document.getElementById('description');
        const charCount = document.getElementById('charCount');
        charCount.textContent = description.value.length;
    }

    // Update total price dynamically when products are selected
    document.getElementById('products').addEventListener('change', function() {
        let totalPrice = 0;

        // Loop through the selected options and add the prices
        const selectedOptions = this.selectedOptions;
        for (let i = 0; i < selectedOptions.length; i++) {
            totalPrice += parseFloat(selectedOptions[i].getAttribute('data-price')) || 0;
        }

        // Update the total price field
        document.getElementById('total_price').value = totalPrice.toFixed(2);
    });
</script>

<script>
    document.getElementById('category_id').addEventListener('change', function() {
        const categoryId = this.value;
        const subcategoryDropdown = document.getElementById('subcategory_id');

        // Clear previous subcategory options
        subcategoryDropdown.innerHTML = '<option value="">Select Subcategory</option>';

        if (categoryId) {
            // Make an AJAX request to fetch subcategories based on the selected category
            fetch(`/get-subcategories/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    // Check if subcategories are available
                    if (data.length > 0) {
                        data.forEach(subcategory => {
                            const option = document.createElement('option');
                            option.value = subcategory.id;
                            option.textContent = subcategory.name;
                            subcategoryDropdown.appendChild(option);
                        });
                    } else {
                        // If no subcategories are available
                        const option = document.createElement('option');
                        option.value = '';
                        option.textContent = 'No subcategories available';
                        subcategoryDropdown.appendChild(option);
                    }
                })
                .catch(error => {
                    console.error('Error fetching subcategories:', error);
                });
        }
    });
</script>

<script>

</script>
@endsection