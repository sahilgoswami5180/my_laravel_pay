@extends('layouts.user')

@section('title', 'Product Details')

@section('content')
<!-- Back Icon -->
<section class="py-4 bg-gray-100">
    <div class="container mx-auto">
        <a href="{{ url()->previous() }}" class="flex items-center text-blue-500 hover:text-blue-600 font-medium">
            <i class="fas fa-arrow-left mr-2"></i> Back
        </a>
    </div>
</section>

<!-- Product Details Section -->
<section class="py-20 bg-gray-100">
    <div class="container mx-auto">
        <div class="flex flex-col lg:flex-row gap-12">
            <!-- Product Image -->
            <div class="bg-white shadow-lg rounded-lg p-6 flex justify-center items-center">
                <div class="image-carousel-container relative">
                    @php
                    $images = explode(',', $product->images); // Convert the comma-separated string into an array
                    @endphp

                    @if (is_array($images) && count($images) > 0)
                    <!-- Big Image -->
                    <div id="big-image-container" class="mb-4">
                        <img id="big-image" src="{{ asset('storage/' . $images[0]) }}" alt="{{ $product->name }}"
                            class="zoom-image w-56 h-56 mx-auto object-cover rounded-md cursor-pointer" />
                    </div>

                    <!-- Thumbnail Images -->
                    <div id="thumbnails" class="flex space-x-4 overflow-x-auto overflow-y-hidden">
                        @foreach ($images as $index => $image)
                        <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}"
                            class="thumbnail w-16 h-16 object-cover cursor-pointer rounded-md"
                            data-image="{{ asset('storage/' . $image) }}" />
                        @endforeach
                    </div>
                    @else
                    <img src="{{ asset('images/placeholder.png') }}" alt="{{ $product->name }}"
                        class="zoom-image w-full h-auto object-cover rounded-md cursor-pointer" />
                    @endif
                </div>
            </div>

            <!-- Product Info -->
            <div class="lg:w-1/2">
                <h2 class="text-3xl font-bold text-gray-800">{{ $product->name }}</h2>
                <p class="text-sm text-gray-500 mt-2">Category: {{ $product->category->name }}</p>
                <p class="text-lg text-gray-600 mt-4">{{ $product->description }}</p>

                <p class="text-2xl font-bold text-gray-800 mt-6">${{ number_format($product->price, 2) }}</p>

                <!-- Add to Cart Button -->
                <div class="mt-6">
                    <form action="{{ route('cart.add', $product) }}" method="POST">
                        @csrf
                        <button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600">
                            Add to Cart
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Related Products Section -->
<section class="py-12 bg-white">
    <div class="container mx-auto text-center">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Related Products</h2>

        <!-- Product Cards Grid -->
        {{-- <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            @foreach ($products as $relatedProduct)
                <div class="bg-white p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                    <img src="{{ asset('storage/' . $relatedProduct->image) }}" alt="{{ $relatedProduct->name }}" class="w-full h-40 object-cover rounded">
        <h3 class="text-lg font-semibold mt-4">{{ $relatedProduct->name }}</h3>
        <p class="text-gray-600 text-sm mt-2">{{ Str::limit($relatedProduct->description, 100) }}</p>
        <p class="text-sm text-gray-500 mt-2">Category: {{ $relatedProduct->category->name }}</p>
        <p class="text-lg font-bold mt-4">${{ number_format($relatedProduct->price, 2) }}</p>

        <div class="mt-4">
            <form action="{{ route('cart.add', $relatedProduct) }}" method="POST">
                @csrf
                <button type="submit" class="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600">Add to Cart</button>
            </form>
        </div>
    </div>
    @endforeach
    </div> --}}
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Change the main image when a thumbnail is clicked
            document.querySelectorAll('.thumbnail').forEach(function(thumbnail) {
                thumbnail.addEventListener('click', function() {
                    const newSrc = thumbnail.getAttribute('data-image');
                    const bigImage = document.getElementById('big-image');
                    bigImage.src = newSrc;
                });
            });

            // Zoom functionality for the big image
            const zoomImage = document.querySelector('.zoom-image');
            let scale = 1;

            zoomImage.addEventListener('click', function() {
                const modal = document.createElement('div');
                modal.classList.add('zoomModal', 'fixed', 'inset-0', 'bg-black',
                    'bg-opacity-70', 'flex', 'justify-center', 'items-center', 'z-50');

                const zoomedImg = document.createElement('img');
                zoomedImg.src = zoomImage.src;
                zoomedImg.classList.add('max-w-full', 'h-auto', 'cursor-zoom-out', 'rounded-md');

                const closeBtn = document.createElement('button');
                closeBtn.innerHTML = 'X';
                closeBtn.classList.add('absolute', 'top-4', 'right-4', 'text-white', 'p-2',
                    'bg-black', 'bg-opacity-50', 'hover:bg-opacity-80', 'rounded-full');

                closeBtn.addEventListener('click', function() {
                    modal.remove();
                });

                modal.appendChild(zoomedImg);
                modal.appendChild(closeBtn);
                document.body.appendChild(modal);

                // Zoom in and out
                zoomedImg.addEventListener('wheel', function(event) {
                    if (event.deltaY < 0) {
                        scale = Math.min(scale + 0.1, 3); // Zoom in, limit to 3x
                    } else {
                        scale = Math.max(scale - 0.1, 1); // Zoom out, limit to 1x
                    }
                    zoomedImg.style.transform = `scale(${scale})`;
                });
            });
        });
    </script>
</section>

@endsection