@extends('layouts.user')

@section('title', 'Your Cart')

@section('content')
<section class="py-0 bg-gray-50 min-h-screen">
    <div class="container mx-auto text-center px-6 md:px-12">
        <h1 class="text-4xl font-semibold text-gray-800 mb-0">Your Cart</h1>

        @if ($cartItems->isEmpty())
        <p class="text-lg text-gray-700">Your cart is empty!</p>
        @else
        <div class="bg-white p-8 rounded-xl shadow-lg">
            <ul class="space-y-6">
                @foreach ($cartItems as $item)
                <li class="flex justify-between items-center border-b py-4">
                    <div class="flex items-center space-x-4">
                        <!-- Product Image -->
                        <img src="{{ $item->product->image ? asset('storage/' . $item->product->image) : asset('images/placeholder.png') }}"
                            alt="{{ $item->product->name }}"
                            class="w-35 h-20 object-cover rounded-md mx-auto cursor-pointer">
                        <span class="font-medium text-gray-800 text-lg">{{ $item->product->name }}</span>
                        <span class="text-gray-600 text-lg">₹{{ number_format($item->product->price, 2) }}</span>
                    </div>
                    <div class="text-gray-600 text-sm">
                        Quantity: {{ $item->quantity }}
                    </div>

                    <!-- Remove Button with icon -->
                    <form action="{{ route('cart.remove', $item) }}" method="POST" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit"
                            class="text-red-500 flex items-center space-x-2 hover:text-red-700">
                            <i class="fas fa-trash-alt"></i>
                            <span>Remove</span>
                        </button>
                    </form>

                    <!-- Update Quantity with + and - buttons -->
                    <form action="{{ route('cart.updateQuantity', $item) }}" method="POST" class="inline">
                        @csrf
                        @method('PATCH')
                        <div class="space-y-2">
                            <!-- Quantity Input (on its own line) -->
                            <input type="number" name="quantity" value="{{ $item->quantity }}" min="1"
                                class="w-20 text-center border border-gray-300 rounded-md mx-auto block" readonly>

                            <!-- Container for buttons -->
                            <div class="flex space-x-2">
                                <!-- Decrease Button -->
                                <button type="submit" name="quantity" value="{{ $item->quantity - 1 }}"
                                    class="bg-gray-200 text-gray-600 px-3 py-1 rounded-md hover:bg-gray-300 w-20 flex items-center justify-center"
                                    {{ $item->quantity <= 1 ? 'disabled' : '' }}>
                                    <i class="fas fa-minus"></i>
                                </button>

                                <!-- Increase Button -->
                                <button type="submit" name="quantity" value="{{ $item->quantity + 1 }}"
                                    class="bg-gray-200 text-gray-600 px-3 py-1 rounded-md hover:bg-gray-300 w-20 flex items-center justify-center">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </li>
                @endforeach
            </ul>

            <div class="mt-8 flex justify-between items-center">
                <span class="font-bold text-xl">Total:
                ₹{{ number_format($cartItems->sum(fn($item) => $item->product->price * $item->quantity), 2) }}</span>
                <a href="{{ route('user.checkout') }}"
                    class="bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 flex items-center space-x-2">
                    <i class="fas fa-credit-card"></i>
                    <span>Proceed to Checkout</span>
                </a>
            </div>
        </div>
        @endif
    </div>
</section>
@if (session('success'))
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Success Icon -->
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <!-- Success Message -->
    <span>{{ session('success') }}</span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
@endif

<!-- Error Toast -->
@if (session('error'))
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Error Icon -->
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <!-- Error Message -->
    <span>{{ session('error') }}</span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
@endif
@endsection