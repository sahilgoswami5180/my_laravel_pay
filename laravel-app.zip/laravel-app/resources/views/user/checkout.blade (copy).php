@extends('layouts.user')

@section('title', 'Checkout')

@section('content')

{{-- Success Message --}}
@if(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif

{{-- Error Message --}}
@if(session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@endif

<div class="container mx-auto mt-8 px-4">

    <!-- Breadcrumb Navigation -->
    <nav class="flex text-md text-gray-600 mb-6 items-center justify-between">
        <div class="flex items-center space-x-2">
            <a href="{{ route('dashboard') }}"
                class="text-xs px-3 py-2 bg-gray-200 rounded-full hover:text-blue-500 flex items-center {{ Request::is('dashboard') ? 'text-blue-500' : '' }}">
                Home
            </a>
            <span class="mx-2 text-xs">/</span>
            <a href="{{ route('user.checkout') }}"
                class="text-xs px-3 py-2 bg-gray-200 rounded-full hover:text-blue-500 flex items-center {{ Request::is('checkout') ? 'text-blue-500' : '' }}">
                Checkout
            </a>
        </div>
    </nav>

    <!-- Cart Items -->
    @if($cartItems->count() > 0)
    <div class="bg-white shadow-lg rounded-lg p-6 mb-8">
        <h2 class="text-2xl font-semibold mb-6 text-gray-800">Your Cart</h2>
        <table class="min-w-full table-auto border-collapse">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="border px-4 py-2 text-left">Product</th>
                    <th class="border px-4 py-2 text-left">Price</th>
                    <th class="border px-4 py-2 text-left">Quantity</th>
                    <th class="border px-4 py-2 text-left">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($cartItems as $item)
                <tr class="hover:bg-gray-50 transition-colors duration-200">
                    <td class="border px-4 py-2 flex items-center space-x-4">
                        <img src="{{ asset('storage/' . $item->product->image) }}" alt="{{ $item->product->name }}" class="w-16 h-16 object-cover rounded-md">
                        <span>{{ $item->product->name }}</span>
                    </td>
                    <td class="border px-4 py-2 text-gray-700">${{ number_format($item->product->price, 2) }}</td>
                    <td class="border px-4 py-2 text-gray-700">{{ $item->quantity }}</td>
                    <td class="border px-4 py-2 text-gray-700">${{ number_format($item->product->price * $item->quantity, 2) }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <!-- Recommended Products Section -->
    <div class="bg-white shadow-lg rounded-lg p-6 mt-8">
        <h2 class="text-2xl font-semibold mb-6 text-gray-800">Recommended for You</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            @foreach($recommendedProducts as $product)
            <a href="{{ route('user.product_details', $product->id) }}"
                class="bg-white p-6 rounded-lg shadow-lg hover:scale-105 transform transition-all duration-300">
                <!-- Product Image -->
                <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}"
                    class="w-full h-48 object-cover rounded-md mb-4">

                <!-- Product Title -->
                <h3 class="text-lg font-semibold mt-2 text-gray-800">{{ $product->name }}</h3>

                <!-- Product Description -->
                <p class="text-gray-600 text-sm mt-2">
                    {{ Str::limit($product->description, 100) }}
                </p>

                <!-- Product Category -->
                <p class="text-sm text-gray-500 mt-2">Category: {{ $product->category->name }}</p>

                <!-- Product Price -->
                <p class="text-lg font-bold mt-4 text-gray-800">${{ number_format($product->price, 2) }}</p>

                <!-- Add to Cart Button -->
                <form action="{{ route('cart.add', $product) }}" method="POST" class="mt-4">
                    @csrf
                    <button type="submit" class="w-full bg-gradient-to-r from-blue-500 to-green-500 text-white py-2 rounded-md hover:bg-gradient-to-r hover:from-blue-600 hover:to-green-600 transition duration-300">
                        Add to Cart
                    </button>
                </form>
            </a>
            @endforeach
        </div>
    </div>

    <!-- Checkout Summary -->
    <div class="bg-white shadow-lg rounded-lg p-6 mb-8">
        <h2 class="text-xl font-semibold mb-6 text-gray-800">Checkout Summary</h2>
        <div class="flex justify-between mb-6">
            <span class="text-lg font-medium text-gray-700">Total:</span>
            <span class="text-lg font-medium text-gray-700">${{ number_format($total, 2) }}</span>
        </div>
    </div>

    <!-- Payment Options -->
    <div class="flex flex-col space-y-6">
        <form action="{{ route('checkout.cod') }}" method="POST">
            @csrf
            <button type="submit" class="w-full bg-gradient-to-r from-blue-500 to-green-500 text-white text-lg font-semibold py-3 rounded-full shadow-lg hover:scale-105 transition-all duration-300">
                Cash on Delivery
            </button>
        </form>

        <!-- Stripe Checkout Form -->
        <form action="{{ route('checkout.process') }}" method="POST">
            @csrf
            <button type="submit" class="w-full bg-gradient-to-r from-blue-500 to-green-500 text-white text-lg font-semibold py-3 rounded-full shadow-lg hover:scale-105 transition-all duration-300">
                Pay with Stripe
            </button>
        </form>
    </div>

    @else
    <div class="text-center">
        <p class="text-gray-500">Your cart is empty. Add items to your cart to proceed with checkout.</p>
    </div>
    @endif

</div>

@endsection