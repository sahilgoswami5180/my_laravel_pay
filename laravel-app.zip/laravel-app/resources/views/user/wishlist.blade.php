@extends('layouts.user')

@section('content')
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">My Wishlist</h2>

            @if (empty($products))
                <p class="text-center text-gray-600">Your wishlist is empty.</p>
            @else
                <ul class="space-y-4">
                    @foreach ($products as $product)
                        <li class="flex justify-between items-center">
                            <span class="text-gray-700">{{ $product['name'] }}</span>
                            <span class="text-gray-500">{{ $product['price'] }}</span>
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
@endsection
