@extends('layouts.user')

@section('title', 'Checkout')

@section('content')

@if (session('success'))
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Success Icon -->
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <!-- Success Message -->
    <span>{{ session('success') }}</span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
@endif

<!-- Error Toast -->
@if (session('error'))
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Error Icon -->
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <!-- Error Message -->
    <span>{{ session('error') }}</span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
@endif

    <div class="container mx-auto mt-8 px-4">

        <!-- Cart Items -->
        @if ($cartItems->count() > 0)
            <div class="bg-white shadow-xl rounded-lg p-6 mb-8">
                <h2 class="text-2xl font-semibold mb-4">Items in Cart <i class="fas fa-cart-arrow-down"></i></h2>
                <table class="min-w-full table-auto border-collapse">
                    <thead class="bg-gray-100 text-gray-600">
                        <tr>
                            <th class="border px-4 py-2 text-left">Product</th>
                            <th class="border px-4 py-2 text-left">Price</th>
                            <th class="border px-4 py-2 text-left">Quantity</th>
                            <th class="border px-4 py-2 text-left">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($cartItems as $item)
                            <tr class="hover:bg-gray-50 transition-colors duration-200">
                                <td class="border px-4 py-2 flex items-center">
                                    <img src="{{ asset('storage/' . $item->product->image) }}"
                                        alt="{{ $item->product->name }}" class="w-16 h-16 object-cover mr-4 rounded-md">
                                    <span>{{ $item->product->name }}</span>
                                </td>
                                <td class="border px-4 py-2">₹ {{ number_format($item->product->price, 2) }}</td>
                                <td class="border px-4 py-2">{{ $item->quantity }}</td>
                                <td class="border px-4 py-2">
                                ₹ {{ number_format($item->product->price * $item->quantity, 2) }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Recommended Products Section -->
            <div class="bg-white shadow-xl rounded-lg p-6 mt-8">
                <h2 class="text-2xl font-semibold mb-4">Recommended for You <i class="fas fa-gift"></i></h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    @foreach ($recommendedProducts as $product)
                        <a href="{{ route('user.product_details', $product->id) }}"
                            class="bg-white p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300">
                            <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}"
                                class="w-full h-48 object-cover rounded-md mb-4">
                            <h3 class="text-lg font-semibold mt-2 text-gray-800">{{ $product->name }}</h3>
                            <p class="text-gray-600 text-sm mt-2">{{ Str::limit($product->description, 100) }}</p>
                            <p class="text-sm text-gray-500 mt-2">Category: {{ $product->category->name }}</p>
                            <p class="text-lg font-bold mt-4 text-gray-800">₹ {{ number_format($product->price, 2) }}</p>
                            <div class="mt-4">
                                <form action="{{ route('cart.add', $product) }}" method="POST">
                                    @csrf
                                    <button type="submit"
                                        class="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600 transition duration-300">
                                        <i class="fas fa-cart-plus"></i> Add to Cart
                                    </button>
                                </form>
                            </div>
                        </a>
                    @endforeach
                </div>
            </div>
<!-- Enter Delivery Address Section -->
<div class="bg-white shadow-xl rounded-lg p-6 mb-8">
                <h2 class="text-3xl font-semibold mb-6 text-gray-800 flex items-center space-x-2">
                    <i class="fas fa-map-marker-alt text-blue-500"></i>
                    <span>Enter Delivery Address</span>
                </h2>

                <!-- Delivery Address Form -->
                <form action="{{ route('checkout.process') }}" method="POST">
    @csrf
    <label for="address" class="block text-lg font-medium mb-2">Address</label>
    <input type="text" id="address" name="address"
        class="w-full p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
        placeholder="Your address" required>
    <div id="map" class="mt-6 w-full" style="height: 450px;"></div>

    <!-- Hidden Fields to Store Latitude and Longitude -->
    <input type="hidden" id="latitude" name="latitude">
    <input type="hidden" id="longitude" name="longitude">

    <!-- Payment Methods Header -->
    <div class="mt-8 mb-6">
        <h3 class="text-xl font-semibold">Select Payment Method</h3>
    </div>

    <!-- Payment Options -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

        <!-- Stripe Payment Option -->
        <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all hover:scale-105">
            <i class="fab fa-stripe text-4xl text-blue-500"></i>
            <h4 class="mt-2 font-medium text-lg">Pay with Stripe</h4>
            <p class="text-gray-600 mt-2">Secure and fast online payments.</p>
            <button type="submit" name="payment_method" value="stripe"
                class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300 mt-4">
                <i class="fab fa-stripe"></i> Choose Stripe Payment
            </button>
        </div>

        <!-- Cash on Delivery Option -->
        <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all hover:scale-105 ">
            <i class="fas fa-cash-register text-4xl text-green-500"></i>
            <h4 class="mt-2 font-medium text-lg">Cash on Delivery</h4>
            <p class="text-gray-600 mt-2">Pay with cash when your order arrives.</p>
            <button type="submit" name="payment_method" value="cod"
                class="w-full bg-green-500 text-white px-6 py-3 rounded-md font-medium hover:bg-green-600 transition duration-300 mt-4">
                <i class="fas fa-cash-register"></i> Choose Cash on Delivery
            </button>
        </div>

        <!-- Razorpay Payment Option -->
        <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all hover:scale-105 mt-6">
            <i class="fas fa-credit-card text-4xl text-blue-500"></i>
            <h4 class="mt-2 font-medium text-lg">Pay with Razorpay</h4>
            <p class="text-gray-600 mt-2">Secure payment gateway</p>
            <button id="razorpay-button" class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300 mt-4">
                <i class="fas fa-credit-card"></i> Choose Razorpay Payment
            </button>
        </div>

        <!-- Paytm Payment Option -->
<div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all hover:scale-105 mt-6">
    <i class="fab fa-paytm text-4xl text-blue-500"></i>
    <h4 class="mt-2 font-medium text-lg">Pay with Paytm</h4>
    <p class="text-gray-600 mt-2">Secure and fast Paytm payments.</p>
    <button type="submit" name="payment_method" value="paytm"
        class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300 mt-4">
        <i class="fab fa-paytm"></i> Choose Paytm Payment
    </button>
</div>

 <!-- PayPal Payment Option -->
 <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all hover:scale-105 mt-6">
        <i class="fab fa-paypal text-4xl text-yellow-600"></i>
        <h4 class="mt-2 font-medium text-lg">Pay with PayPal</h4>
        <p class="text-gray-600 mt-2">Fast and secure PayPal payments.</p>
        <button id="paypal-button" type="button"
            class="w-full bg-yellow-600 text-white px-6 py-3 rounded-md font-medium hover:bg-yellow-700 transition duration-300 mt-4">
            <i class="fab fa-paypal"></i> Choose PayPal Payment
        </button>
    </div>
    </div>
</form>

<!-- Razorpay Script -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script>
    document.getElementById('razorpay-button').onclick = function (e) {
        e.preventDefault();

        var options = {
            "key": "{{ env('RAZORPAY_KEY') }}", // Your Razorpay Key
            "amount": "{{ $total * 100 }}", // Amount in Paise (total price in cents)
            "currency": "INR",
            "name": "Your Company Name",
            "description": "Payment for Order",
            "image": "https://your-logo-url.com/logo.png",
            "order_id": "", // Razorpay order ID
            "handler": function (response) {
                // Send the response details to the backend for further processing
                fetch("{{ route('checkout.razorpay.success') }}", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "{{ csrf_token() }}"
                    },
                    body: JSON.stringify({
                        razorpay_payment_id: response.razorpay_payment_id,
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_signature: response.razorpay_signature,
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = data.redirect_url;
                    }
                });
            },
            "prefill": {
                "name": "{{ Auth::user()->name }}",
                "email": "{{ Auth::user()->email }}",
                "contact": "{{ Auth::user()->phone_number }}"
            },
            "theme": {
                "color": "#F37254"
            }
        };

        var rzp1 = new Razorpay(options);
        rzp1.open();
    }
</script>


            </div>
        @else
            <div class="text-center">
                <p class="text-gray-500">No items added yet. Browse and add products to your cart to proceed with checkout.
                    <i class="fas fa-cart-arrow-down"></i>
                </p>
            </div>
        @endif
 <!-- Google Maps API Script -->
 <script
        src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&callback=initMap&key=AIzaSyCz7Bo_xQIywAxLvk5BRR5xz70VY2VhLPk"
        async defer></script>

        <script>
    let map;
    let geocoder;
    let marker;
    let autocomplete;

    function initMap() {
        if (typeof google === 'undefined') {
            console.error("Google Maps API failed to load.");
            return;
        }

        geocoder = new google.maps.Geocoder();

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const userLat = position.coords.latitude;
                const userLng = position.coords.longitude;
                const userLocation = {
                    lat: userLat,
                    lng: userLng
                };

                map = new google.maps.Map(document.getElementById('map'), {
                    center: userLocation,
                    zoom: 14
                });

                marker = new google.maps.Marker({
                    position: userLocation,
                    map: map,
                    title: "Your location"
                });

                document.getElementById('latitude').value = userLat;
                document.getElementById('longitude').value = userLng;

                // Setup the autocomplete for the address field
                autocomplete = new google.maps.places.Autocomplete(document.getElementById('address'), {
                    types: ['geocode'],  // Only allow addresses
                });

                autocomplete.addListener('place_changed', function () {
                    const place = autocomplete.getPlace();
                    if (!place.geometry) {
                        console.error("Place has no geometry");
                        return;
                    }

                    // Set the map to the address location
                    map.setCenter(place.geometry.location);
                    marker.setPosition(place.geometry.location);

                    // Fill in the latitude and longitude hidden fields
                    document.getElementById('latitude').value = place.geometry.location.lat();
                    document.getElementById('longitude').value = place.geometry.location.lng();

                    // Fill the address field with the selected address
                    document.getElementById('address').value = place.formatted_address;
                });

                // Allow map click to update location and address
                google.maps.event.addListener(map, 'click', function(event) {
                    const lat = event.latLng.lat();
                    const lng = event.latLng.lng();

                    // Update hidden latitude and longitude fields
                    document.getElementById('latitude').value = lat;
                    document.getElementById('longitude').value = lng;

                    // Set the marker position to the clicked location
                    marker.setPosition(event.latLng);

                    // Perform reverse geocoding to get the address
                    geocodeLatLng(lat, lng);
                });

            }, function() {
                const defaultLocation = {
                    lat: 23.0260736,
                    lng: 72.5581824
                };
                createMapWithLocation(defaultLocation);
            });
        } else {
            const defaultLocation = {
                lat: 23.0260736,
                lng: 72.5581824
            };
            createMapWithLocation(defaultLocation);
        }
    }

    function createMapWithLocation(location) {
        map = new google.maps.Map(document.getElementById('map'), {
            center: location,
            zoom: 14
        });

        marker = new google.maps.Marker({
            position: location,
            map: map,
            title: "Click to select an address"
        });

        google.maps.event.addListener(map, 'click', function(event) {
            const lat = event.latLng.lat();
            const lng = event.latLng.lng();

            // Update hidden latitude and longitude fields
            document.getElementById('latitude').value = lat;
            document.getElementById('longitude').value = lng;

            // Set the marker position to the clicked location
            marker.setPosition(event.latLng);

            // Perform reverse geocoding to get the address
            geocodeLatLng(lat, lng);
        });
    }

    function geocodeLatLng(lat, lng) {
        const latLng = {
            lat: lat,
            lng: lng
        };
        geocoder.geocode({
            'location': latLng
        }, function(results, status) {
            if (status === 'OK') {
                if (results[0]) {
                    // Populate the address field with the formatted address
                    document.getElementById('address').value = results[0].formatted_address;
                } else {
                    alert('No results found');
                }
            } else {
                alert('Geocoder failed due to: ' + status);
            }
        });
    }
</script>

    </div>

@endsection
