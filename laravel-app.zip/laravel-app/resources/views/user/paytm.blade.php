<form method="post" action="https://secure.paytm.in/theia/processTransaction" name="paytm_form">
    @csrf
    @foreach ($paytmParams as $key => $value)
        <input type="hidden" name="{{ $key }}" value="{{ $value }}">
    @endforeach
    <button type="submit" class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300 mt-4">
        Pay with Paytm
    </button>
</form>
<script type="text/javascript">
    document.paytm_form.submit();
</script>
