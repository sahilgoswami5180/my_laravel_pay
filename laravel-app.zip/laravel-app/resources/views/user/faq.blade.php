@extends('layouts.user')

@section('content')
    <div class="flex items-center justify-center">
        <div class="bg-white shadow-lg rounded-lg p-8 w-full max-w-lg">
            <h2 class="text-3xl font-semibold text-center mb-6 text-gray-800">FAQ</h2>

            <div class="space-y-4">
                <div class="border-b pb-4">
                    <h3 class="font-semibold text-gray-800">How can I reset my password?</h3>
                    <p class="text-gray-600">You can reset your password by going to the "Change Password" section in your
                        profile.</p>
                </div>

                <div class="border-b pb-4">
                    <h3 class="font-semibold text-gray-800">How do I track my order?</h3>
                    <p class="text-gray-600">You can track your orders in the "My Orders" section in your profile.</p>
                </div>

                <div class="border-b pb-4">
                    <h3 class="font-semibold text-gray-800">How can I contact customer support?</h3>
                    <p class="text-gray-600">You can reach our support team by filling out the contact form in the "Support"
                        section.</p>
                </div>
            </div>
        </div>
    </div>
@endsection
