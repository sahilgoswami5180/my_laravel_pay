@extends('layouts.app')

@section('title', 'Product Details')

@section('content')
<div class="container mx-auto mt-8">
    <div class="bg-white shadow-lg rounded-lg p-8 mb-8">
        <!-- Title and Back Button -->
        <div class="flex items-center justify-between mb-4">
            <div>
                <h6 class="text-xl font-semibold">
                    <a href="{{ route('products.index') }}" class="mr-2 text-blue-800 hover:text-blue-600" id="goBackLink">
                        <i class="fa-solid fa-arrow-left-long"></i>
                    </a>
                    {{ $product->name }}
                </h6>
            </div>
        </div>

        <!-- Product Information Section -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Product Image -->
            <div class="bg-white shadow-lg rounded-lg p-6 flex justify-center items-center">
                <div class="image-carousel-container relative">
                    @php
                    $images = explode(',', $product->images); // Convert the comma-separated string into an array
                    @endphp

                    @if (is_array($images) && count($images) > 0)
                    <!-- Big Image -->
                    <div id="big-image-container" class="mb-4">
                        <img id="big-image" src="{{ asset('storage/' . $images[0]) }}" alt="{{ $product->name }}"
                            class="zoom-image w-56 h-56 mx-auto object-cover rounded-md cursor-pointer" />
                    </div>

                    <!-- Thumbnail Images -->
                    <div id="thumbnails" class="flex space-x-4 overflow-x-auto overflow-y-hidden">
                        @foreach ($images as $index => $image)
                        <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}"
                            class="thumbnail w-16 h-16 object-cover cursor-pointer rounded-md"
                            data-image="{{ asset('storage/' . $image) }}" />
                        @endforeach
                    </div>
                    @else
                    <img src="{{ asset('images/placeholder.png') }}" alt="{{ $product->name }}"
                        class="zoom-image w-full h-auto object-cover rounded-md cursor-pointer" />
                    @endif
                </div>
            </div>

            <!-- Product Details -->
            <div class="bg-white shadow-lg rounded-lg p-6">
                <table class="min-w-full table-auto">
                    <tbody>
                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Product Name</th>
                            <td class="py-2 px-4">{{ $product->name }}</td>
                        </tr>

                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Category</th>
                            <td class="py-2 px-4">{{ $product->category->name }}</td>
                        </tr>
                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Price</th>
                            <td class="py-2 px-4 text-xl font-semibold text-gray-900">
                                ₹{{ number_format($product->price, 2) }}</td>
                        </tr>

                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Description</th>
                            <td class="py-2 px-4">{{ $product->description }}</td>
                        </tr>
                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Created At</th>
                            <td class="py-2 px-4">{{ $product->created_at->format('Y-m-d H:i:s') }}</td>
                        </tr>
                        <tr>
                            <th class="text-left font-semibold py-2 px-4">Updated At</th>
                            <td class="py-2 px-4">{{ $product->updated_at->format('Y-m-d H:i:s') }}</td>
                        </tr>
                    </tbody>
                </table>
                <div class="flex justify-center space-x-4 mt-8">
                    <a href="{{ route('products.edit', $product->id) }}"
                        class="btn btn-primary px-6 py-3 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200 ease-in-out">
                        <i class="fa-solid fa-pencil"></i> Edit
                    </a>
                    <form action="{{ route('products.destroy', $product->id) }}" method="POST" class="inline-block">
                        @csrf
                        @method('DELETE')
                        <button type="submit"
                            class="btn btn-danger px-6 py-3 bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 focus:ring-4 focus:ring-red-300 transition duration-200 ease-in-out"
                            onclick="return confirm('Are you sure you want to delete this item?')">
                            <i class="fas fa-trash-alt"></i> Delete
                        </button>
                    </form>
                </div>
            </div>

        </div>

        <!-- Action Buttons -->

    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Change the main image when a thumbnail is clicked
        document.querySelectorAll('.thumbnail').forEach(function(thumbnail) {
            thumbnail.addEventListener('click', function() {
                const newSrc = thumbnail.getAttribute('data-image');
                const bigImage = document.getElementById('big-image');
                bigImage.src = newSrc;
            });
        });

        // Zoom functionality for the big image
        const zoomImage = document.querySelector('.zoom-image');
        let scale = 1;

        zoomImage.addEventListener('click', function() {
            const modal = document.createElement('div');
            modal.classList.add('zoomModal', 'fixed', 'inset-0', 'bg-black',
                'bg-opacity-70', 'flex', 'justify-center', 'items-center', 'z-50');

            const zoomedImg = document.createElement('img');
            zoomedImg.src = zoomImage.src;
            zoomedImg.classList.add('max-w-full', 'h-auto', 'cursor-zoom-out', 'rounded-md');

            const closeBtn = document.createElement('button');
            closeBtn.innerHTML = 'X';
            closeBtn.classList.add('absolute', 'top-4', 'right-4', 'text-white', 'p-2',
                'bg-black', 'bg-opacity-50', 'hover:bg-opacity-80', 'rounded-full');

            closeBtn.addEventListener('click', function() {
                modal.remove();
            });

            modal.appendChild(zoomedImg);
            modal.appendChild(closeBtn);
            document.body.appendChild(modal);

            // Zoom in and out
            zoomedImg.addEventListener('wheel', function(event) {
                if (event.deltaY < 0) {
                    scale = Math.min(scale + 0.1, 3); // Zoom in, limit to 3x
                } else {
                    scale = Math.max(scale - 0.1, 1); // Zoom out, limit to 1x
                }
                zoomedImg.style.transform = `scale(${scale})`;
            });
        });
    });
</script>

<style>
    .carousel {
        position: relative;
        width: 100%;
        max-width: 300px;
        margin: 0 auto;
    }

    .carousel-images {
        display: flex;
        overflow: hidden;
    }

    .carousel-item {
        display: none;
        transition: opacity 0.5s ease-in-out;
    }

    .carousel-item img {
        width: 300px;
        height: auto;
    }

    .carousel-item.active {
        display: block;
    }

    .carousel-prev,
    .carousel-next {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        font-size: 1.5rem;
        color: white;
        border: none;
        cursor: pointer;
        padding: 5px;
        margin-left: -50px;
        margin-right: -50px;
        border-radius: 50%;
    }

    .carousel-prev {
        left: 5px;
    }

    .carousel-next {
        right: 5px;
    }

    .zoomModal {
        transition: transform 0.3s ease-in-out;
    }

    .zoomModal img {
        max-width: 90%;
        max-height: 90%;
    }

    .thumbnail {
        transition: transform 0.3s ease;
        cursor: pointer;
    }

    .thumbnail:hover {
        transform: scale(1.1);
    }

    #thumbnails {
        display: flex;
        overflow-x: auto;
        overflow-y: hidden;
        gap: 8px;
    }

    #thumbnails::-webkit-scrollbar {
        display: none;
    }

    #thumbnails::-webkit-scrollbar {
        width: 8px;
    }

    #thumbnails::-webkit-scrollbar-thumb {
        background-color: #888;
        border-radius: 10px;
    }

    #thumbnails::-webkit-scrollbar-thumb:hover {
        background-color: #555;
    }
</style>
@endsection

<!-- <a href="{{ route('user.product_details', $product) }}"></a> -->
