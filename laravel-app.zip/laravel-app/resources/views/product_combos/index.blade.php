@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Product Combos</h1>
    <table class="min-w-full bg-white rounded-lg shadow-lg">
        <thead>
            <tr class="text-left bg-gray-200">
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Name</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Description</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Total Price</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Discount Price</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Selected Products</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Image</th>
                <th class="px-6 py-3 text-sm font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($combos as $combo)
            <tr class="border-t border-gray-200 hover:bg-gray-50">
                <td class="px-6 py-4 text-sm text-gray-800">{{ $combo->name }}</td>
                <td class="px-6 py-4 text-sm text-gray-600">{{ $combo->description }}</td>
                <td class="px-6 py-4 text-sm text-gray-800">{{ $combo->total_price }}</td>
                <td class="px-6 py-4 text-sm text-gray-800">{{ $combo->disc_price }}</td>

                <!-- Displaying Selected Products -->
                <td class="px-6 py-4 text-sm text-gray-600">
                    @foreach ($combo->products as $product)
                    <span class="block text-gray-800">{{ $product->name }}</span>
                    @endforeach
                </td>
                <!-- Displaying the Product Image -->
                <td class="px-6 py-4 text-sm text-gray-600">
                    @if($combo->image_path && Storage::exists('public/' . $combo->image_path))
                    <img src="{{ asset('storage/' . $combo->image_path) }}" alt="{{ $combo->name }}" class="w-16 h-16 object-cover rounded-lg">
                    @else
                    <img src="{{ asset('images/default-image.jpg') }}" alt="Default Image" class="w-16 h-16 object-cover rounded-lg">
                    @endif
                </td>
                <td class="px-6 py-4 text-sm space-x-2">
                    <!-- Edit Button -->
                    <a href="{{ route('product_combos.edit', $combo->id) }}" class="inline-flex items-center px-4 py-2 text-white bg-yellow-500 hover:bg-yellow-600 rounded-lg transition duration-300">
                        <i class="fas fa-edit mr-2"></i>Edit
                    </a>

                    <!-- Delete Button -->
                    <form action="{{ route('product_combos.destroy', $combo->id) }}" method="POST" class="inline-block" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="inline-flex items-center px-4 py-2 text-white bg-red-500 hover:bg-red-600 rounded-lg transition duration-300">
                            <i class="fas fa-trash mr-2"></i>Delete
                        </button>
                    </form>

                    <!-- Soft Delete Button -->
                    <form action="{{ route('product_combos.softdelete', $combo->id) }}" method="POST" class="inline-block" style="display:inline;">
                        @csrf
                        <button type="submit" class="inline-flex items-center px-4 py-2 text-white bg-gray-500 hover:bg-gray-600 rounded-lg transition duration-300">
                            <i class="fas fa-archive mr-2"></i>Soft Delete
                        </button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

</div>
@endsection