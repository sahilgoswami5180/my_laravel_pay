@extends('layouts.app')

@section('content')
    <div class="container mx-auto mt-0">
        <!-- Breadcrumb Navigation -->
        <nav class="flex text-md text-gray-600 mb-2 items-center justify-between">
            <div class="flex items-center">
                <a href="{{ route('dashboard') }}"
                    class="hover:text-blue-500 flex items-center {{ Request::is('dashboard') ? 'text-blue-500' : '' }}">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <a href="{{ route('categories.index') }}"
                    class="hover:text-blue-500 flex items-center {{ Request::is('categories') || Request::is('categories/*') ? 'text-blue-500' : '' }}">
                    <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Categories</span>
                </a>
                <span class="mx-2 text-xs">/</span>
                <span class="text-xs px-2 py-1 bg-gray-200 rounded-full text-blue-500">Subcategories</span>
            </div>

            <!-- Back to Category Button -->
            <div class="flex items-center">
                <a href="{{ route('categories.index') }}"
                    class="bg-blue-500 text-white px-4 py-2 rounded-full shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300">
                    Back to Categories
                </a>
            </div>
        </nav>

        <!-- Heading with Centered and Uppercase Category Name -->
        <h1 class="text-2xl font-semibold text-gray-800 mb-6 text-center uppercase">
            Subcategories for Category: {{ $category->name }}
        </h1>

        <!-- Card View for Subcategories -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            @if ($subcategories->count())
                @foreach ($subcategories as $subcategory)
                    <a href="{{ route('subcategories.show', $subcategory->id) }}" class="block">
                        <div class="bg-white rounded-lg shadow-md overflow-hidden p-2">
                            <img src="{{ $subcategory->image ? asset('storage/' . $subcategory->image) : asset('images/placeholder.png') }}"
                                alt="{{ $subcategory->name }}" class="w-full h-48 object-cover">
                            <div class="p-4">
                                <h3 class="text-lg font-semibold text-gray-800">{{ $subcategory->name }}</h3>
                                <!-- Description with Truncation -->
                                <p class="text-sm text-gray-600 mt-2 line-clamp-2">
                                    <strong>Description:</strong> {{ $subcategory->description }}
                                </p>
                                <p class="text-sm text-gray-600 mt-2"><strong>Category:</strong> {{ $category->name }}</p>
                            </div>
                        </div>
                    </a>
                @endforeach
            @else
                <div class="col-span-full text-center text-gray-500 py-6">
                    <p>No subcategories found for this category. <a href="{{ route('subcategories.create') }}"
                            class="text-blue-500 underline">Create one</a> now!</p>
                </div>
            @endif
        </div>

        <!-- Pagination -->
        <div class="mt-6">
            {{ $subcategories->links() }}
        </div>
    </div>

    <!-- Success Toast -->
    @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span>{{ session('success') }}</span>
        </div>
        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <!-- Error Toast -->
    @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span>{{ session('error') }}</span>
        </div>
        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    @endif
@endsection
