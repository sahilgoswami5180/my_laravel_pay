@extends('layouts.app')

@section('title', 'Create Category')

@section('content')

    <div class="container mx-auto mt-0">

        <!-- Breadcrumb Navigation -->
        <nav class="flex text-sm text-gray-600 mb-6 items-center">
            <a href="{{ route('dashboard') }}"
                class="flex items-center {{ Request::is('dashboard') ? 'text-blue-500' : '' }}">
                <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Home</span>
            </a>
            <span class="mx-2 text-xs">/</span>
            <a href="{{ route('categories.index') }}"
                class="flex items-center {{ Request::is('categories') || Request::is('categories/*') ? 'text-blue-500' : '' }}">
                <span class="text-xs px-2 py-1 bg-gray-200 rounded-full">Categories</span>
            </a>
            <span class="mx-2 text-xs">/</span>
            <span class="text-xs text-gray-500">Create</span>
        </nav>

        <!-- Full-Screen Width Card Container for the Form -->
        <div class="w-full bg-white p-8 rounded-lg shadow-xl">
            <!-- Flex container to align Button and Page Title -->
            <div class="flex justify-between items-center mb-6">
                <!-- Page Title -->
                <h2 class="text-3xl font-semibold text-gray-800"><i class="fas fa-plus-circle mr-2"></i> Add New Category
                </h2> <!-- Add Icon to Title -->
            </div>

            <!-- Form to Create Category -->
            <form action="{{ route('categories.store') }}" method="POST" class="space-y-6" enctype="multipart/form-data">
                @csrf

                <!-- Category Name -->
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">
                        Category Name <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <input type="text" name="name" id="name" value="{{ old('name') }}"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-tag absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>

                    @error('name')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Category Description -->
                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-700">
                        Category Description <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <textarea name="description" id="description" rows="2" maxlength="100" oninput="updateCharCount()"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">{{ old('description') }}</textarea>
                        <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>

                    <div class="flex justify-end text-sm text-gray-500 mt-1">
                        <span id="charCount">0</span> / 100
                    </div>

                    @error('description')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Category Image Upload -->
                <div class="mb-4">
                    <label for="image" class="block text-sm font-medium text-gray-700">
                        Category Image <span class="text-red-500">*</span>
                    </label>
                    <input type="file" name="image" id="image" accept="image/*"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">

                    @error('image')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>


                <div class="flex justify-end gap-4 mt-6">
                    <!-- Cancel Button -->
                    <a href="{{ route('categories.index') }}"
                        class="bg-gray-300 text-gray-700 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                        <i class="fas fa-times-circle mr-2"></i> Cancel
                    </a>
                    <!-- Submit Button -->
                    <button type="submit"
                        class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                        <i class="fas fa-check-circle mr-2"></i>
                        Create Category
                    </button>
                </div>
            </form>
        </div>

    </div>

    @if (session('success'))
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span>{{ session('success') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <!-- Error Toast -->
    @if (session('error'))
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span>{{ session('error') }}</span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    @endif

    <script>
        // Function to update character count
        function updateCharCount() {
            const textarea = document.getElementById('description');
            const charCount = document.getElementById('charCount');
            charCount.textContent = textarea.value.length; // Update character count
        }
    </script>

@endsection
