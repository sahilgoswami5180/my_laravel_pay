<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductCombosTable extends Migration
{
    public function up()
    {
        Schema::create('product_combos', function (Blueprint $table) {
            $table->id();
            $table->string('name');  // Name of the combo
            $table->text('description');  // Description of the combo
            $table->decimal('total_price', 10, 2);  // Total price of the combo
            $table->decimal('disc_price', 10, 2);  // Discounted price of the combo
            $table->string('image')->nullable();  // Image for the combo (optional)
            $table->boolean('softdelete')->default(false);  // For soft delete
            $table->foreignId('category_id')->constrained()->onDelete('cascade');
            $table->foreignId('subcategory_id')->constrained()->onDelete('cascade');
            $table->softDeletes();
            $table->timestamps();
        });

        // Create the pivot table for product relationships
        Schema::create('product_combo_product', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_combo_id')->constrained()->onDelete('cascade');
            $table->foreignId('product_id')->constrained()->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('product_combo_product');
        Schema::dropIfExists('product_combos');
        Schema::table('product_combos', function (Blueprint $table) {
            $table->dropSoftDeletes(); // This will remove the 'deleted_at' column
        });
    }
}
