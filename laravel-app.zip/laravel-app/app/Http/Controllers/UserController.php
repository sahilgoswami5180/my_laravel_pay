<?php

namespace App\Http\Controllers;

use App\Jobs\DeleteUserAccount;
use App\Mail\AccountDeletionNotice;
use App\Models\Product;
use App\Models\Category;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\SupportRequest;
use App\Models\Wishlist;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
    /**
     * Show the user dashboard or main user page.
     */
    public function index(Request $request)
    {
        // Get categories for filtering
        $categories = Category::all();
        $categories = Category::all();
        $query = Product::query();

        // Start with fetching all active products
        $products = Product::where('status', 'active');

        // Apply category filter if category is selected
        if ($request->has('category_id')) {
            $products = $products->where('category_id', $request->category_id);
        }

        // Apply search filter if there's a search query
        if ($request->has('search') && $request->search != '') {
            $products = $products->where('name', 'like', '%' . $request->search . '%');
        }

        // Apply category filter
        if ($request->has('category_id') && $request->category_id) {
            $query->where('category_id', $request->category_id);
        }

        // Apply price range filter
        if ($request->has('price_range') && $request->price_range) {
            $query->where('price', '<=', $request->price_range);
        }

        // Get the filtered products
        $filteredProducts = $query->get();
        // Fetch the products
        $products = $products->get();

        // Get cart items from session (or database if persistent cart)
        $cartItems = session('cart', []);

        return view('user.index', compact('products', 'categories', 'filteredProducts', 'cartItems'));
    }
 
    /**
     * Show products for a specific category.
     */
    public function categorywiseshow($categoryId)
    {
        // Fetch category by ID or throw 404 if not found
        $category = Category::findOrFail($categoryId);

        // Fetch products associated with the category
        $products = Product::where('category_id', $categoryId)->where('status', 'active')->paginate(10);

        // Check if the category has no products
        if ($products->isEmpty()) {
            return back()->with('error', 'No products found for this category.');
        }

        // Return the view with the category and products
        return view('user.categorywiseproduct', compact('category', 'products'));
    }

    /**
     * Show product details.
     */
    public function show($id)
    {
        $product = Product::with('category')->findOrFail($id);
        return view('user.product_details', compact('product'));
    }

    /**
     * Add product to the cart.
     */
    public function addToCart(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        // Get cart from session
        $cart = session('cart', []);

        // If product already exists in cart, update quantity
        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            // Add new product to the cart
            $cart[$id] = [
                'name' => $product->name,
                'price' => $product->price,
                'quantity' => 1,
                'image' => $product->image
            ];
        }

        // Store the updated cart in the session
        session(['cart' => $cart]);

        return redirect()->route('user.index')->with('success', 'Product added to cart.');
    }

    /**
     * Update product quantity in the cart.
     */
    public function updateQuantity(Request $request, $id)
    {
        // Get the current cart from session
        $cart = session('cart', []);

        // If the product exists in the cart
        if (isset($cart[$id])) {
            // Update the quantity
            $cart[$id]['quantity'] = $request->quantity;

            // Store the updated cart in session
            session(['cart' => $cart]);
        }

        return redirect()->route('user.index')->with('success', 'Cart updated successfully.');
    }

    /**
     * Remove product from the cart.
     */
    public function removeFromCart($id)
    {
        // Get the current cart from session
        $cart = session('cart', []);

        // If the product exists in the cart, remove it
        if (isset($cart[$id])) {
            unset($cart[$id]);
            session(['cart' => $cart]);
        }

        return redirect()->route('user.index')->with('success', 'Product removed from cart.');
    }
    

    public function deleteAccount(Request $request)
    {
        $user = Auth::user();

        // Set the deletion time to 24 hours from now, if not already set
        if (!$user->deleted_at) {
            $user->deleted_at = Carbon::now('Asia/Kolkata')->addDay(); // 24 hours from now
            $user->save();
        }

        // Send the deletion notice email immediately
        try {
            Mail::to($user->email)->send(new AccountDeletionNotice($user));
        } catch (\Exception $e) {
            // If email fails, log the error
            Log::error('Email sending failed: ' . $e->getMessage());
        }

        // Dispatch the job to delete the account after 24 hours
        DeleteUserAccount::dispatch($user);

        // Log the user out
        Auth::logout();

        // Redirect to a confirmation page with a success message
        return redirect()->route('login')->with('success', 'Your account will be deleted in 24 hours. You have been logged out.');
    }

    public function showProfile()
    {
        // Return profile view with user data
        return view('user.show', ['user' => auth()->user()]);
    }

    public function showOrders()
    {
        // Assuming the user has orders related to them
        $orders = Order::where('user_id', auth()->id())->get();
        return view('user.myorder', compact('orders'));
    }
    public function showOrderDetails($orderId)
    {
        // dd('dfgdf');
        $order = Order::with('order_items.product')->findOrFail($orderId);
        return view('user.myorder-details', compact('order'));
    }
    public function showWishlist()
    {
        // Assuming the user has a wishlist
        $wishlist = Wishlist::where('user_id', auth()->id())->get();
        return view('user.wishlist', compact('wishlist'));
    }

    public function showSupport()
    {
        return view('user.support'); // Your Blade view for the support page
    }

    // Method to handle the support form submission
    public function storeSupport(Request $request)
    {
        // Validate the incoming message
        $request->validate([
            'message' => 'required|string|max:1000',
        ]);

        // Store the support request in the database
        SupportRequest::create([
            'user_id' => auth()->id(), // Get the logged-in user's ID
            'message' => $request->input('message'),
            'status' => 'pending', // Default status
        ]);

        // Redirect the user back with a success message
        return redirect()->route('user.support')->with('success', 'Your support request has been sent!');
    }
    public function showFAQ()
    {
        return view('user.faq');
    }
}
