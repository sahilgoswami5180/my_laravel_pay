<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DeletedProductController extends Controller
{
    /**
     * Show the list of deleted products.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Ensure the user is authenticated
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'You must be logged in to view deleted products.');
        }

        // Get all soft-deleted products
        $deletedProducts = Product::onlyTrashed()->get();

        return view('products.deleted', compact('deletedProducts'));
    }

    /**
     * Restore the specified soft-deleted product.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function restore($id)
    {
        // Ensure the user is authenticated
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'You must be logged in to restore products.');
        }

        // Find the soft-deleted product by its ID
        $product = Product::withTrashed()->findOrFail($id);

        // Restore the product
        $product->restore();

        // Redirect back with success message
        return redirect()->route('deleted-products.index')->with('success', 'Product restored successfully!');
    }

    /**
     * Force delete a product permanently.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function forceDelete($id)
    {
        // Ensure the user is authenticated
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'You must be logged in to permanently delete products.');
        }

        // Find the soft-deleted product by its ID
        $product = Product::onlyTrashed()->findOrFail($id);

        // Force delete the product permanently
        $product->forceDelete();

        // Redirect back with success message
        return redirect()->route('deleted-products.index')->with('success', 'Product permanently deleted.');
    }
}
