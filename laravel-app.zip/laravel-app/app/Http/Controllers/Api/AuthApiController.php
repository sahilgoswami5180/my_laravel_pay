<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Mail\EmailVerificationMail;
use App\Mail\OtpVerificationMail;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Str;
use Twilio\Rest\Client;

class AuthApiController extends Controller
{
    // Handle registration and send OTP via both email and SMS
    public function register(Request $request)
    {
        // Validate the registration request with added rules
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'mobile' => 'required|string|max:15|unique:users,mobile_number|regex:/^(\+?[1-9]\d{1,14})$/', // Validates international phone numbers
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
        ]);

        // Hash the password
        $validated['password'] = Hash::make($validated['password']);
        $validated['role'] = 'user';

        // Store mobile number (make sure to store full phone number with country code)
        $validated['mobile_number'] = $validated['mobile']; // Store full phone number

        // Create the user
        $user = User::create($validated);

        // Generate OTP (6-digit random number)
        $otp = rand(100000, 999999);

        // Store the OTP in the database
        $user->otp = $otp;

        // Generate email verification token
        $emailVerificationToken = Str::random(32);  // Generate a unique 32 character token
        $user->email_verification_token = $emailVerificationToken;
        $user->save();

        // Store OTP in the session for later validation
        session(['otp' => $otp, 'otp_email' => $user->email, 'otp_sent_at' => Carbon::now()]);

        // Send OTP to user's email
        Mail::to($user->email)->send(new OtpVerificationMail($otp));

        // Send OTP via SMS using Twilio
        $this->sendOtpSms($user->mobile_number, $otp);

        // Send email verification link
        $this->sendVerificationEmail($user, $emailVerificationToken);

        return response()->json([
            'status' => 'success',
            'message' => 'Registration successful! Please check your email and phone for the OTP to verify your account.',
        ]);
    }

    // Send OTP via Twilio SMS
    private function sendOtpSms($phoneNumber, $otp)
    {
        // Get Twilio credentials from the environment file
        $sid = env('TWILIO_SID');
        $token = env('TWILIO_AUTH_TOKEN');
        $twilioNumber = env('TWILIO_PHONE_NUMBER');

        // Create a Twilio client
        $client = new Client($sid, $token);

        try {
            // Send SMS using Twilio API
            $client->messages->create(
                $phoneNumber, // The phone number to send the OTP to
                [
                    'from' => $twilioNumber, // Your Twilio phone number
                    'body' => "Your OTP is: $otp" // The OTP message
                ]
            );
            Log::info("OTP sent successfully to $phoneNumber");
        } catch (\Exception $e) {
            // Handle Twilio exceptions (e.g., invalid phone number)
            Log::error('Twilio SMS Error: ' . $e->getMessage());
        }
    }

    // Send the email verification email with the token
    private function sendVerificationEmail($user, $token)
    {
        // Generate the verification URL with the token
        $verificationUrl = route('auth.verify-email', ['token' => $token]);

        // Send the verification email
        Mail::to($user->email)->send(new EmailVerificationMail($user, $verificationUrl));
    }

    // Verify email address
    public function verifyEmail($token)
    {
        $user = User::where('email_verification_token', $token)->first();

        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid or expired verification token.',
            ], 400);
        }

        // Mark the email as verified
        $user->email_verified_at = Carbon::now();
        $user->email_verification_token = null;
        $user->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Your email has been successfully verified!',
        ]);
    }

    // Handle login
    public function login(Request $request)
    {
        // Validate the incoming request data
        $validated = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8|max:13',
        ]);

        // Attempt login with provided credentials
        if (Auth::attempt(['email' => $validated['email'], 'password' => $validated['password']], $request->filled('remember'))) {
            $request->session()->regenerate();

            // Get the authenticated user
            $user = Auth::user();

            // Check if email is verified
            if ($user->email_verified_at === null) {
                // If email is not verified, log out the user and send an error message
                Auth::logout();
                return response()->json([
                    'status' => 'error',
                    'message' => 'Your email is not verified. Please check your inbox and verify your email.',
                ], 400);
            }

            // Check if OTP is verified
            if ($user->otp_verified_at === null) {
                // If OTP is not verified, redirect to OTP verification page
                return response()->json([
                    'status' => 'error',
                    'message' => 'Please verify your mobile number by entering the OTP sent to your phone.',
                ], 400);
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Login successful!',
                'user' => $user,
            ]);
        }

        return response()->json([
            'status' => 'error',
            'message' => 'Invalid email or password.',
        ], 401);
    }

    // Handle logout
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->json([
            'status' => 'success',
            'message' => 'You have been logged out successfully.',
        ]);
    }

    // Show the OTP verification form
    public function showOtpVerifyForm()
    {
        return response()->json([
            'status' => 'success',
            'message' => 'OTP verification form shown.',
        ]);
    }

    // Verify OTP
    public function verifyOtp(Request $request)
    {
        $validated = $request->validate([
            'otp' => 'required|digits:6', // Ensures exactly 6 digits
        ]);

        $sessionOtp = session('otp');
        $otp = $validated['otp'];

        if (!$sessionOtp || $sessionOtp != $otp) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid OTP. Please try again.',
            ], 400);
        }

        $user = User::where('email', session('otp_email'))->first();

        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'User not found.',
            ], 404);
        }

        // Mark the phone number as verified
        $user->otp_verified_at = Carbon::now();
        $user->save();

        session()->forget(['otp', 'otp_email', 'otp_sent_at']);

        return response()->json([
            'status' => 'success',
            'message' => 'Your phone number has been successfully verified!',
        ]);
    }

    // Resend OTP
    public function resendOtp(Request $request)
    {
        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'User not found.',
            ], 404);
        }

        $lastOtpSent = session('otp_sent_at');
        if ($lastOtpSent && Carbon::now()->diffInSeconds($lastOtpSent) < 30) {
            return response()->json([
                'status' => 'error',
                'message' => 'You can resend the OTP after 30 seconds.',
            ], 400);
        }

        $otp = rand(100000, 999999);
        $user->otp = $otp;
        $user->save();

        session(['otp' => $otp, 'otp_email' => $user->email, 'otp_sent_at' => Carbon::now()]);

        Mail::to($user->email)->send(new OtpVerificationMail($otp));

        return response()->json([
            'status' => 'success',
            'message' => 'Verification OTP has been sent again.',
        ]);
    }

    // Check if user exists
    public function checkUserExistence(Request $request)
    {
        $email = $request->query('email');
        $user = User::where('email', $email)->first();

        return response()->json([
            'exists' => $user ? true : false
        ]);
    }
}
