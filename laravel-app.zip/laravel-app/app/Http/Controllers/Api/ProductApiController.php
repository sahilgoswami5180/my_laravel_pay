<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Subcategory;
use Dompdf\Dompdf;
use Dompdf\Options;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\QrCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ProductApiController extends Controller
{
    /**
     * Display a listing of the products.
     */
    public function index(Request $request)
    {
        // Start with the base query to get products, including soft-deleted ones
        $query = Product::with(['category', 'subcategory'])->withoutTrashed();

        // Apply filters for search, category, and subcategory
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->filled('subcategory_id')) {
            $query->where('subcategory_id', $request->subcategory_id);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Get paginated results
        $products = $query->paginate(10);

        return response()->json($products);
    }

    /**
     * Store a newly created product in storage.
     */
    public function store(Request $request)
    {
        // Handle the image upload if an image is provided
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('products', 'public');
        }

        // Create the product with the validated data
        $product = Product::create([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'price' => $request->input('price'),
            'category_id' => $request->input('category_id'),
            'subcategory_id' => $request->input('subcategory_id'),
            'image' => isset($imagePath) ? $imagePath : null, // Add image if it exists
            'status' => $request->input('status'),
        ]);

        return response()->json([
            'message' => 'Product created successfully!',
            'product' => $product
        ], 201);
    }


    /**
     * Display the specified product.
     */
    public function show(Product $product)
    {
        // Load related category and subcategory
        $product->load(['category', 'subcategory']);

        return response()->json($product);
    }

    /**
     * Update the specified product in storage.
     */
    public function update(Request $request, Product $product)
    {
        // Handle the image upload if an image is provided
        if ($request->hasFile('image')) {
            // Delete old image if it exists
            if ($product->image && Storage::exists('public/' . $product->image)) {
                Storage::delete('public/' . $product->image);
            }

            // Store new image and add it to the request data
            $imagePath = $request->file('image')->store('product_images', 'public');
            $request->merge(['image' => $imagePath]); // Merge the image path to the request data
        }

        // Update the product with the request data (only the necessary fields)
        $productUpdated = $product->update($request->only(['name', 'description', 'price', 'category_id', 'subcategory_id', 'status', 'image']));

        // Check if update was successful
        if ($productUpdated) {
            return response()->json([
                'message' => 'Product updated successfully!',
                'product' => $product
            ]);
        } else {
            return response()->json([
                'message' => 'Failed to update product.'
            ], 500); // Return error message with a 500 status if update fails
        }
    }


    /**
     * Soft delete the product.
     */
    public function destroy(Product $product)
    {
        // Soft delete the product
        $product->delete();

        return response()->json([
            'message' => 'Product deleted successfully!'
        ]);
    }

    /**
     * Restore a soft-deleted product.
     */
    public function restore($id)
    {
        // Find the product including soft-deleted ones
        $product = Product::withTrashed()->findOrFail($id);

        // Restore the product
        $product->restore();

        return response()->json([
            'message' => 'Product restored successfully!',
            'product' => $product
        ]);
    }

    /**
     * Update product status (active/inactive).
     */
    public function updateStatus(Product $product)
    {
        // Toggle the product status between active and inactive
        $product->status = $product->status === 'active' ? 'inactive' : 'active';
        $product->save();

        return response()->json([
            'message' => 'Product status updated successfully!',
            'status' => $product->status
        ]);
    }
    public function generateProductQrCode($productId)
    {
        // Fetch the product using the product ID
        $product = Product::findOrFail($productId);

        // Format the product data into a string
        $productData = sprintf(
            "Product Name: %s\nDescription: %s\nPrice: $%0.2f\nStatus: %s\nCategory: %s",
            $product->name,
            $product->description,
            $product->price,
            ucfirst($product->status), // Capitalizing the status
            $product->category->name
        );

        // Generate QR Code
        $qrCode = new QrCode($productData);
        $qrCode->setSize(300); // Set the size of the QR Code
        $qrCode->setEncoding('UTF-8');
        $qrCode->setErrorCorrectionLevel(ErrorCorrectionLevel::HIGH); // Set error correction level to high

        // Return the QR code as a PNG image
        return response($qrCode->writeString(), 200)
            ->header('Content-Type', 'image/png');
    }

    public function exportToCsv()
    {
        // Optional: Check if the user is authenticated (if needed for your use case)
        // if (!Auth::check()) {
        //     return response()->json(['error' => 'Unauthorized'], 401);
        // }

        // Set the filename with a timestamp
        $fileName = 'trashed_products_' . date('Ymd_His') . '.csv';

        // Headers to define the CSV file content type
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$fileName\"",
        ];

        // Callback function to stream the CSV content
        $callback = function () {
            $fileHandle = fopen('php://output', 'w');

            // Add the CSV header row
            fputcsv($fileHandle, [
                'ID',
                'Name',
                'Description',
                'Price',
                'Category',
                'Status',
                'Created At',
                'Updated At',
                'Deleted At'
            ]);

            // Fetch soft-deleted products with their associated category
            $trashedProducts = Product::withTrashed()->with('category')->get();

            // Loop through the trashed products and add them to the CSV
            foreach ($trashedProducts as $product) {
                $deletedAt = $product->deleted_at ? $product->deleted_at->format('M j, Y, g:i a') : 'Not Deleted';

                // Write product data to CSV
                fputcsv($fileHandle, [
                    $product->id,
                    $product->name,
                    $product->description,
                    $product->price,
                    $product->category->name ?? 'N/A',
                    ucfirst($product->status), // Capitalize the status (e.g., "active" becomes "Active")
                    $product->created_at->format('M j, Y, g:i a'),
                    $product->updated_at->format('M j, Y, g:i a'),
                    $deletedAt,  // Format deleted_at or show 'N/A'
                ]);
            }

            // Close the file handle after writing the data
            fclose($fileHandle);
        };

        // Return the CSV file as a streamed response
        return new StreamedResponse($callback, 200, $headers);
    }

    public function exportToPdf()
    {
        // Optional: Check if the user is authenticated (if needed for your use case)
        // if (!Auth::check()) {
        //     return response()->json(['error' => 'Unauthorized'], 401);
        // }

        // Fetch all products data, including those that are soft-deleted
        $products = Product::with('category')->get();

        // Separate products into non-deleted and soft-deleted
        $nonDeletedProducts = $products->whereNull('deleted_at');
        $deletedProducts = Product::onlyTrashed()->with('category')->get();

        // Prepare the data for rendering in the PDF view
        $html = view('products.pdf', compact('nonDeletedProducts', 'deletedProducts'))->render();

        // Configure Dompdf options
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);  // Enable HTML5 parsing for better rendering
        $options->set('isPhpEnabled', true);          // Allow PHP function calls in PDF rendering (for URLs, etc.)
        $options->set('isRemoteEnabled', true);       // Allow loading remote images (if you are using external image URLs)

        // Initialize Dompdf with the options
        $dompdf = new Dompdf($options);
        $dompdf->loadHtml($html);  // Load the HTML content for PDF
        $dompdf->setPaper('A4', 'landscape');  // Set paper size and orientation (A4 landscape)
        $dompdf->render();  // Render the PDF

        // Stream the generated PDF as a downloadable file
        return $dompdf->stream('products_' . date('Ymd_His') . '.pdf', [
            'Attachment' => true,  // Set to 'true' for download, 'false' for inline display
        ]);
    }
    public function card(Request $request)
    {
        // Get the page number from the query parameters (default is 1)
        $page = $request->input('page', 1);

        // Fetch products with pagination (8 products per page)
        $products = Product::paginate(8, ['*'], 'page', $page);

        // Return paginated products as a JSON response
        return response()->json([
            'data' => $products->items(),
            'current_page' => $products->currentPage(),
            'total_pages' => $products->lastPage(),
            'total_items' => $products->total(),
            'per_page' => $products->perPage(),
        ]);
    }
    /**
     * Get subcategories of a category.
     */
    public function getSubcategories($categoryId)
    {
        // Fetch subcategories based on category ID
        $subcategories = Subcategory::where('category_id', $categoryId)->get();

        return response()->json($subcategories);
    }
}
