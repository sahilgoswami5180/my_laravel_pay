<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\DeleteUserAccount;
use App\Mail\AccountDeletionNotice;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\SupportRequest;
use App\Models\Wishlist;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class ApiUserController extends Controller
{
    /**
     * Show the user dashboard or main user page with filtered products.
     */
    public function index(Request $request)
    {
        $categories = Category::all();
        $query = Product::query();

        $products = Product::where('status', 'active');

        if ($request->has('category_id')) {
            $products = $products->where('category_id', $request->category_id);
        }

        if ($request->has('search') && $request->search != '') {
            $products = $products->where('name', 'like', '%' . $request->search . '%');
        }

        if ($request->has('category_id') && $request->category_id) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('price_range') && $request->price_range) {
            $query->where('price', '<=', $request->price_range);
        }

        $filteredProducts = $query->get();
        $products = $products->get();

        return response()->json([
            'products' => $products,
            'categories' => $categories,
            'filteredProducts' => $filteredProducts,
        ]);
    }

    /**
     * Show products for a specific category.
     */
    public function categorywiseshow($categoryId)
    {
        $category = Category::findOrFail($categoryId);
        $products = Product::where('category_id', $categoryId)->where('status', 'active')->paginate(10);

        if ($products->isEmpty()) {
            return response()->json(['error' => 'No products found for this category.'], 404);
        }

        return response()->json([
            'category' => $category,
            'products' => $products,
        ]);
    }

    /**
     * Show product details.
     */
    public function show($id)
    {
        $product = Product::with('category')->findOrFail($id);
        return response()->json($product);
    }

    /**
     * Add product to the cart.
     */
    public function addToCart(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $cart = session('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                'name' => $product->name,
                'price' => $product->price,
                'quantity' => 1,
                'image' => $product->image
            ];
        }

        session(['cart' => $cart]);

        return response()->json([
            'message' => 'Product added to cart.',
            'cart' => $cart
        ]);
    }

    /**
     * Update product quantity in the cart.
     */
    public function updateQuantity(Request $request, $id)
    {
        $cart = session('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity'] = $request->quantity;
            session(['cart' => $cart]);
        }

        return response()->json([
            'message' => 'Cart updated successfully.',
            'cart' => $cart
        ]);
    }

    /**
     * Remove product from the cart.
     */
    public function removeFromCart($id)
    {
        $cart = session('cart', []);

        if (isset($cart[$id])) {
            unset($cart[$id]);
            session(['cart' => $cart]);
        }

        return response()->json([
            'message' => 'Product removed from cart.',
            'cart' => $cart
        ]);
    }

    /**
     * Delete user account with a 24-hour delay.
     */
    public function deleteAccount(Request $request)
    {
        $user = Auth::user();

        if (!$user->deleted_at) {
            $user->deleted_at = Carbon::now('Asia/Kolkata')->addDay();
            $user->save();
        }

        try {
            Mail::to($user->email)->send(new AccountDeletionNotice($user));
        } catch (\Exception $e) {
            Log::error('Email sending failed: ' . $e->getMessage());
        }

        DeleteUserAccount::dispatch($user);
        Auth::logout();

        return response()->json([
            'message' => 'Your account will be deleted in 24 hours. You have been logged out.',
        ]);
    }

    /**
     * Show user profile.
     */
    public function showProfile()
    {
        return response()->json(auth()->user());
    }

    /**
     * Show user orders.
     */
    public function showOrders()
    {
        $orders = Order::where('user_id', auth()->id())->get();
        return response()->json($orders);
    }

    /**
     * Show details of a specific order.
     */
    public function showOrderDetails($orderId)
    {
        $order = Order::with('order_items.product')->findOrFail($orderId);
        return response()->json($order);
    }

    /**
     * Show user wishlist.
     */
    public function showWishlist()
    {
        $wishlist = Wishlist::where('user_id', auth()->id())->get();
        return response()->json($wishlist);
    }

    /**
     * Show support page.
     */
    public function showSupport()
    {
        return response()->json(['message' => 'Support page']);
    }

    /**
     * Handle support request submission.
     */
    public function storeSupport(Request $request)
    {
        $request->validate([
            'message' => 'required|string|max:1000',
        ]);

        SupportRequest::create([
            'user_id' => auth()->id(),
            'message' => $request->input('message'),
            'status' => 'pending',
        ]);

        return response()->json([
            'message' => 'Your support request has been sent!',
        ]);
    }

    /**
     * Show FAQ page.
     */
    public function showFAQ()
    {
        return response()->json(['message' => 'FAQ page']);
    }
}
