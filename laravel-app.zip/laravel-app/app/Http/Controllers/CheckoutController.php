<?php

namespace App\Http\Controllers;

use App\Mail\OrderPlaced;
use App\Mail\PaymentSuccess;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Stripe\Stripe;
use Stripe\Checkout\Session;
use Stripe\Exception\ApiErrorException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;  // Make sure to include this
use paytm\paytmchecksum\PaytmChecksum;
use Razorpay\Api\Api;

class CheckoutController extends Controller
{
    /**
     * Show the checkout page with cart items.
     */
    public function index()
    {
        // Fetch the user's cart items
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Calculate total price
        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });

        // Get unique categories of products in the cart
        $categories = $cartItems->map(function ($item) {
            return $item->product->category_id; // Assuming you have a `category_id` field in the `products` table
        })->unique();

        // Query recommended products based on the categories in the cart
        // Exclude products already in the cart
        $recommendedProducts = Product::whereIn('category_id', $categories)
            ->whereNotIn('id', $cartItems->pluck('product_id'))
            ->limit(8) // Limit to 8 recommended products
            ->get();

        // Pass data to the view
        return view('user.checkout', compact('cartItems', 'total', 'recommendedProducts'));
    }

    /**
     * Handle Cash on Delivery checkout.
     */
    public function codCheckout(Request $request)
    {

        $validated = $request->validate([
            'address' => 'required|string|max:500',
        ]);
        // Fetch the user's cart items
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Calculate total price
        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });

        // Create an order with status 'cash on delivery'
        $order = Order::create([
            'user_id' => Auth::id(),
            'total' => $total,
            'address' => $validated['address'],
            'status' => 'cash on delivery', // Set the status to COD
            'product_id' => $cartItems->first()->product->id, // Store the first product's ID
        ]);

        // Collect data for the comma-separated format
        $productNames = [];
        $productImages = [];
        $quantities = [];
        $prices = [];

        foreach ($cartItems as $item) {
            $productNames[] = $item->product->name;
            $productImages[] = $item->product->image;
            $quantities[] = $item->quantity;
            $prices[] = $item->product->price;
        }

        // Save comma-separated values in the order
        $order->order_items = implode(",", $productNames);  // Store the comma-separated product names
        $order->order_images = implode(",", $productImages);  // Store the comma-separated product images
        $order->order_quantities = implode(",", $quantities);  // Store the comma-separated quantities
        $order->order_prices = implode(",", $prices);  // Store the comma-separated prices

        // Save the order with the comma-separated details
        $order->save();

        // Clear the user's cart after placing the order
        CartItem::where('user_id', Auth::id())->delete();

        // Reset the auto-increment value of the cart_items table
        DB::statement('ALTER TABLE cart_items AUTO_INCREMENT = 1;');

        // Send an email to the user after the order is placed
        Mail::to(Auth::user()->email)->send(new OrderPlaced($order));

        // Return a success view or redirect to a confirmation page
        return redirect()->route('checkout.success')->with('order', $order);
    }

    /**
     * Process payment with Stripe.
     */
    public function process(Request $request)
    {
        $validated = $request->validate([
            'address' => 'required|string|max:500',
        ]);
        
        // Fetch the user's cart items
        $cartItems = CartItem::where('user_id', Auth::id())->get();
        
        // Calculate total price
        $total = $cartItems->sum(function ($item) {
            return $item->product->price * $item->quantity;
        });
        
        $paymentMethod = $request->input('payment_method');
        
        // Handle Paytm payment
        if ($paymentMethod == 'paytm') {
            $paytmParams = [
                "MID" => env('PAYTM_MID'),
                "WEBSITE" => env('PAYTM_WEBSITE'),
                "CHANNEL_ID" => "WEB",
                "INDUSTRY_TYPE_ID" => "Retail",
                "ORDER_ID" => 'ORD' . uniqid(),
                "CUST_ID" => Auth::id(),
                "MOBILE_NO" => Auth::user()->mobile_number,
                "EMAIL" => Auth::user()->email,
                "TXN_AMOUNT" => $total,
                "CALLBACK_URL" => route('checkout.paytm.callback'),
            ];
    
            // Generate checksum hash
            $paytmParams["CHECKSUMHASH"] = PaytmChecksum::generateSignature($paytmParams, env('PAYTM_MERCHANT_KEY'));
    
            // Create the order record in the database
            $order = Order::create([
                'user_id' => Auth::id(),
                'total' => $total,
                'address' => $validated['address'],
                'status' => 'pending', // Initially set the order as pending
                'payment_method' => 'paytm',
                'product_id' => $cartItems->first()->product->id, // Store the first product's ID
            ]);
    
            // Collect data for the comma-separated format
            $productNames = [];
            foreach ($cartItems as $item) {
                $productNames[] = $item->product->name;
            }
            $order->order_items = implode(",", $productNames);
            $order->save();
            
            // Send the Paytm params to the view (for the user to submit the form)
            return view('user.paytm', compact('paytmParams'));
        }
    
        // Add existing payment methods logic (Stripe, COD, Razorpay, PayPal, etc.)
    }
    

    public function razorpaySuccess(Request $request)
    {
        // Validate the Razorpay response
        $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));

        $paymentId = $request->razorpay_payment_id;
        $orderId = $request->razorpay_order_id;
        $signature = $request->razorpay_signature;

        // Validate payment signature using Razorpay's verifyPaymentSignature
        $attributes = [
            'razorpay_order_id' => $orderId,
            'razorpay_payment_id' => $paymentId,
            'razorpay_signature' => $signature
        ];

        try {
            $api->utility->verifyPaymentSignature($attributes);

            // Fetch the order and update the status to 'paid'
            $order = Order::where('user_id', Auth::id())
                ->where('status', 'pending')
                ->latest()
                ->first();

            if ($order) {
                $order->update([
                    'status' => 'paid',
                    'payment_method' => 'razorpay',
                ]);

                // Send order confirmation email
                Mail::to(Auth::user()->email)->send(new PaymentSuccess($order));

                // Clear the user's cart after successful payment
                CartItem::where('user_id', Auth::id())->delete();

                return response()->json([
                    'success' => true,
                    'redirect_url' => route('checkout.success')
                ]);
            }
        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Payment failed. Please try again.']);
        }
    }

    public function paypalSuccess(Request $request)
{
    $paymentId = $request->paymentId;
    $payerId = $request->PayerID;
    $orderId = $request->orderId;

    $clientId = env('PAYPAL_CLIENT_ID');
    $clientSecret = env('PAYPAL_CLIENT_SECRET');
    $environment = new SandboxEnvironment($clientId, $clientSecret);
    $client = new PayPalHttpClient($environment);

    // Execute payment (capture)
    $captureRequest = new OrdersCaptureRequest($paymentId);
    $captureRequest->body = [];
    
    try {
        $response = $client->execute($captureRequest);
        
        // Update order status to 'paid'
        $order = Order::where('user_id', Auth::id())->where('status', 'pending')->latest()->first();
        
        if ($order) {
            $order->update([
                'status' => 'paid',
                'payment_method' => 'paypal',
            ]);

            // Send order confirmation email
            Mail::to(Auth::user()->email)->send(new PaymentSuccess($order));

            // Clear the cart after successful payment
            CartItem::where('user_id', Auth::id())->delete();

            return redirect()->route('checkout.success');
        }
    } catch (\Exception $e) {
        return back()->withErrors(['error' => 'PayPal payment capture failed.']);
    }
}

public function paytmCallback(Request $request)
{
    $paytmParams = $request->all();

    // Verify Paytm checksum
    $checksumVerified = PaytmChecksum::verifySignature($paytmParams, env('PAYTM_MERCHANT_KEY'), $paytmParams['CHECKSUMHASH']);
    
    if ($checksumVerified) {
        // Check the response from Paytm
        if ($paytmParams['STATUS'] == 'TXN_SUCCESS') {
            // Update the order status
            $order = Order::where('user_id', Auth::id())
                ->where('status', 'pending')
                ->latest()
                ->first();

            if ($order) {
                $order->update([
                    'status' => 'paid',
                    'payment_method' => 'paytm',
                ]);

                // Send success emails
                Mail::to(Auth::user()->email)->send(new PaymentSuccess($order));

                // Clear the user's cart after successful payment
                CartItem::where('user_id', Auth::id())->delete();

                return redirect()->route('checkout.success');
            }
        } else {
            // Payment failed, update order status
            $order->update(['status' => 'failed']);

            return redirect()->route('checkout.cancel');
        }
    } else {
        return back()->withErrors(['error' => 'Invalid checksum']);
    }
}

public function paypalCancel()
{
    return back()->withErrors(['error' => 'Payment cancelled.']);
}

    /**
     * Handle successful payment.
     */
    public function success(Request $request)
    {
        // Determine if it's a COD order or a paid Stripe order
        $order = Order::where('user_id', Auth::id())
            ->whereIn('status', ['pending', 'cash on delivery'])  // Check for both COD and pending orders
            ->latest()
            ->first();  // Get the most recent order

        if ($order) {
            // If the order is still in the 'pending' state, update to 'paid'
            if ($order->status == 'pending') {
                $order->update([
                    'status' => 'paid',
                ]);
            }

            // Send the order placed confirmation email
            Mail::to(Auth::user()->email)->send(new OrderPlaced($order));

            // Send payment success email (if payment was successful)
            Mail::to(Auth::user()->email)->send(new PaymentSuccess($order));

            // Clear the user's cart after successful payment
            CartItem::where('user_id', Auth::id())->delete();

            // Reset the auto-increment value of the cart_items table
            DB::statement('ALTER TABLE cart_items AUTO_INCREMENT = 1;');

            // Return success view
            return view('user.paysuccess', compact('order'));
        }

        // If order not found, redirect to some error page
        return redirect()->route('user.paysuccess');
    }

   /**
     * Handle canceled payment.
     */
    public function cancel()
    {
        $order = Order::where('user_id', Auth::id())
            ->where('status', 'pending')
            ->latest()
            ->first();

        if ($order) {
            $order->update(['status' => 'cancelled']);
        }

        return view('user.cancel', compact('order'));
    }
}
