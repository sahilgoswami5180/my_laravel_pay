<?php

namespace App\Http\Controllers;

use App\Models\ContactUs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;
use App\Notifications\NewContactUsNotification;

class ContactUsController extends Controller
{
    // Show the contact form
    public function create()
    {
        return view('user.contact-us');
    }

    // Handle the form submission
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string',
        ]);

        // Save the contact submission
        $contactUs = ContactUs::create([
            'name' => $request->name,
            'email' => $request->email,
            'message' => $request->message,
        ]);

        // Notify the admin
        Notification::route('mail', 'admin@example.com')
            ->notify(new NewContactUsNotification($contactUs));

        return redirect()->back()->with('success', 'Your message has been sent!');
    }

    // Mark the contact submission as read
    public function markAsRead($id)
    {
        $contactUs = ContactUs::findOrFail($id);
        $contactUs->update(['read' => true]);

        return back()->with('success', 'Notification marked as read.');
    }

    // Delete selected contact submissions
    public function deleteSelected(Request $request)
    {
        $request->validate([
            'ids' => 'required|array', // Ensure 'ids' is an array
            'ids.*' => 'exists:contact_us,id', // Ensure each id exists in the database
        ]);

        // Delete the selected messages
        ContactUs::whereIn('id', $request->ids)->delete();

        // Return a success response
        return response()->json(['message' => 'Selected messages deleted successfully.']);
    }
}
