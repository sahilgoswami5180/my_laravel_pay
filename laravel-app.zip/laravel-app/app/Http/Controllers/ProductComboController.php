<?php

namespace App\Http\Controllers;

use App\Models\ProductCombo;
use App\Models\Product;
use App\Models\Category;
use App\Models\Subcategory;
use Illuminate\Http\Request;

class ProductComboController extends Controller
{
    // Display all product combos
    public function index()
    {
        // Fetch all combos including soft deleted ones if needed
        $combos = ProductCombo::with('products')->get();
        return view('product_combos.index', compact('combos'));
    }

    // Show form to create a new product combo
    public function create()
    {
        $products = Product::all();
        $categories = Category::all();
        $subcategories = Subcategory::all();
        return view('product_combos.create', compact('products', 'categories', 'subcategories'));
    }

    // Store a new product combo
    public function store(Request $request)
    {
        // Validate input
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'total_price' => 'required|numeric',
            'disc_price' => 'required|numeric',
            'category_id' => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:subcategories,id',
            'products' => 'required|array|min:2|max:6',
        ]);

        // Create the product combo
        $combo = ProductCombo::create($request->except('products'));
        // Attach selected products to the combo
        $combo->products()->attach($request->products);

        return redirect()->route('product_combos.index')->with('success', 'Product Combo Created Successfully');
    }

    // Edit a product combo
    public function edit($id)
    {
        $combo = ProductCombo::with('products')->findOrFail($id);
        $products = Product::all();
        $categories = Category::all();
        $subcategories = Subcategory::where('category_id', $combo->category_id)->get();
        return view('product_combos.edit', compact('combo', 'products', 'categories', 'subcategories'));
    }
    public function update(Request $request, $id)
    {
        // dd($request);
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'total_price' => 'required|numeric',
            'disc_price' => 'required|numeric',
            'category_id' => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:subcategories,id',
            'products' => 'required|array|min:2|max:6',
        ]);

        $combo = ProductCombo::findOrFail($id);
        $combo->update($request->except('products'));

        $combo->products()->sync($request->products);

        return redirect()->route('product_combos.index')->with('success', 'Product Combo Updated Successfully');
    }
    // Soft delete a product combo
    public function softDelete(ProductCombo $productCombo)
    {
        // Perform soft delete by setting the deleted_at column
        $productCombo->delete();

        // Optionally, you can add a flash message for user feedback
        return redirect()->route('product_combos.index')->with('success', 'Product Combo soft-deleted successfully.');
    }
    // Restore a soft-deleted product combo
    public function restore($id)
    {
        $combo = ProductCombo::withTrashed()->findOrFail($id);
        $combo->restore();  // This will restore the product combo

        return redirect()->route('product_combos.index')->with('success', 'Product Combo Restored Successfully');
    }
    // Permanently delete a product combo
    public function destroy($id)
    {
        $combo = ProductCombo::findOrFail($id);
        $combo->forceDelete();  // This will permanently delete the product combo

        return redirect()->route('product_combos.index')->with('success', 'Product Combo Deleted Successfully');
    }
}
