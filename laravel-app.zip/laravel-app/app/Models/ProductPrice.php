<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductPrice extends Model
{
    // Define the table name (if different from the pluralized version of the model name)
    protected $table = 'product_prices';

    // Define the fillable fields to allow mass assignment
    protected $fillable = [
        'product_id',
        'price',
        'serving_size',
    ];

    /**
     * Relationship: A ProductPrice belongs to a Product.
     */
    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}
