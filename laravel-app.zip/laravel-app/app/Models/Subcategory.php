<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Subcategory extends Model
{
    use HasFactory, SoftDeletes; // Enable SoftDeletes

    // Fillable fields for mass assignment
    protected $fillable = ['name', 'category_id', 'description', 'image'];

    // Relationship: A subcategory belongs to a category
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    // Relationship: A subcategory has many products
    public function products()
    {
        return $this->hasMany(Product::class);
    }

    /**
     * Get the name of the related category.
     *
     * @return string
     */
    public function getCategoryNameAttribute()
    {
        return $this->category ? $this->category->name : 'No category';
    }

    // Boot method to handle cascading soft-deletes and restorations
    protected static function boot()
    {
        parent::boot();

        // Automatically handle cascading deletes
        static::deleting(function ($subcategory) {
            if ($subcategory->isForceDeleting()) {
                // Hard delete related products when the subcategory is permanently deleted
                $subcategory->products()->forceDelete();
            } else {
                // Soft delete related products when the subcategory is soft deleted
                $subcategory->products()->delete();
            }
        });

        // Automatically handle cascading restores
        static::restoring(function ($subcategory) {
            // Restore related products when the subcategory is restored
            $subcategory->products()->withTrashed()->restore();
        });
    }
}
