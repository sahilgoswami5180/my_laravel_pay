<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes; // For soft delete functionality

class Product extends Model
{
    use HasFactory, SoftDeletes; // Add SoftDeletes to the model

    // Fillable fields for mass assignment
    protected $fillable = [
        'name',
        'description',
        'price',
        'category_id',
        'subcategory_id',  // Add 'subcategory_id' to fillable for mass assignment
        'image',
        'serving_size',
        'status', // Add 'status' to fillable
    ];

    // Define possible statuses for the product
    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';

    /**
     * Get the available statuses.
     *
     * @return array
     */
    public static function getStatuses()
    {
        return [
            self::STATUS_ACTIVE,
            self::STATUS_INACTIVE,
        ];
    }

    /**
     * Define the relationship between Product and Category.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function category()
    {
        return $this->belongsTo(Category::class); // A product belongs to a category
    }

    /**
     * Define the relationship between Product and Subcategory.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function subcategory()
    {
        return $this->belongsTo(Subcategory::class); // A product belongs to a subcategory
    }

    /**
     * Define the relationship between Product and OrderItem.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}
