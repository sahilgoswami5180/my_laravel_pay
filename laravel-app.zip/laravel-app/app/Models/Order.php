<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    // Define the table name (if it's different from the plural form of the model name)
    protected $table = 'orders';

    // Define the fillable fields (add 'product_id' to the fillable array)
    protected $fillable = [
        'user_id',
        'product_id', // Add product_id to fillable
        'total',
        'status',
        'address',
        'order_items',
        'order_images',
        'order_quantities',
        'order_prices',
    ];

    // Define relationships with other models, if necessary
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // In the Order model
    public function order_items()
    {
        return $this->hasMany(OrderItem::class); // foreign key: order_id
    }



    public function category()
    {
        return $this->belongsTo(Category::class); // Assuming an Order belongs to one Category
    }

    // Define the relationship with the Product model (assuming each order is related to a single product)
    public function product()
    {
        return $this->belongsTo(Product::class); // Assuming you have a Product model
    }

    // If you need the relationship with CartItem as well
    public function cartItems()
    {
        return $this->hasMany(CartItem::class);
    }
    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }
}
