<?php

namespace App\Notifications;

use App\Models\ContactUs;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class NewContactUsNotification extends Notification
{
    use Queueable;

    public $contactUs;

    public function __construct(ContactUs $contactUs)
    {
        $this->contactUs = $contactUs;
    }

    public function via($notifiable)
    {
        return ['mail']; // You can add other channels like database, etc.
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->line('You have a new contact form submission.')
            ->line('Name: ' . $this->contactUs->name)
            ->line('Message: ' . $this->contactUs->message)
            ->action('View Submission', url('/admin/dashboard'))
            ->line('Thank you for using our application!');
    }

    public function toArray($notifiable)
    {
        return [
            'contact_us_id' => $this->contactUs->id,
            'name' => $this->contactUs->name,
            'message' => $this->contactUs->message,
        ];
    }
}
