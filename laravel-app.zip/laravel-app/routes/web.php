<?php

use Laravel\Socialite\Facades\Socialite;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ChangePasswordController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\ContactUsController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DeletedCategoryController;
use App\Http\Controllers\DeletedProductController;
use App\Http\Controllers\DeletedSubcategoryController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\ProductComboController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SubcategoryController;
use App\Http\Controllers\UserController;
use App\Models\ContactUs;
use Illuminate\Support\Facades\Route;
use Barryvdh\DomPDF\Facade\Pdf;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

// Routes outside auth middleware
Route::get('/', [AuthController::class, 'showLoginForm'])->name('home'); // Home route
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');

// Registration routes
Route::get('register', [AuthController::class, 'showRegisterForm'])->name('register.form');
Route::post('register', [AuthController::class, 'register'])->name('register');
Route::get('/email/verify/{token}', [AuthController::class, 'verifyEmail'])->name('auth.verify-email');
Route::get('/check-user-existence', [AuthController::class, 'checkUserExistence']);

// Login and logout routes
Route::post('login', [AuthController::class, 'login'])->name('login');
Route::post('logout', [AuthController::class, 'logout'])->name('logout');
Route::get('login/google', [AuthController::class, 'redirectToGoogle']);
Route::get('login/google/callback', [AuthController::class, 'handleGoogleCallback']);
// Password reset routes
Route::get('forgot-password', [PasswordResetController::class, 'showForgotPasswordForm'])->name('forgot.password');
Route::post('forgot-password', [PasswordResetController::class, 'sendResetLink'])->name('password.email');
Route::get('password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
Route::post('password/reset', [PasswordResetController::class, 'reset'])->name('password.update');

// Routes inside auth middleware

// OTP Verification routes
Route::get('otp/verify', [AuthController::class, 'showOtpVerifyForm'])->name('auth.verify-otp');
Route::post('otp/verify', [AuthController::class, 'verifyOtp'])->name('otp.verify');
Route::post('otp/resend', [AuthController::class, 'resendOtp'])->name('otp.resend');

// Password reset routes
Route::get('password/reset', [AuthController::class, 'showResetPasswordForm'])->name('auth.reset-password.page');
Route::post('password/reset', [AuthController::class, 'resetPassword'])->name('auth.reset-password');

Route::middleware(['auth'])->group(function () {
    // Dashboard and user-related routes
    Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('index', [UserController::class, 'index'])->name('user.index');

    // Category routes
    Route::resource('categories', CategoryController::class);
    Route::get('/category/{category}', [CategoryController::class, 'view'])->name('categories.view');

    // Restore a deleted category
    Route::post('/categories/{id}/restore', [CategoryController::class, 'restore'])->name('categories.restore');
    // Permanently delete a category
    Route::delete('/categories/{id}/destroy', [CategoryController::class, 'destroy'])->name('categories.destroy');

    // Product routes
    Route::resource('products', ProductController::class);
    Route::post('products/{product}/change-status', [ProductController::class, 'updateStatus'])->name('products.change-status');
    Route::post('products/{product}/edit', [ProductController::class, 'update'])->name('products.edit');
    Route::delete('products/{product}/delete', [ProductController::class, 'destroy'])->name('products.delete');
    Route::post('categories/{category}/products/change-status1', [ProductController::class, 'updateStatus1'])->name('categories.products.change-status');

    // Deleted categories routes
    Route::get('deleted-categories', [DeletedCategoryController::class, 'index'])->name('deleted-categories.index');
    Route::post('deleted-categories/{id}/restore', [DeletedCategoryController::class, 'restore'])->name('deleted-categories.restore');
    Route::delete('deleted-categories/{id}/force-delete', [DeletedCategoryController::class, 'forceDelete'])->name('deleted-categories.force-delete');

    // Deleted products routes
    Route::get('deleted-products', [DeletedProductController::class, 'index'])->name('deleted-products.index');
    Route::post('deleted-products/{id}/restore', [DeletedProductController::class, 'restore'])->name('deleted-products.restore');
    Route::delete('deleted-products/{id}/force-delete', [DeletedProductController::class, 'forceDelete'])->name('deleted-products.force-delete');

    Route::get('orders', [UserController::class, 'showOrders'])->name('user.myorder');
    Route::get('/orders/{order}', [UserController::class, 'showOrderDetails'])->name('user.myorder-details');
    // Product card view and QR code
    Route::get('products/card', [ProductController::class, 'card'])->name('products.card-view');
    Route::get('product/{productId}/qr-code', [ProductController::class, 'generateProductQrCode'])->name('products.qr-code');
    Route::get('/products/export/pdf', [ProductController::class, 'exportToPdf'])->name('products.export.pdf');
    Route::get('/products/export/csv', [ProductController::class, 'exportToCsv'])->name('products.export.csv');
    Route::get('/get-subcategories/{categoryId}', [ProductController::class, 'getSubcategories']);

    // User account and cart routes
    Route::get('/account', [AccountController::class, 'index'])->name('account');

    // Cart Routes
    Route::get('/cart', [CartController::class, 'index'])->name('user.cart');  // View the cart
    Route::post('cart/add/{product}', [CartController::class, 'add'])->name('cart.add');
    Route::delete('/cart/{cartItem}', [CartController::class, 'remove'])->name('cart.remove');  // Remove item from cart
    Route::patch('/cart/{cartItem}', [CartController::class, 'updateQuantity'])->name('cart.updateQuantity');  // Update quantity in cart


    Route::get('/checkout', [CheckoutController::class, 'index'])->name('user.checkout');
    Route::post('/checkout', [CheckoutController::class, 'process'])->name('checkout.process');
    Route::get('/checkout/success', [CheckoutController::class, 'success'])->name('checkout.success');
    Route::get('/checkout/cancel', [CheckoutController::class, 'cancel'])->name('checkout.cancel');
    Route::post('checkout/cod', [CheckoutController::class, 'codCheckout'])->name('checkout.cod');
    Route::post('checkout/razorpay/success', [CheckoutController::class, 'razorpaySuccess'])->name('checkout.razorpay.success');
    Route::get('/categories/{category}/products', [CategoryController::class, 'viewProducts'])->name('categories.products');
    Route::get('categories/{category}/subcategories', [CategoryController::class, 'viewSubcategories'])->name('categories.viewSubcategories');
    Route::get('/category/{category}/products', [UserController::class, 'categorywiseshow'])->name('user.categorywiseproduct');

    Route::get('subcategories', [SubcategoryController::class, 'index'])->name('subcategories.index');
    Route::get('subcategories/create', [SubcategoryController::class, 'create'])->name('subcategories.create');
    Route::post('subcategories', [SubcategoryController::class, 'store'])->name('subcategories.store');
    Route::get('subcategories/{id}', [SubcategoryController::class, 'show'])->name('subcategories.show');
    Route::get('subcategories/{id}/edit', [SubcategoryController::class, 'edit'])->name('subcategories.edit');
    Route::put('subcategories/{id}', [SubcategoryController::class, 'update'])->name('subcategories.update');
    Route::delete('subcategories/{id}', [SubcategoryController::class, 'destroy'])->name('subcategories.destroy');
    Route::get('deleted-subcategories', [DeletedSubcategoryController::class, 'index'])->name('subcategories.deleted');
    Route::post('deleted-subcategories/{id}/restore', [DeletedSubcategoryController::class, 'restore'])->name('subcategories.restore');
    Route::delete('deleted-subcategories/{id}/force-delete', [DeletedSubcategoryController::class, 'forceDelete'])->name('subcategories.force-delete');
    Route::get('subcategories/export-pdf', [SubcategoryController::class, 'exportToPdf'])->name('subcategories.exportToPdf');
    Route::get('subcategories/{subcategory}', [SubcategoryController::class, 'show'])->name('subcategories.show');

    Route::post('checkout/paytm/callback', [CheckoutController::class, 'paytmCallback'])->name('checkout.paytm.callback');

    // Route for displaying products of a subcategory
    Route::get('subcategories/{id}/products', [SubcategoryController::class, 'viewProducts'])->name('subcategories.viewProducts');

    Route::get('product/{id}', [UserController::class, 'show'])->name('user.product_details');
    Route::get('/search', [UserController::class, 'index'])->name('user.search');
    Route::post('/delete-account', [UserController::class, 'deleteAccount'])->name('delete.account');


    // Change password routes
    Route::get('/change-password', [ChangePasswordController::class, 'showChangePasswordForm'])->name('change-password.form');
    Route::post('/change-password', [ChangePasswordController::class, 'updatePassword'])->name('change-password.update');

    // Change password routes for user
    Route::get('/user/change-password', [ChangePasswordController::class, 'showuserChangePasswordForm'])->name('userchange-password.form');
    Route::post('/user/change-password', [ChangePasswordController::class, 'updatePassword'])->name('change-password.update');
    // User profile routes
    Route::get('/profile', [AuthController::class, 'show'])->name('profile');
    Route::get('/myprofile', [AuthController::class, 'userprofileshow'])->name('userprofile');
    Route::get('/profile/orders', [UserController::class, 'showOrders'])->name('user.orders');

    // Wishlist Section
    Route::get('/profile/wishlist', [UserController::class, 'showWishlist'])->name('user.wishlist');

    // Support Section
    // Display support page (GET request)
    Route::get('/profile/support', [UserController::class, 'showSupport'])->name('user.support');

    // Handle form submission (POST request)
    Route::post('/profile/support', [UserController::class, 'storeSupport'])->name('user.support.store');


    // FAQ Section
    Route::get('/profile/faq', [UserController::class, 'showFAQ'])->name('user.faq');

    Route::put('/profile/image', [AuthController::class, 'updateImage'])->name('profile.update.image');
    Route::put('/profile/userimage', [AuthController::class, 'updateuserImage'])->name('profile.update.userimage');

    Route::resource('order', OrderController::class);
    Route::post('order/{order}/edit', [OrderController::class, 'update'])->name('order.edit');
    Route::get('/contact-us', [ContactUsController::class, 'create'])->name('user.contact-us');
    Route::post('/contact-us', [ContactUsController::class, 'store']);
    Route::get('/dashboard/contact-msg', [DashboardController::class, 'dashboard'])->name('dashboard.contact-msg');
    Route::post('/contact-msg/{id}/read', [ContactUsController::class, 'markAsRead'])->name('contact-msg.mark-as-read');
    Route::post('/contact-msg/mark-all-as-read', [NotificationController::class, 'markAllAsRead'])->name('contact_msg.mark_all_as_read');
    Route::delete('/contact-msg/clear-all', [NotificationController::class, 'clearAll'])->name('contact_msg.clear_all');
    Route::delete('/contact-msg/delete-selected', [ContactUsController::class, 'deleteSelected'])->name('contact-msg.delete-selected');
    Route::get('/inbox', function () {
        $contactUsSubmissions = ContactUs::all();
        return view('inbox', compact('contactUsSubmissions'));
    })->name('inbox');
});

Route::delete('products/{id}/delete-image/{image}', [ProductController::class, 'deleteImage'])->name('products.deleteImage');
Route::get('/home', [UserController::class, 'index'])->name('user.index');

Route::resource('product_combos', ProductComboController::class);
Route::post('product_combos/{id}/restore', [ProductComboController::class, 'restore'])->name('product_combos.restore');
Route::patch('/product_combos/{product_combo}/softdelete', [ProductComboController::class, 'softDelete'])->name('product_combos.softdelete');
Route::get('product_combos/{combo}/edit', [ProductComboController::class, 'edit'])->name('product_combos.edit');
