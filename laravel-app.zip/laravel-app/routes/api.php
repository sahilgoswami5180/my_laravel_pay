<?php

use App\Http\Controllers\Api\ApiUserController;
use App\Http\Controllers\Api\AuthApiController;
use App\Http\Controllers\Api\CategoryApiController;
use App\Http\Controllers\Api\ProductApiController;
use App\Http\Controllers\Api\UserApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');


// Route::middleware('auth:sanctum')->group(function () {
Route::get('categories', [CategoryApiController::class, 'index']);
Route::post('categories/create', [CategoryApiController::class, 'store']);
Route::get('categories/{category}', [CategoryApiController::class, 'show']);
Route::put('categories/{category}', [CategoryApiController::class, 'update']);
Route::delete('categories/{category}', [CategoryApiController::class, 'destroy']);
Route::post('categories/{id}/restore', [CategoryApiController::class, 'restore']);
Route::get('categories/{category}/products', [CategoryApiController::class, 'viewProducts']);
Route::get('categories/{category}/subcategories', [CategoryApiController::class, 'viewSubcategories']);
// });

// GET http://127.0.0.1:8001/api/categories
// POST http://127.0.0.1:8001/api/categories/create
// PUT http://127.0.0.1:8001/api/categories/5
// DELETE http://127.0.0.1:8001/api/categories/5
// for restore POST http://127.0.0.1:8001/api/categories/5/restore
// for get product by category GET http://127.0.0.1:8001/api/categories/1/products
// for get subcategories by category GET  http://127.0.0.1:8001/api/categories/2/subcategories


Route::get('products', [ProductApiController::class, 'index']);
Route::post('products/create', [ProductApiController::class, 'store']);
Route::get('products/{product}', [ProductApiController::class, 'show']);
Route::put('products/{product}', [ProductApiController::class, 'update']);
Route::delete('products/{product}', [ProductApiController::class, 'destroy']);
Route::post('products/{id}/restore', [ProductApiController::class, 'restore']);
Route::post('products/{product}/status', [ProductApiController::class, 'updateStatus']);
Route::get('products/{product}/generate-qrcode', [ProductApiController::class, 'generateProductQrCode']);
Route::get('products/export/csv', [ProductApiController::class, 'exportToCsv']);
Route::get('products/export/pdf', [ProductApiController::class, 'exportToPdf']);
Route::get('products/card', [ProductApiController::class, 'card']);

// GET http://127.0.0.1:8001/api/products
// POST http://127.0.0.1:8001/api/products/create
// GET http://127.0.0.1:8001/api/products/3
// PUT http://127.0.0.1:8000/api/products/3
// DELETE http://127.0.0.1:8000/api/products/3
// POST http://127.0.0.1:8000/api/products/3/restore
// POST http://127.0.0.1:8000/api/products/3/status
// GET http://127.0.0.1:8000/api/products/export/csv
// GET http://127.0.0.1:8000/api/products/export/pdf



// Registration route - Handles user registration, OTP via email and SMS
Route::post('register', [AuthApiController::class, 'register']);
// Email verification route - Handles the email verification link
Route::get('verify-email/{token}', [AuthApiController::class, 'verifyEmail'])->name('auth.verify-email');
// Login route - Handles user login
Route::post('login', [AuthApiController::class, 'login']);
// Logout route - Handles user logout
Route::post('logout', [AuthApiController::class, 'logout']);
// OTP verification route - Handles OTP verification
Route::post('verify-otp', [AuthApiController::class, 'verifyOtp']);
// Show OTP verification form - If you want to display a form in front-end
Route::get('show-otp-form', [AuthApiController::class, 'showOtpVerifyForm']);
// Resend OTP route - Handles OTP resend functionality
Route::post('resend-otp', [AuthApiController::class, 'resendOtp']);
// Check user existence by email
Route::get('check-user', [AuthApiController::class, 'checkUserExistence']);


// User dashboard and product listing
Route::get('dashboard', [UserApiController::class, 'index']);
// Show products by category
Route::get('category/{categoryId}', [UserApiController::class, 'categoryWiseShow']);
// Show product details
Route::get('product/{id}', [UserApiController::class, 'show']);
// Add product to cart
Route::post('cart/{id}', [UserApiController::class, 'addToCart']);
// Update cart item quantity
Route::put('cart/{id}', [UserApiController::class, 'updateQuantity']);
// Remove product from cart
Route::delete('cart/{id}', [UserApiController::class, 'removeFromCart']);
// Delete user account
Route::delete('account', [UserApiController::class, 'deleteAccount']);
// Show user profile
Route::get('profile', [UserApiController::class, 'showProfile']);
// Show user orders
Route::get('orders', [UserApiController::class, 'showOrders']);
// Show user wishlist
Route::get('wishlist', [UserApiController::class, 'showWishlist']);
// Show support page
Route::get('support', [UserApiController::class, 'showSupport']);
// Store support request
Route::post('support', [UserApiController::class, 'storeSupport']);
// Show FAQ page
Route::get('faq', [UserApiController::class, 'showFAQ']);


// GET http://127.0.0.1:8000/api/dashboard

Route::get('/user', [ApiUserController::class, 'index']);
    
// Show products by category
Route::get('/category/{categoryId}/products', [ApiUserController::class, 'categorywiseshow']);

// Show product details
Route::get('/product/{id}', [ApiUserController::class, 'show']);

// Add to cart
Route::post('/cart/{id}', [ApiUserController::class, 'addToCart']);

// Update cart quantity
Route::put('/cart/{id}', [ApiUserController::class, 'updateQuantity']);

// Remove from cart
Route::delete('/cart/{id}', [ApiUserController::class, 'removeFromCart']);

// Delete account
Route::delete('/account', [ApiUserController::class, 'deleteAccount']);

// Show profile
Route::get('/profile', [ApiUserController::class, 'showProfile']);

// Show orders
Route::get('/orders', [ApiUserController::class, 'showOrders']);

// Show order details
Route::get('/orders/{orderId}', [ApiUserController::class, 'showOrderDetails']);

// Show wishlist
Route::get('/wishlist', [ApiUserController::class, 'showWishlist']);

// Support page
Route::get('/support', [ApiUserController::class, 'showSupport']);

// Submit support request
Route::post('/support', [ApiUserController::class, 'storeSupport']);

// Show FAQ
Route::get('/faq', [ApiUserController::class, 'showFAQ']);